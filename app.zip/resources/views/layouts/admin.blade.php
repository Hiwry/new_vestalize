<!DOCTYPE html>
<html lang="pt-BR" class="h-full">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'Laravel') }}</title>

    <!-- ⚡ CRITICAL: Prevenir flash aplicando tema ANTES de qualquer renderização -->
    <script>
        (function() {
            try {
                const isDarkMode = localStorage.getItem('dark') === 'true';
                const html = document.documentElement;
                
                // Aplicar classe dark IMEDIATAMENTE (antes de qualquer renderização)
                if (isDarkMode) {
                    html.classList.add('dark');
                    html.style.colorScheme = 'dark';
                    html.style.backgroundColor = '#111827';
                } else {
                    html.classList.remove('dark');
                    html.style.colorScheme = 'light';
                    html.style.backgroundColor = '#f9fafb';
                }
                
                // Aplicar ao body se já existir (pode não existir ainda)
                if (document.body) {
                    if (isDarkMode) {
                        document.body.style.backgroundColor = '#111827';
                        document.body.style.color = '#f9fafb';
                    } else {
                        document.body.style.backgroundColor = '#f9fafb';
                        document.body.style.color = '#111827';
                    }
                } else {
                    // Se o body ainda não existe, aguardar e aplicar quando for criado
                    const observer = new MutationObserver(function(mutations) {
                        if (document.body) {
                            if (isDarkMode) {
                                document.body.style.backgroundColor = '#111827';
                                document.body.style.color = '#f9fafb';
                            } else {
                                document.body.style.backgroundColor = '#f9fafb';
                                document.body.style.color = '#111827';
                            }
                            observer.disconnect();
                        }
                    });
                    observer.observe(document.documentElement, { childList: true });
                }
            } catch (e) {
                // Fallback silencioso
            }
        })();
    </script>
    
    <style>
        /* Prevenir flash durante carregamento - aplicar ANTES do Tailwind */
        html {
            background-color: #f9fafb;
            color: #111827;
        }
        
        html.dark {
            background-color: #111827 !important;
            color: #f9fafb !important;
        }
        
        html:not(.dark) body {
            background-color: #f9fafb;
            color: #111827;
        }
        
        html.dark body {
            background-color: #111827 !important;
            color: #f9fafb !important;
        }
        
        /* Prevenir flash em elementos comuns - remover transições durante carregamento */
        html.dark * {
            transition: background-color 0s, color 0s, border-color 0s;
        }
        
        /* Forçar background escuro imediatamente no dark mode */
        html.dark #main-content {
            background-color: #111827 !important;
        }
        
        html.dark #main-content main {
            background-color: #111827 !important;
        }
        
        /* Prevenir flash durante navegação */
        html.dark body {
            background-color: #111827 !important;
            transition: none !important;
        }
    </style>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

    <!-- Suprimir aviso do Tailwind CDN ANTES de carregar o script -->
    <script>
        // Suprimir aviso do Tailwind CDN em produção
        if (typeof console !== 'undefined' && console.warn) {
            const originalWarn = console.warn;
            console.warn = function(...args) {
                if (args[0] && typeof args[0] === 'string' && args[0].includes('cdn.tailwindcss.com')) {
                    return; // Suprimir aviso do Tailwind CDN
                }
                originalWarn.apply(console, args);
            };
        }
    </script>
    
    <!-- Tailwind CSS via CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        // Configuração do Tailwind após carregar o CDN
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {}
            }
        };
    </script>
    <style>
        .dark p:not([class*="text-"]) { color: rgb(226 232 240); }
        .dark p.text-gray-900,
        .dark p.text-gray-800,
        .dark p.text-gray-700,
        .dark p.text-black { color: rgb(226 232 240) !important; }
        
        /* Forçar cor de texto dos inputs no dark mode */
        .dark input[type="text"],
        .dark input[type="email"],
        .dark input[type="password"],
        .dark input[type="number"],
        .dark input[type="tel"],
        .dark input[type="url"],
        .dark input[type="search"],
        .dark textarea,
        .dark select {
            color: rgb(243 244 246) !important;
        }
        
        /* Placeholder no dark mode */
        .dark input::placeholder,
        .dark textarea::placeholder {
            color: rgb(156 163 175) !important;
            opacity: 1;
        }
        
        /* Autocomplete no dark mode */
        .dark input:-webkit-autofill,
        .dark input:-webkit-autofill:hover,
        .dark input:-webkit-autofill:focus,
        .dark textarea:-webkit-autofill,
        .dark textarea:-webkit-autofill:hover,
        .dark textarea:-webkit-autofill:focus,
        .dark select:-webkit-autofill,
        .dark select:-webkit-autofill:hover,
        .dark select:-webkit-autofill:focus {
            -webkit-text-fill-color: rgb(243 244 246) !important;
            -webkit-box-shadow: 0 0 0px 1000px rgb(55 65 81) inset !important;
            box-shadow: 0 0 0px 1000px rgb(55 65 81) inset !important;
        }
    </style>
    
    <!-- Alpine.js para componentes interativos -->
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
    
    <!-- Chart.js para gráficos -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    <script>
        // Garantir que Chart.js está disponível
        window.chartJsLoaded = typeof Chart !== 'undefined';
        if (!window.chartJsLoaded) {
            console.error('Chart.js não foi carregado corretamente');
        }
    </script>
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Paste Modal CSS -->
    <link rel="stylesheet" href="{{ asset('css/paste-modal.css') }}">
    
    <!-- Dark Mode Script -->
    <script src="{{ asset('js/dark-mode.js') }}"></script>
    <!-- AJAX Navigation Script -->
    <script src="{{ asset('js/ajax-navigation.js') }}" defer></script>
    <!-- Paste Modal Script -->
    <script src="{{ asset('js/paste-modal.js') }}" defer></script>
</head>
<body class="h-full bg-gray-50 dark:bg-gray-900">
    <div class="h-screen overflow-hidden">
        <!-- Sidebar -->
        @include('components.app-sidebar')

        <!-- Page Content -->
        <div id="main-content" class="h-screen overflow-y-auto bg-gray-50 dark:bg-gray-900">
            <main class="p-4 sm:p-6 min-h-full">
                @yield('content')
                @stack('page-scripts')
            </main>
        </div>
    </div>

    <!-- Notificações Flutuantes -->
    @include('components.notifications-bell')

    <!-- Scripts -->
    <script>
        // Garantir que o dark mode seja aplicado IMEDIATAMENTE ao carregar
        (function() {
            const isDarkMode = localStorage.getItem('dark') === 'true';
            const html = document.documentElement;
            
            if (isDarkMode) {
                html.classList.add('dark');
                html.style.colorScheme = 'dark';
                // Forçar estilos inline para prevenir flash
                html.style.backgroundColor = '#111827';
                if (document.body) {
                    document.body.style.backgroundColor = '#111827';
                    document.body.style.color = '#f9fafb';
                }
            }
        })();
        
        // Inicializar margem do conteúdo baseado no estado da sidebar
        document.addEventListener('DOMContentLoaded', function() {
            // Garantir dark mode novamente após DOM carregar
            const isDarkMode = localStorage.getItem('dark') === 'true';
            if (isDarkMode) {
                document.documentElement.classList.add('dark');
                document.documentElement.style.colorScheme = 'dark';
            }
            
            const sidebarExpanded = localStorage.getItem('sidebarExpanded') === 'true';
            const mainContent = document.getElementById('main-content');
            if (mainContent) {
                mainContent.style.marginLeft = sidebarExpanded ? '16rem' : '4rem';
            }
        });
        
        // Não sobrescrever toggleDarkMode se já existir (do dark-mode.js)
        // A função já está definida no dark-mode.js
        
        // Monitorar mudanças de página (para navegação AJAX ou normal)
        let lastDarkMode = localStorage.getItem('dark') === 'true';
        setInterval(function() {
            const currentDarkMode = localStorage.getItem('dark') === 'true';
            if (currentDarkMode !== lastDarkMode) {
                lastDarkMode = currentDarkMode;
                if (currentDarkMode) {
                    document.documentElement.classList.add('dark');
                    document.documentElement.style.colorScheme = 'dark';
                } else {
                    document.documentElement.classList.remove('dark');
                    document.documentElement.style.colorScheme = 'light';
                }
            } else if (currentDarkMode && !document.documentElement.classList.contains('dark')) {
                // Se deveria estar em dark mode mas não está, corrigir
                document.documentElement.classList.add('dark');
                document.documentElement.style.colorScheme = 'dark';
            }
        }, 100);
    </script>

    @stack('scripts')
</body>
</html>

