<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <title>Nota do Pedido #<?php echo e(str_pad($order->id, 6, '0', STR_PAD_LEFT)); ?></title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: Arial, sans-serif;
            font-size: 11px;
            line-height: 1.3;
            color: #000;
            background: white;
        }
        .header {
            text-align: center;
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 2px solid #000;
        }
        .header h1 {
            font-size: 20px;
            color: #000;
            margin-bottom: 3px;
            font-weight: bold;
        }
        .header .subtitle {
            font-size: 12px;
            color: #333;
        }
        .company-info {
            text-align: left;
            margin-bottom: 10px;
            padding: 6px 8px;
            background-color: #f5f5f5;
            border: 1px solid #ccc;
        }
        .company-info h2 {
            font-size: 14px;
            color: #000;
            margin-bottom: 2px;
            font-weight: bold;
        }
        .company-info p {
            font-size: 8px;
            color: #333;
            margin: 0;
            line-height: 1.2;
        }
        .section {
            margin-bottom: 12px;
            padding: 8px;
            border: 1px solid #000;
        }
        .section-title {
            font-size: 12px;
            font-weight: bold;
            color: #000;
            margin-bottom: 6px;
            padding-bottom: 2px;
            border-bottom: 1px solid #000;
            text-transform: uppercase;
        }
        .info-grid {
            display: table;
            width: 100%;
        }
        .info-row {
            display: table-row;
        }
        .info-label {
            display: table-cell;
            font-weight: bold;
            padding: 2px 8px 2px 0;
            width: 30%;
            font-size: 10px;
        }
        .info-value {
            display: table-cell;
            padding: 2px 0;
            font-size: 10px;
        }
        .item-section {
            margin-bottom: 12px;
            padding: 8px;
            background-color: #f9f9f9;
            border: 1px solid #ccc;
        }
        .item-header {
            font-size: 11px;
            font-weight: bold;
            color: #000;
            margin-bottom: 6px;
            text-transform: uppercase;
        }
        .application-item {
            background-color: white;
            border-left: 3px solid #000;
            padding: 6px;
            margin-bottom: 6px;
            font-size: 9px;
        }
        .application-header {
            font-weight: bold;
            color: #000;
            margin-bottom: 2px;
        }
        .application-details {
            color: #333;
        }
        .price-row {
            display: flex;
            justify-content: space-between;
            margin-top: 4px;
            padding-top: 4px;
            border-top: 1px dashed #000;
            font-size: 9px;
        }
        .total-section {
            background-color: #000;
            color: white;
            padding: 12px;
            text-align: center;
            margin: 15px 0;
        }
        .total-section h3 {
            font-size: 14px;
            margin-bottom: 3px;
        }
        .total-section .amount {
            font-size: 20px;
            font-weight: bold;
        }
        .payment-info {
            background-color: #f0f0f0;
            border: 1px solid #000;
            padding: 8px;
            margin: 12px 0;
        }
        .payment-info h4 {
            color: #000;
            font-size: 11px;
            margin-bottom: 4px;
            font-weight: bold;
        }
        .payment-details {
            font-size: 10px;
            color: #000;
        }
        .footer {
            margin-top: 20px;
            text-align: center;
            font-size: 9px;
            color: #000;
            border-top: 1px solid #000;
            padding-top: 8px;
        }
        .status-badge {
            display: inline-block;
            padding: 2px 6px;
            border: 1px solid #000;
            font-size: 9px;
            font-weight: bold;
            text-transform: uppercase;
            background-color: #f0f0f0;
        }
    </style>
</head>
<body>
    <!-- Cabeçalho -->
    <div class="header">
        <h1>NOTA DO PEDIDO</h1>
        <div class="subtitle">Pedido #<?php echo e(str_pad($order->id, 6, '0', STR_PAD_LEFT)); ?></div>
    </div>

    <!-- Informações da Empresa -->
    <div class="company-info" style="padding: 6px 8px;">
        <div style="display: table; width: 100%;">
            <div style="display: table-row;">
                <?php if($companySettings->logo_path && file_exists(public_path($companySettings->logo_path))): ?>
                <div style="display: table-cell; vertical-align: middle; width: 25%; padding-right: 10px;">
                    <?php
                        $logoPath = public_path($companySettings->logo_path);
                        $imageData = base64_encode(file_get_contents($logoPath));
                        $imageType = pathinfo($logoPath, PATHINFO_EXTENSION);
                        $imageSrc = "data:image/{$imageType};base64,{$imageData}";
                    ?>
                    <img src="<?php echo e($imageSrc); ?>" 
                         alt="Logo" 
                         style="max-height: 50px; max-width: 120px; object-fit: contain;">
                </div>
                <?php endif; ?>
                <div style="display: table-cell; vertical-align: middle; <?php echo e($companySettings->logo_path && file_exists(public_path($companySettings->logo_path)) ? 'width: 75%;' : 'width: 100%;'); ?>">
                    <h2 style="margin: 0 0 3px 0; font-size: 14px;"><?php echo e($companySettings->company_name ?? 'SUA EMPRESA'); ?></h2>
                    <div style="font-size: 8px; line-height: 1.2;">
                        <?php if($companySettings->company_address || $companySettings->company_city): ?>
                        <span><?php if($companySettings->company_address): ?><?php echo e($companySettings->company_address); ?><?php endif; ?>
                        <?php if($companySettings->company_city): ?>, <?php echo e($companySettings->company_city); ?><?php endif; ?>
                        <?php if($companySettings->company_state): ?> - <?php echo e($companySettings->company_state); ?><?php endif; ?>
                        <?php if($companySettings->company_zip): ?> - CEP: <?php echo e($companySettings->company_zip); ?><?php endif; ?></span> |
                        <?php endif; ?>
                        <?php if($companySettings->company_phone): ?>Tel: <?php echo e($companySettings->company_phone); ?><?php endif; ?>
                        <?php if($companySettings->company_phone && $companySettings->company_email): ?> | <?php endif; ?>
                        <?php if($companySettings->company_email): ?>Email: <?php echo e($companySettings->company_email); ?><?php endif; ?>
                        <?php if($companySettings->company_cnpj): ?>
                        | CNPJ: <?php echo e($companySettings->company_cnpj); ?>

                        <?php endif; ?>
                        <?php if($companySettings->company_website): ?>
                        <br><span><?php echo e($companySettings->company_website); ?></span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Informações do Cliente -->
    <div class="section">
        <div class="section-title">DADOS DO CLIENTE</div>
        <div class="info-grid">
            <div class="info-row">
                <div class="info-label">Nome:</div>
                <div class="info-value"><?php echo e($order->client->name); ?></div>
            </div>
            <div class="info-row">
                <div class="info-label">Telefone:</div>
                <div class="info-value"><?php echo e($order->client->phone_primary); ?></div>
            </div>
            <?php if($order->client->email): ?>
            <div class="info-row">
                <div class="info-label">Email:</div>
                <div class="info-value"><?php echo e($order->client->email); ?></div>
            </div>
            <?php endif; ?>
            <?php if($order->client->cpf_cnpj): ?>
            <div class="info-row">
                <div class="info-label">CPF/CNPJ:</div>
                <div class="info-value"><?php echo e($order->client->cpf_cnpj); ?></div>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Status e Datas -->
    <div class="section">
        <div class="section-title">STATUS DO PEDIDO</div>
        <div class="info-grid">
            <div class="info-row">
                <div class="info-label">Status Atual:</div>
                <div class="info-value">
                    <span class="status-badge status-<?php echo e(strtolower(str_replace(' ', '-', $order->status->name))); ?>" 
                          style="background-color: <?php echo e($order->status->color); ?>20; color: <?php echo e($order->status->color); ?>">
                        <?php echo e($order->status->name); ?>

                    </span>
                </div>
            </div>
            <div class="info-row">
                <div class="info-label">Data do Pedido:</div>
                <div class="info-value"><?php echo e($order->created_at->format('d/m/Y H:i')); ?></div>
            </div>
            <?php if($order->delivery_date): ?>
            <div class="info-row">
                <div class="info-label">Data de Entrega:</div>
                <div class="info-value"><?php echo e(\Carbon\Carbon::parse($order->delivery_date)->format('d/m/Y')); ?></div>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Itens do Pedido -->
    <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="item-section">
        <div class="item-header">ITEM <?php echo e($loop->iteration); ?> - <?php echo e($item->print_type); ?></div>
        
        <!-- Nome da Arte -->
        <?php if($item->art_name): ?>
        <div style="margin-bottom: 8px;">
            <div style="font-weight: bold; margin-bottom: 3px; font-size: 11px;">NOME DA ARTE:</div>
            <div style="font-size: 12px; font-weight: bold; padding: 5px; background-color: white; text-align: center; border: 1px solid #E5E7EB;">
                <?php echo e($item->art_name); ?>

            </div>
        </div>
        <?php endif; ?>


        <!-- Detalhes da Costura -->
        <div style="margin-bottom: 8px;">
            <div style="font-weight: bold; margin-bottom: 3px; font-size: 11px;">ESPECIFICAÇÕES DA COSTURA:</div>
            <div class="info-grid">
                <div class="info-row">
                    <div class="info-label">Tecido:</div>
                    <div class="info-value"><?php echo e($item->fabric); ?></div>
                </div>
                <div class="info-row">
                    <div class="info-label">Cor:</div>
                    <div class="info-value"><?php echo e($item->color); ?></div>
                </div>
                <div class="info-row">
                    <div class="info-label">Tipo de Impressão:</div>
                    <div class="info-value"><?php echo e($item->print_type); ?></div>
                </div>
            </div>
            <?php
                // Garantir que sizes seja um array
                $itemSizesForSum = is_array($item->sizes) ? $item->sizes : (is_string($item->sizes) && !empty($item->sizes) ? json_decode($item->sizes, true) : []);
                $itemSizesForSum = $itemSizesForSum ?? [];
                $totalQuantity = array_sum($itemSizesForSum);
            ?>
            <div class="price-row">
                <span>Quantidade Total: <?php echo e($totalQuantity); ?> unidades</span>
                <span>Preço Unitário da Costura: R$ <?php echo e(number_format($item->unit_price, 2, ',', '.')); ?></span>
                <span><strong>Valor da Costura: R$ <?php echo e(number_format($item->unit_price * $totalQuantity, 2, ',', '.')); ?></strong></span>
            </div>
        </div>

        <!-- Aplicações -->
        <?php if($item->sublimations && $item->sublimations->count() > 0): ?>
        <div style="margin-bottom: 8px;">
            <div style="font-weight: bold; margin-bottom: 3px; font-size: 11px;">APLICAÇÕES DE PERSONALIZAÇÃO:</div>
            
            <?php $__currentLoopData = $item->sublimations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $sizeName = $sub->size ? $sub->size->name : $sub->size_name;
                $sizeDimensions = $sub->size ? $sub->size->dimensions : '';
                $locationName = $sub->location ? $sub->location->name : $sub->location_name;
                $appType = $sub->application_type ? strtoupper($sub->application_type) : 'APLICAÇÃO';
            ?>
            <div class="application-item">
                <div class="application-header">
                    Aplicação <?php echo e($index + 1); ?>: 
                    <?php if($sizeName): ?>
                        <?php echo e($sizeName); ?><?php if($sizeDimensions): ?> (<?php echo e($sizeDimensions); ?>)<?php endif; ?>
                    <?php else: ?>
                        <?php echo e($appType); ?>

                    <?php endif; ?>
                </div>
                <div class="application-details">
                    <?php if($locationName): ?><strong>Local:</strong> <?php echo e($locationName); ?> | <?php endif; ?>
                    <strong>Quantidade:</strong> <?php echo e($sub->quantity); ?>

                    <?php if($sub->color_count > 0): ?>
                    | <strong>Cores:</strong> <?php echo e($sub->color_count); ?>

                    <?php endif; ?>
                    <?php if($sub->has_neon): ?>
                    | <strong>Neon:</strong> Sim
                    <?php endif; ?>
                </div>
                <div class="price-row">
                    <span>Preço Unitário: R$ <?php echo e(number_format($sub->unit_price, 2, ',', '.')); ?> × <?php echo e($sub->quantity); ?></span>
                    <?php if($sub->discount_percent > 0): ?>
                    <span style="color: #059669;">Desconto: <?php echo e($sub->discount_percent); ?>%</span>
                    <?php endif; ?>
                    <span><strong>Subtotal: R$ <?php echo e(number_format($sub->final_price, 2, ',', '.')); ?></strong></span>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endif; ?>

        <!-- Tamanhos -->
        <div style="margin-bottom: 8px;">
            <div style="font-weight: bold; margin-bottom: 3px; font-size: 10px;">TAMANHOS:</div>
            <?php
                $allSizes = ['PP', 'P', 'M', 'G', 'GG', 'EXG', 'G1', 'G2', 'G3', 'ESPECIAL'];
                // Garantir que sizes seja um array
                $itemSizes = is_array($item->sizes) ? $item->sizes : (is_string($item->sizes) && !empty($item->sizes) ? json_decode($item->sizes, true) : []);
                $itemSizes = $itemSizes ?? [];
            ?>
            <table style="width: 100%; border-collapse: collapse; font-size: 9px;">
                <thead>
                    <tr style="background-color: #000 !important;">
                        <?php $__currentLoopData = $allSizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th style="border: 1px solid #000; padding: 4px; text-align: center; font-weight: bold; color: #fff !important; background-color: #000 !important;"><?php echo e($size); ?></th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <?php $__currentLoopData = $allSizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $qty = $itemSizes[$size] ?? $itemSizes[strtolower($size)] ?? 0;
                        ?>
                        <td style="border: 1px solid #000; padding: 4px; text-align: center; color: #000 !important; background-color: <?php echo e($qty > 0 ? '#f0f0f0' : '#fff'); ?> !important; <?php echo e($qty > 0 ? 'font-weight: bold;' : ''); ?>"><?php echo e($qty); ?></td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                </tbody>
            </table>
        </div>

        <!-- Acréscimos de Tamanhos Especiais -->
        <?php
            // Calcular total do item (costura + personalizações) para usar no cálculo dos acréscimos
            $itemTotalBeforeSurcharges = ($item->unit_price * $totalQuantity);
            if ($item->sublimations && $item->sublimations->count() > 0) {
                foreach ($item->sublimations as $sub) {
                    $itemTotalBeforeSurcharges += $sub->final_price;
                }
            }
            
            // Tamanhos que têm acréscimo
            $sizesWithSurcharge = ['GG', 'EXG', 'ESPECIAL'];
            $hasSurcharges = false;
            $totalSurcharges = 0;
            $surchargesDetails = [];
            
            foreach ($sizesWithSurcharge as $size) {
                $qty = $itemSizes[$size] ?? $itemSizes[strtolower($size)] ?? 0;
                if ($qty > 0) {
                    // Buscar acréscimo no banco de dados baseado no total do item
                    $surchargeData = \App\Models\SizeSurcharge::getSurchargeForSize($size, $itemTotalBeforeSurcharges);
                    if ($surchargeData) {
                        $surchargePerUnit = $surchargeData->surcharge;
                        $totalSurchargeForSize = $surchargePerUnit * $qty;
                        $totalSurcharges += $totalSurchargeForSize;
                        $hasSurcharges = true;
                        $surchargesDetails[] = [
                            'size' => $size,
                            'quantity' => $qty,
                            'surcharge_per_unit' => $surchargePerUnit,
                            'total' => $totalSurchargeForSize
                        ];
                    }
                }
            }
        ?>
        
        <?php if($hasSurcharges): ?>
        <div style="margin-bottom: 8px; padding: 6px; background-color: #fff3cd; border: 1px solid #ffc107; border-left: 3px solid #ff9800;">
            <div style="font-weight: bold; margin-bottom: 4px; font-size: 10px; color: #856404;">ACRÉSCIMOS DE TAMANHOS ESPECIAIS:</div>
            <?php $__currentLoopData = $surchargesDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="price-row" style="font-size: 9px; margin-top: 3px;">
                <span>Acréscimo <?php echo e($detail['size']); ?> (<?php echo e($detail['quantity']); ?>x R$ <?php echo e(number_format($detail['surcharge_per_unit'], 2, ',', '.')); ?>):</span>
                <span style="color: #ff9800; font-weight: bold;">+R$ <?php echo e(number_format($detail['total'], 2, ',', '.')); ?></span>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="price-row" style="font-size: 10px; margin-top: 4px; padding-top: 4px; border-top: 1px solid #ffc107; font-weight: bold;">
                <span>Total de Acréscimos:</span>
                <span style="color: #ff5722; font-weight: bold;">+R$ <?php echo e(number_format($totalSurcharges, 2, ',', '.')); ?></span>
            </div>
        </div>
        <?php endif; ?>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <!-- Resumo Financeiro -->
    <div class="total-section">
        <h3>TOTAL DO PEDIDO</h3>
        <div class="amount">R$ <?php echo e(number_format($order->total, 2, ',', '.')); ?></div>
    </div>

    <!-- Informações de Pagamento -->
    <?php if($payment): ?>
    <div class="payment-info">
        <h4>INFORMAÇÕES DE PAGAMENTO</h4>
        <div class="payment-details">
            <div style="margin-bottom: 5px;">
                <strong>Total Pago:</strong> R$ <?php echo e(number_format($payment->entry_amount, 2, ',', '.')); ?>

            </div>
            <div style="margin-bottom: 5px;">
                <strong><?php echo e($payment->remaining_amount < 0 ? 'Crédito do Cliente:' : 'Restante:'); ?></strong> R$ <?php echo e(number_format(abs($payment->remaining_amount), 2, ',', '.')); ?>

            </div>
            <div>
                <strong>Método:</strong> <?php echo e(ucfirst($payment->method)); ?>

            </div>
            <?php if($payment->notes): ?>
            <div style="margin-top: 5px;">
                <strong>Observações:</strong> <?php echo e($payment->notes); ?>

            </div>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>

    <!-- Observações -->
    <?php if($order->notes): ?>
    <div class="section">
        <div class="section-title">OBSERVAÇÕES</div>
        <div style="padding: 6px; background-color: #f0f0f0; border-left: 3px solid #000; font-size: 10px;">
            <?php echo e($order->notes); ?>

        </div>
    </div>
    <?php endif; ?>

    <!-- Rodapé -->
    <div class="footer">
        <p><strong>Obrigado pela preferência!</strong></p>
        <p>Esta nota serve como comprovante do seu pedido.</p>
        <p>Para dúvidas, entre em contato conosco.</p>
        <?php if($companySettings->company_phone || $companySettings->company_email): ?>
        <p>
            <?php if($companySettings->company_phone): ?>Tel: <?php echo e($companySettings->company_phone); ?><?php endif; ?>
            <?php if($companySettings->company_phone && $companySettings->company_email): ?> | <?php endif; ?>
            <?php if($companySettings->company_email): ?>Email: <?php echo e($companySettings->company_email); ?><?php endif; ?>
        </p>
        <?php endif; ?>
        <p>Impresso em <?php echo e(date('d/m/Y H:i')); ?></p>
    </div>
</body>
</html>
<?php /**PATH /home2/dd173158/laravel/resources/views/orders/pdf/client-receipt.blade.php ENDPATH**/ ?>