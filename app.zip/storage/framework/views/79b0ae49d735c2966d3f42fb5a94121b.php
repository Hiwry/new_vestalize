<!-- Wrapper para Sidebar e Modal -->
<div x-data="{
        expanded: localStorage.getItem('sidebarExpanded') === 'true',
        showProfileModal: false,
        toggle() {
            this.expanded = !this.expanded;
            localStorage.setItem('sidebarExpanded', this.expanded);
            const mainContent = document.getElementById('main-content');
            if (mainContent) {
                mainContent.style.marginLeft = this.expanded ? '16rem' : '4rem';
            }
        }
    }"
    @keydown.escape.window="showProfileModal = false">

<!-- Sidebar -->
<aside id="sidebar" 
       :class="expanded ? 'w-64' : 'w-16'"
       class="fixed top-0 left-0 z-40 h-screen bg-white dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700 overflow-hidden transition-all duration-300 ease-in-out">
    
    <!-- Header do Sidebar com Botão Toggle -->
    <div class="flex items-center justify-between h-16 px-4 border-b border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800">
        <h1 class="text-xl font-medium text-gray-800 dark:text-white whitespace-nowrap overflow-hidden transition-all duration-300"
            x-show="expanded"
            x-transition:enter="transition ease-out duration-300"
            x-transition:enter-start="opacity-0"
            x-transition:enter-end="opacity-100"
            x-transition:leave="transition ease-in duration-300"
            x-transition:leave-start="opacity-100"
            x-transition:leave-end="opacity-0">
            Sistema de Pedidos
        </h1>
        <button @click="toggle()" 
                class="flex-shrink-0 p-2 rounded-md text-gray-700 dark:text-gray-300 hover:bg-blue-50 dark:hover:bg-gray-700 hover:text-blue-600 dark:hover:text-white transition-all border border-transparent hover:border-blue-200 dark:hover:border-gray-600"
                :class="expanded ? '' : 'mx-auto'"
                title="Expandir/Recolher Menu">
            <svg class="w-6 h-6 transition-transform duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2.5"
                 :class="expanded ? '' : 'rotate-180'">
                <path stroke-linecap="round" stroke-linejoin="round" d="M11 19l-7-7 7-7m8 14l-7-7 7-7"></path>
            </svg>
        </button>
    </div>

    <!-- Menu Items -->
    <nav class="flex flex-col px-2 py-4 space-y-1 overflow-y-auto h-[calc(100vh-16rem)]">
        <?php if(Auth::user()->isEstoque() && !Auth::user()->isAdmin()): ?>
            <!-- Sidebar Simplificada para Estoque -->
            <!-- Tela Inicial -->
            <a href="<?php echo e(route('dashboard')); ?>" 
               class="flex items-center px-3 py-2.5 text-sm font-medium rounded-md transition-all duration-300 ease-in-out <?php echo e(request()->is('dashboard*') ? 'bg-blue-600 text-white' : 'text-gray-700 dark:text-gray-300 hover:bg-blue-50 dark:hover:bg-gray-700 hover:text-blue-600 dark:hover:text-white'); ?>"
               :class="expanded ? 'justify-start' : 'justify-center'">
                <svg class="flex-shrink-0 h-5 w-5 <?php echo e(request()->is('dashboard*') ? 'text-white' : 'text-gray-500 dark:text-gray-400'); ?>" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
                </svg>
                <span class="whitespace-nowrap overflow-hidden transition-all duration-300 ease-in-out"
                      :class="expanded ? 'opacity-100 ml-3' : 'opacity-0 w-0'">
                    Tela Inicial
                </span>
            </a>

            <!-- Estoque -->
            <a href="<?php echo e(route('stocks.index')); ?>" 
               class="flex items-center px-3 py-2.5 text-sm font-medium rounded-md transition-all duration-300 ease-in-out <?php echo e(request()->is('stocks*') && !request()->is('stock-requests*') && !request()->is('stock-history*') ? 'bg-blue-600 text-white' : 'text-gray-700 dark:text-gray-300 hover:bg-blue-50 dark:hover:bg-gray-700 hover:text-blue-600 dark:hover:text-white'); ?>"
               :class="expanded ? 'justify-start' : 'justify-center'">
                <svg class="flex-shrink-0 h-5 w-5 <?php echo e(request()->is('stocks*') && !request()->is('stock-requests*') && !request()->is('stock-history*') ? 'text-white' : 'text-gray-500 dark:text-gray-400'); ?>" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" />
                </svg>
                <span class="whitespace-nowrap overflow-hidden transition-all duration-300 ease-in-out"
                      :class="expanded ? 'opacity-100 ml-3' : 'opacity-0 w-0'">
                    Estoque
                </span>
            </a>

            <!-- Solicitações -->
            <a href="<?php echo e(route('stock-requests.index')); ?>" 
               class="flex items-center px-3 py-2.5 text-sm font-medium rounded-md transition-all duration-300 ease-in-out <?php echo e(request()->is('stock-requests*') ? 'bg-blue-600 text-white' : 'text-gray-700 dark:text-gray-300 hover:bg-blue-50 dark:hover:bg-gray-700 hover:text-blue-600 dark:hover:text-white'); ?>"
               :class="expanded ? 'justify-start' : 'justify-center'">
                <svg class="flex-shrink-0 h-5 w-5 <?php echo e(request()->is('stock-requests*') ? 'text-white' : 'text-gray-500 dark:text-gray-400'); ?>" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                </svg>
                <span class="whitespace-nowrap overflow-hidden transition-all duration-300 ease-in-out"
                      :class="expanded ? 'opacity-100 ml-3' : 'opacity-0 w-0'">
                    Solicitações
                </span>
            </a>
        <?php else: ?>
            <!-- Sidebar Completa para outros usuários -->
            <!-- Tela Inicial -->
            <a href="<?php echo e(url('/')); ?>" 
               class="flex items-center px-3 py-2.5 text-sm font-medium rounded-md transition-all duration-300 ease-in-out <?php echo e(request()->is('/') ? 'bg-blue-600 text-white' : 'text-gray-700 dark:text-gray-300 hover:bg-blue-50 dark:hover:bg-gray-700 hover:text-blue-600 dark:hover:text-white'); ?>"
               :class="expanded ? 'justify-start' : 'justify-center'">
                <svg class="flex-shrink-0 h-5 w-5 <?php echo e(request()->is('/') ? 'text-white' : 'text-gray-500 dark:text-gray-400'); ?>" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
                </svg>
                <span class="whitespace-nowrap overflow-hidden transition-all duration-300 ease-in-out"
                      :class="expanded ? 'opacity-100 ml-3' : 'opacity-0 w-0'">
                    Tela Inicial
                </span>
            </a>

            <!-- Pedidos -->
        <a href="<?php echo e(route('orders.index')); ?>" 
           class="flex items-center px-3 py-2.5 text-sm font-medium rounded-md transition-all duration-300 ease-in-out <?php echo e(request()->is('pedidos*') ? 'bg-blue-600 text-white' : 'text-gray-700 dark:text-gray-300 hover:bg-blue-50 dark:hover:bg-gray-700 hover:text-blue-600 dark:hover:text-white'); ?>"
           :class="expanded ? 'justify-start' : 'justify-center'">
            <svg class="flex-shrink-0 h-5 w-5 <?php echo e(request()->is('pedidos*') ? 'text-white' : 'text-gray-500 dark:text-gray-400'); ?>" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
            </svg>
            <span class="whitespace-nowrap overflow-hidden transition-all duration-300 ease-in-out"
                  :class="expanded ? 'opacity-100 ml-3' : 'opacity-0 w-0'">
                Pedidos
            </span>
        </a>

        <!-- Orçamento -->
        <a href="<?php echo e(route('budget.index')); ?>" 
           class="flex items-center px-3 py-2.5 text-sm font-medium rounded-md transition-all duration-300 ease-in-out <?php echo e(request()->is('orcamento*') ? 'bg-blue-600 text-white' : 'text-gray-700 dark:text-gray-300 hover:bg-blue-50 dark:hover:bg-gray-700 hover:text-blue-600 dark:hover:text-white'); ?>"
           :class="expanded ? 'justify-start' : 'justify-center'">
            <svg class="flex-shrink-0 h-5 w-5 <?php echo e(request()->is('orcamento*') ? 'text-white' : 'text-gray-500 dark:text-gray-400'); ?>" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
            </svg>
            <span class="whitespace-nowrap overflow-hidden transition-all duration-300 ease-in-out"
                  :class="expanded ? 'opacity-100 ml-3' : 'opacity-0 w-0'">
                Orçamento
            </span>
        </a>

        <!-- PDV (Vendedor e Admin) -->
        <?php if(Auth::user()->isVendedor() || Auth::user()->isAdmin()): ?>
        <a href="<?php echo e(route('pdv.index')); ?>" 
           class="flex items-center px-3 py-2.5 text-sm font-medium rounded-md transition-all duration-300 ease-in-out <?php echo e(request()->is('pdv') && !request()->is('pdv/vendas*') ? 'bg-blue-600 text-white' : 'text-gray-700 dark:text-gray-300 hover:bg-blue-50 dark:hover:bg-gray-700 hover:text-blue-600 dark:hover:text-white'); ?>"
           :class="expanded ? 'justify-start' : 'justify-center'">
            <svg class="flex-shrink-0 h-5 w-5 <?php echo e(request()->is('pdv') && !request()->is('pdv/vendas*') ? 'text-white' : 'text-gray-500 dark:text-gray-400'); ?>" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
            </svg>
            <span class="whitespace-nowrap overflow-hidden transition-all duration-300 ease-in-out"
                  :class="expanded ? 'opacity-100 ml-3' : 'opacity-0 w-0'">
                PDV
            </span>
        </a>
        <?php endif; ?>

        <!-- Clientes -->
        <a href="<?php echo e(route('clients.index')); ?>" 
           class="flex items-center px-3 py-2.5 text-sm font-medium rounded-md transition-all duration-300 ease-in-out <?php echo e(request()->is('clientes*') ? 'bg-blue-600 text-white' : 'text-gray-700 dark:text-gray-300 hover:bg-blue-50 dark:hover:bg-gray-700 hover:text-blue-600 dark:hover:text-white'); ?>"
           :class="expanded ? 'justify-start' : 'justify-center'">
            <svg class="flex-shrink-0 h-5 w-5 <?php echo e(request()->is('clientes*') ? 'text-white' : 'text-gray-500 dark:text-gray-400'); ?>" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
            </svg>
            <span class="whitespace-nowrap overflow-hidden transition-all duration-300 ease-in-out"
                  :class="expanded ? 'opacity-100 ml-3' : 'opacity-0 w-0'">
                Clientes
            </span>
        </a>

        <!-- Kanban -->
        <a href="<?php echo e(route('kanban.index')); ?>" 
           class="flex items-center px-3 py-2.5 text-sm font-medium rounded-md transition-all duration-300 ease-in-out <?php echo e(request()->is('kanban*') ? 'bg-blue-600 text-white' : 'text-gray-700 dark:text-gray-300 hover:bg-blue-50 dark:hover:bg-gray-700 hover:text-blue-600 dark:hover:text-white'); ?>"
           :class="expanded ? 'justify-start' : 'justify-center'">
            <svg class="flex-shrink-0 h-5 w-5 <?php echo e(request()->is('kanban*') ? 'text-white' : 'text-gray-500 dark:text-gray-400'); ?>" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4" />
            </svg>
            <span class="whitespace-nowrap overflow-hidden transition-all duration-300 ease-in-out"
                  :class="expanded ? 'opacity-100 ml-3' : 'opacity-0 w-0'">
                Kanban
            </span>
        </a>

        <!-- Dashboard Produção (Produção e Admin) -->
        <?php if(Auth::user()->isProducao() || Auth::user()->isAdmin()): ?>
        <a href="<?php echo e(route('production.dashboard')); ?>" 
           class="flex items-center px-3 py-2.5 text-sm font-medium rounded-md transition-all duration-300 ease-in-out <?php echo e(request()->is('production/dashboard*') ? 'bg-blue-600 text-white' : 'text-gray-700 dark:text-gray-300 hover:bg-blue-50 dark:hover:bg-gray-700 hover:text-blue-600 dark:hover:text-white'); ?>"
           :class="expanded ? 'justify-start' : 'justify-center'">
            <svg class="flex-shrink-0 h-5 w-5 <?php echo e(request()->is('production/dashboard*') ? 'text-white' : 'text-gray-500 dark:text-gray-400'); ?>" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
            </svg>
            <span class="whitespace-nowrap overflow-hidden transition-all duration-300 ease-in-out"
                  :class="expanded ? 'opacity-100 ml-3' : 'opacity-0 w-0'">
                Dashboard Produção
            </span>
        </a>

        <!-- Produção (Produção e Admin) -->
        <a href="<?php echo e(route('production.index')); ?>" 
           class="flex items-center px-3 py-2.5 text-sm font-medium rounded-md transition-all duration-300 ease-in-out <?php echo e(request()->is('producao*') && !request()->is('production/dashboard*') ? 'bg-blue-600 text-white' : 'text-gray-700 dark:text-gray-300 hover:bg-blue-50 dark:hover:bg-gray-700 hover:text-blue-600 dark:hover:text-white'); ?>"
           :class="expanded ? 'justify-start' : 'justify-center'">
            <svg class="flex-shrink-0 h-5 w-5 <?php echo e(request()->is('producao*') && !request()->is('production/dashboard*') ? 'text-white' : 'text-gray-500 dark:text-gray-400'); ?>" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" />
            </svg>
            <span class="whitespace-nowrap overflow-hidden transition-all duration-300 ease-in-out"
                  :class="expanded ? 'opacity-100 ml-3' : 'opacity-0 w-0'">
                Produção
            </span>
        </a>
        <?php endif; ?>

        <!-- Divisor -->
        <div class="pt-2 pb-2">
            <div class="border-t border-gray-200 dark:border-gray-700"></div>
        </div>

        <!-- Caixa (Admin e Caixa) -->
        <?php if(Auth::user()->isAdmin() || Auth::user()->isCaixa()): ?>
        <a href="<?php echo e(route('cash.index')); ?>" 
           class="flex items-center px-3 py-2.5 text-sm font-medium rounded-md transition-all duration-300 ease-in-out <?php echo e(request()->is('cash') && !request()->is('cash/*') ? 'bg-blue-600 text-white' : 'text-gray-700 dark:text-gray-300 hover:bg-blue-50 dark:hover:bg-gray-700 hover:text-blue-600 dark:hover:text-white'); ?>"
           :class="expanded ? 'justify-start' : 'justify-center'">
            <svg class="flex-shrink-0 h-5 w-5 <?php echo e(request()->is('cash') && !request()->is('cash/*') ? 'text-white' : 'text-gray-500 dark:text-gray-400'); ?>" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z" />
            </svg>
            <span class="whitespace-nowrap overflow-hidden transition-all duration-300 ease-in-out"
                  :class="expanded ? 'opacity-100 ml-3' : 'opacity-0 w-0'">
                Caixa
            </span>
        </a>
        
        <!-- Aprovações (Admin e Caixa) -->
        <a href="<?php echo e(route('cash.approvals.index')); ?>" 
           class="flex items-center px-3 py-2.5 text-sm font-medium rounded-md transition-all duration-300 ease-in-out <?php echo e(request()->is('cash/approvals*') ? 'bg-blue-600 text-white' : 'text-gray-700 dark:text-gray-300 hover:bg-blue-50 dark:hover:bg-gray-700 hover:text-blue-600 dark:hover:text-white'); ?>"
           :class="expanded ? 'justify-start' : 'justify-center'">
            <svg class="flex-shrink-0 h-5 w-5 <?php echo e(request()->is('cash/approvals*') ? 'text-white' : 'text-gray-500 dark:text-gray-400'); ?>" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <span class="whitespace-nowrap overflow-hidden transition-all duration-300 ease-in-out"
                  :class="expanded ? 'opacity-100 ml-3' : 'opacity-0 w-0'">
                Aprovações
            </span>
        </a>
        <?php endif; ?>

        <!-- Estoque (Admin e Estoque) -->
        <?php if(Auth::user()->isAdmin() || Auth::user()->isEstoque()): ?>
        <a href="<?php echo e(route('stocks.index')); ?>" 
           class="flex items-center px-3 py-2.5 text-sm font-medium rounded-md transition-all duration-300 ease-in-out <?php echo e(request()->is('stocks*') && !request()->is('stock-requests*') && !request()->is('stock-history*') ? 'bg-blue-600 text-white' : 'text-gray-700 dark:text-gray-300 hover:bg-blue-50 dark:hover:bg-gray-700 hover:text-blue-600 dark:hover:text-white'); ?>"
           :class="expanded ? 'justify-start' : 'justify-center'">
            <svg class="flex-shrink-0 h-5 w-5 <?php echo e(request()->is('stocks*') && !request()->is('stock-requests*') && !request()->is('stock-history*') ? 'text-white' : 'text-gray-500 dark:text-gray-400'); ?>" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" />
            </svg>
            <span class="whitespace-nowrap overflow-hidden transition-all duration-300 ease-in-out"
                  :class="expanded ? 'opacity-100 ml-3' : 'opacity-0 w-0'">
                Estoque
            </span>
        </a>
        <?php endif; ?>

        <!-- Divisor -->
        <div class="pt-2 pb-2">
            <div class="border-t border-gray-200 dark:border-gray-700"></div>
        </div>

        <!-- Configurações (não para vendedor) -->
        <?php if(!Auth::user()->isVendedor()): ?>
        <a href="<?php echo e(route('settings.index')); ?>" 
           class="flex items-center px-3 py-2.5 text-sm font-medium rounded-md transition-all duration-300 ease-in-out <?php echo e(request()->is('settings*') ? 'bg-blue-600 text-white' : 'text-gray-700 dark:text-gray-300 hover:bg-blue-50 dark:hover:bg-gray-700 hover:text-blue-600 dark:hover:text-white'); ?>"
           :class="expanded ? 'justify-start' : 'justify-center'">
            <svg class="flex-shrink-0 h-5 w-5 <?php echo e(request()->is('settings*') ? 'text-white' : 'text-gray-500 dark:text-gray-400'); ?>" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
            </svg>
            <span class="whitespace-nowrap overflow-hidden transition-all duration-300 ease-in-out"
                  :class="expanded ? 'opacity-100 ml-3' : 'opacity-0 w-0'">
                Configurações
            </span>
        </a>
        <?php endif; ?>

        <!-- Links -->
        <a href="<?php echo e(route('links.index')); ?>" 
           class="flex items-center px-3 py-2.5 text-sm font-medium rounded-md transition-all duration-300 ease-in-out <?php echo e(request()->is('links*') ? 'bg-blue-600 text-white' : 'text-gray-700 dark:text-gray-300 hover:bg-blue-50 dark:hover:bg-gray-700 hover:text-blue-600 dark:hover:text-white'); ?>"
           :class="expanded ? 'justify-start' : 'justify-center'">
            <svg class="flex-shrink-0 h-5 w-5 <?php echo e(request()->is('links*') ? 'text-white' : 'text-gray-500 dark:text-gray-400'); ?>" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
            </svg>
            <span class="whitespace-nowrap overflow-hidden transition-all duration-300 ease-in-out"
                  :class="expanded ? 'opacity-100 ml-3' : 'opacity-0 w-0'">
                Links
            </span>
        </a>

        <!-- Botão de Alternar Tema -->
        <button id="theme-toggle" 
                x-data="{ isDark: localStorage.getItem('dark') === 'true' }"
                @click="isDark = !isDark; toggleDarkMode()"
                class="flex items-center px-3 py-2.5 text-sm font-medium rounded-md text-gray-700 dark:text-gray-300 hover:bg-blue-50 dark:hover:bg-gray-700 hover:text-blue-600 dark:hover:text-white transition-all duration-300 ease-in-out"
                :class="expanded ? 'justify-start' : 'justify-center'">
            <svg x-show="isDark" class="flex-shrink-0 h-5 w-5 text-gray-500 dark:text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z" />
            </svg>
            <svg x-show="!isDark" class="flex-shrink-0 h-5 w-5 text-gray-500 dark:text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z" />
            </svg>
            <span class="whitespace-nowrap overflow-hidden transition-all duration-300 ease-in-out"
                  :class="expanded ? 'opacity-100 ml-3' : 'opacity-0 w-0'">
                Tema
            </span>
        </button>
        <?php endif; ?>
    </nav>

    <!-- Footer do Sidebar -->
    <div class="absolute bottom-0 left-0 right-0 p-3 border-t border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800">
        <button @click="showProfileModal = true" 
                class="flex items-center w-full px-3 py-2.5 text-sm font-medium rounded-md text-gray-700 dark:text-gray-300 hover:bg-blue-50 dark:hover:bg-gray-700 hover:text-blue-600 dark:hover:text-white transition-all duration-300 ease-in-out"
                :class="expanded ? 'justify-start' : 'justify-center'">
            <div class="flex-shrink-0 flex items-center justify-center h-8 w-8 rounded-full bg-blue-600 text-white text-sm font-medium">
                <?php echo e(strtoupper(substr(auth()->user()->name, 0, 2))); ?>

            </div>
            <span class="whitespace-nowrap overflow-hidden transition-all duration-300 ease-in-out truncate"
                  :class="expanded ? 'opacity-100 ml-3 max-w-[180px]' : 'opacity-0 w-0'">
                <?php echo e(auth()->user()->name); ?>

            </span>
        </button>
    </div>
</aside>

<!-- Modal de Perfil -->
<div x-show="showProfileModal" 
@click.self="showProfileModal = false"
style="display: none;"
class="fixed inset-0 z-[9999] flex items-center justify-center p-4 bg-black bg-opacity-50 backdrop-blur-sm transition-opacity duration-300"
x-transition:enter="transition ease-out duration-200"
x-transition:enter-start="opacity-0"
x-transition:enter-end="opacity-100"
x-transition:leave="transition ease-in duration-150"
x-transition:leave-start="opacity-100"
x-transition:leave-end="opacity-0">
    
    <!-- Conteúdo do Modal -->
    <div class="bg-white dark:bg-gray-800 rounded-lg shadow-xl max-w-md w-full max-h-[90vh] overflow-y-auto"
         x-transition:enter="transition ease-out duration-200 transform"
         x-transition:enter-start="opacity-0 scale-95"
         x-transition:enter-end="opacity-100 scale-100"
         x-transition:leave="transition ease-in duration-150 transform"
         x-transition:leave-start="opacity-100 scale-100"
         x-transition:leave-end="opacity-0 scale-95">
        
        <!-- Header do Modal -->
        <div class="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
            <h2 class="text-xl font-semibold text-gray-900 dark:text-gray-100">Informações do Perfil</h2>
            <button @click="showProfileModal = false" class="text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 transition">
                <svg class="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                </svg>
            </button>
        </div>

        <!-- Corpo do Modal -->
        <div class="p-6 space-y-4">
            <!-- Avatar -->
            <div class="flex items-center space-x-4">
                <div class="flex-shrink-0">
                    <div class="flex items-center justify-center h-16 w-16 rounded-full bg-blue-600 text-white text-2xl font-medium">
                        <?php echo e(strtoupper(substr(auth()->user()->name, 0, 2))); ?>

                    </div>
                </div>
                <div>
                    <h3 class="text-lg font-semibold text-gray-900 dark:text-gray-100"><?php echo e(auth()->user()->name); ?></h3>
                    <p class="text-sm text-gray-500 dark:text-gray-400"><?php echo e(auth()->user()->email); ?></p>
                </div>
            </div>

            <!-- Informações -->
            <div class="space-y-3">
                <div class="flex items-center justify-between py-2 border-b border-gray-200 dark:border-gray-700">
                    <span class="text-sm font-medium text-gray-700 dark:text-gray-300">Tipo de Usuário</span>
                    <span class="text-sm text-gray-900 dark:text-gray-100">
                        <?php if(auth()->user()->isAdmin()): ?>
                            <span class="px-2 py-1 rounded-full text-xs font-semibold bg-purple-100 text-purple-800 dark:bg-purple-800 dark:text-purple-100">Administrador</span>
                        <?php elseif(auth()->user()->isProducao()): ?>
                            <span class="px-2 py-1 rounded-full text-xs font-semibold bg-green-100 text-green-800 dark:bg-green-800 dark:text-green-100">Produção</span>
                        <?php else: ?>
                            <span class="px-2 py-1 rounded-full text-xs font-semibold bg-blue-100 text-blue-800 dark:bg-blue-800 dark:text-blue-100">Vendedor</span>
                        <?php endif; ?>
                    </span>
                </div>

                <?php if(auth()->user()->store): ?>
                <div class="flex items-center justify-between py-2 border-b border-gray-200 dark:border-gray-700">
                    <span class="text-sm font-medium text-gray-700 dark:text-gray-300">Loja</span>
                    <span class="text-sm text-gray-900 dark:text-gray-100"><?php echo e(auth()->user()->store); ?></span>
                </div>
                <?php endif; ?>

                <div class="flex items-center justify-between py-2 border-b border-gray-200 dark:border-gray-700">
                    <span class="text-sm font-medium text-gray-700 dark:text-gray-300">Data de Cadastro</span>
                    <span class="text-sm text-gray-900 dark:text-gray-100"><?php echo e(auth()->user()->created_at->format('d/m/Y')); ?></span>
                </div>
            </div>
        </div>

        <!-- Footer do Modal -->
        <div class="flex items-center justify-end p-6 border-t border-gray-200 dark:border-gray-700 space-x-3">
            <form method="POST" action="<?php echo e(route('logout')); ?>" class="inline">
                <?php echo csrf_field(); ?>
                <button type="submit" class="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2 transition duration-150 ease-in-out">
                    Sair
                </button>
            </form>
            <button @click="showProfileModal = false" class="px-4 py-2 bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-gray-200 rounded-md hover:bg-gray-300 dark:hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition duration-150 ease-in-out">
                Fechar
            </button>
        </div>
    </div>
</div>

</div><!-- Fim do wrapper sidebar + modal -->

<style>
    /* Estilos para modo escuro */
    [x-cloak] { 
        display: none !important; 
    }
    
    body.modal-open {
        overflow: hidden;
    }
    
    /* Smooth scrollbar */
    #sidebar nav {
        scrollbar-width: thin;
        scrollbar-color: rgb(156, 163, 175) transparent;
    }
    
    #sidebar nav::-webkit-scrollbar {
        width: 4px;
    }
    
    #sidebar nav::-webkit-scrollbar-track {
        background: transparent;
    }
    
    #sidebar nav::-webkit-scrollbar-thumb {
        background-color: rgb(156, 163, 175);
        border-radius: 20px;
    }
    
    .dark #sidebar nav::-webkit-scrollbar-thumb {
        background-color: rgb(75, 85, 99);
    }
</style>

<script>
// Função global para toggle do tema
window.toggleTheme = function() {
    const isDark = document.documentElement.classList.toggle('dark');
    localStorage.setItem('dark', isDark);
    document.dispatchEvent(new CustomEvent('theme-changed', { 
        detail: { dark: isDark } 
    }));
};

// Alias para compatibilidade
window.toggleDarkMode = window.toggleTheme;

// Inicializar tema ao carregar
document.addEventListener('DOMContentLoaded', function() {
    const isDark = localStorage.getItem('dark') === 'true' || 
                  (!('dark' in localStorage) && window.matchMedia('(prefers-color-scheme: dark)').matches);
    
    if (isDark) {
        document.documentElement.classList.add('dark');
    } else {
        document.documentElement.classList.remove('dark');
    }
});
</script>
<?php /**PATH /home2/dd173158/laravel/resources/views/components/app-sidebar.blade.php ENDPATH**/ ?>