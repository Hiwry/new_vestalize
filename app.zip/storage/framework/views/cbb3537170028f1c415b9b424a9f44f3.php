<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <title>Nota de Venda #<?php echo e(str_pad($order->id, 6, '0', STR_PAD_LEFT)); ?></title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: Arial, sans-serif;
            font-size: 12px;
            line-height: 1.4;
            color: #000;
            background: white;
        }
        .header {
            text-align: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 3px solid #000;
        }
        .header h1 {
            font-size: 24px;
            color: #000;
            margin-bottom: 5px;
            font-weight: bold;
            text-transform: uppercase;
        }
        .header .subtitle {
            font-size: 14px;
            color: #333;
            font-weight: bold;
        }
        .company-info {
            text-align: center;
            margin-bottom: 15px;
            padding: 10px;
            background-color: #f5f5f5;
            border: 1px solid #ccc;
        }
        .company-info h2 {
            font-size: 16px;
            color: #000;
            margin-bottom: 5px;
            font-weight: bold;
        }
        .company-info p {
            font-size: 10px;
            color: #333;
            margin: 2px 0;
            line-height: 1.3;
        }
        .section {
            margin-bottom: 15px;
            padding: 10px;
            border: 1px solid #000;
        }
        .section-title {
            font-size: 13px;
            font-weight: bold;
            color: #000;
            margin-bottom: 8px;
            padding-bottom: 5px;
            border-bottom: 2px solid #000;
            text-transform: uppercase;
        }
        .info-grid {
            display: table;
            width: 100%;
        }
        .info-row {
            display: table-row;
        }
        .info-label {
            display: table-cell;
            font-weight: bold;
            padding: 3px 10px 3px 0;
            width: 35%;
            font-size: 11px;
        }
        .info-value {
            display: table-cell;
            padding: 3px 0;
            font-size: 11px;
        }
        .items-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }
        .items-table th {
            background-color: #000;
            color: white;
            padding: 8px;
            text-align: left;
            font-size: 11px;
            font-weight: bold;
            border: 1px solid #000;
        }
        .items-table td {
            padding: 8px;
            border: 1px solid #ccc;
            font-size: 11px;
        }
        .items-table tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .total-section {
            margin-top: 20px;
            padding: 15px;
            background-color: #000;
            color: white;
            text-align: right;
        }
        .total-section .total-label {
            font-size: 14px;
            font-weight: bold;
            margin-bottom: 5px;
        }
        .total-section .total-value {
            font-size: 20px;
            font-weight: bold;
        }
        .payment-section {
            margin-top: 15px;
            padding: 10px;
            background-color: #f0f0f0;
            border: 1px solid #ccc;
        }
        .payment-method {
            padding: 5px 0;
            border-bottom: 1px solid #ddd;
        }
        .payment-method:last-child {
            border-bottom: none;
        }
        .footer {
            margin-top: 30px;
            padding-top: 15px;
            border-top: 2px solid #000;
            text-align: center;
            font-size: 10px;
            color: #666;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>NOTA DE VENDA</h1>
        <div class="subtitle">Venda #<?php echo e(str_pad($order->id, 6, '0', STR_PAD_LEFT)); ?></div>
    </div>

    <!-- Informações da Empresa -->
    <div class="company-info">
        <h2><?php echo e($companySettings->company_name ?? 'Nóbrega Confecções'); ?></h2>
        <p>
            <?php if($companySettings->company_address || $companySettings->company_city): ?>
            <?php echo e($companySettings->company_address ?? ''); ?>

            <?php if($companySettings->company_city): ?>, <?php echo e($companySettings->company_city); ?><?php endif; ?>
            <?php if($companySettings->company_state): ?> - <?php echo e($companySettings->company_state); ?><?php endif; ?>
            <?php if($companySettings->company_zip): ?> - CEP: <?php echo e($companySettings->company_zip); ?><?php endif; ?>
            <?php endif; ?>
        </p>
        <p>
            <?php if($companySettings->company_phone): ?>Tel: <?php echo e($companySettings->company_phone); ?><?php endif; ?>
            <?php if($companySettings->company_phone && $companySettings->company_email): ?> | <?php endif; ?>
            <?php if($companySettings->company_email): ?>Email: <?php echo e($companySettings->company_email); ?><?php endif; ?>
        </p>
        <?php if($companySettings->company_cnpj): ?>
        <p>CNPJ: <?php echo e($companySettings->company_cnpj); ?></p>
        <?php endif; ?>
    </div>

    <!-- Informações do Cliente -->
    <div class="section">
        <div class="section-title">DADOS DO CLIENTE</div>
        <div class="info-grid">
            <?php if($order->client): ?>
            <div class="info-row">
                <div class="info-label">Nome:</div>
                <div class="info-value"><?php echo e($order->client->name); ?></div>
            </div>
            <?php if($order->client->phone_primary): ?>
            <div class="info-row">
                <div class="info-label">Telefone:</div>
                <div class="info-value"><?php echo e($order->client->phone_primary); ?></div>
            </div>
            <?php endif; ?>
            <?php if($order->client->cpf_cnpj): ?>
            <div class="info-row">
                <div class="info-label">CPF/CNPJ:</div>
                <div class="info-value"><?php echo e($order->client->cpf_cnpj); ?></div>
            </div>
            <?php endif; ?>
            <?php else: ?>
            <div class="info-row">
                <div class="info-label">Nome:</div>
                <div class="info-value">Venda sem cliente cadastrado</div>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Informações da Venda -->
    <div class="section">
        <div class="section-title">INFORMAÇÕES DA VENDA</div>
        <div class="info-grid">
            <div class="info-row">
                <div class="info-label">Data da Venda:</div>
                <div class="info-value"><?php echo e($order->created_at->format('d/m/Y H:i')); ?></div>
            </div>
            <div class="info-row">
                <div class="info-label">Vendedor:</div>
                <div class="info-value"><?php echo e($order->user->name ?? 'N/A'); ?></div>
            </div>
            <?php if($order->notes): ?>
            <div class="info-row">
                <div class="info-label">Observações:</div>
                <div class="info-value"><?php echo e($order->notes); ?></div>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Itens da Venda -->
    <div class="section">
        <div class="section-title">ITENS DA VENDA</div>
        <table class="items-table">
            <thead>
                <tr>
                    <th>Item</th>
                    <th>Descrição</th>
                    <th>Quantidade</th>
                    <th>Preço Unit.</th>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    // Calcular acréscimos de tamanho
                    $sizes = is_string($item->sizes) ? json_decode($item->sizes, true) : $item->sizes;
                    $sizeSurcharges = [];
                    $totalSurcharges = 0;
                    
                    if (is_array($sizes) && !empty($sizes)) {
                        foreach (['GG', 'EXG', 'G1', 'G2', 'G3'] as $size) {
                            $qty = $sizes[$size] ?? 0;
                            if ($qty > 0 && $item->unit_price > 0) {
                                $surchargeData = \App\Models\SizeSurcharge::getSurchargeForSize($size, $item->unit_price);
                                if ($surchargeData) {
                                    $surchargeTotal = $surchargeData->surcharge * $qty;
                                    $sizeSurcharges[$size] = [
                                        'quantity' => $qty,
                                        'surcharge_per_unit' => $surchargeData->surcharge,
                                        'total' => $surchargeTotal,
                                    ];
                                    $totalSurcharges += $surchargeTotal;
                                }
                            }
                        }
                    }
                ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td>
                        <strong><?php echo e($item->print_type); ?></strong>
                        <?php if($item->fabric): ?>
                        <br><small>Tecido: <?php echo e($item->fabric); ?></small>
                        <?php endif; ?>
                        <?php if($item->color): ?>
                        <br><small>Cor: <?php echo e($item->color); ?></small>
                        <?php endif; ?>
                        <?php if($sizes && is_array($sizes)): ?>
                        <br><small>
                            Tamanhos: 
                            <?php $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size => $qty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($qty > 0): ?>
                                    <?php echo e($size); ?>(<?php echo e($qty); ?>) 
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </small>
                        <?php endif; ?>
                    </td>
                    <td><?php echo e(number_format($item->quantity, 2, ',', '.')); ?></td>
                    <td>R$ <?php echo e(number_format($item->unit_price, 2, ',', '.')); ?></td>
                    <td>R$ <?php echo e(number_format($item->unit_price * $item->quantity, 2, ',', '.')); ?></td>
                </tr>
                <?php if(!empty($sizeSurcharges)): ?>
                <?php $__currentLoopData = $sizeSurcharges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size => $surchargeData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr style="background-color: #f0f0f0;">
                    <td></td>
                    <td style="padding-left: 30px;">
                        <small>
                            <strong>Acréscimo Tamanho <?php echo e($size); ?>:</strong><br>
                            <?php echo e($surchargeData['quantity']); ?> unidade(s) × R$ <?php echo e(number_format($surchargeData['surcharge_per_unit'], 2, ',', '.')); ?>

                        </small>
                    </td>
                    <td><?php echo e(number_format($surchargeData['quantity'], 2, ',', '.')); ?></td>
                    <td>R$ <?php echo e(number_format($surchargeData['surcharge_per_unit'], 2, ',', '.')); ?></td>
                    <td>R$ <?php echo e(number_format($surchargeData['total'], 2, ',', '.')); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <?php if($item->sublimations && $item->sublimations->count() > 0): ?>
                    <?php $__currentLoopData = $item->sublimations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sublimation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr style="background-color: #f0f0f0;">
                        <td></td>
                        <td style="padding-left: 30px;">
                            <small>
                                <strong>Personalização SUB.LOCAL:</strong><br>
                                <?php
                                    $locationName = $sublimation->location ? $sublimation->location->name : ($sublimation->location_name ?? 'Local não informado');
                                    $sizeName = $sublimation->size ? $sublimation->size->name : ($sublimation->size_name ?? '');
                                ?>
                                <?php echo e($locationName); ?>

                                <?php if($sizeName): ?>
                                - Tamanho: <?php echo e($sizeName); ?>

                                <?php endif; ?>
                            </small>
                        </td>
                        <td><?php echo e(number_format($sublimation->quantity, 2, ',', '.')); ?></td>
                        <td>R$ <?php echo e(number_format($sublimation->unit_price, 2, ',', '.')); ?></td>
                        <td>R$ <?php echo e(number_format($sublimation->final_price, 2, ',', '.')); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        // Calcular total do item incluindo acréscimos e personalizações
                        $itemBaseTotal = $item->unit_price * $item->quantity;
                        $itemSublimationsTotal = $item->sublimations->sum('final_price');
                        $itemTotalWithSurcharges = $itemBaseTotal + $totalSurcharges + $itemSublimationsTotal;
                    ?>
                    <?php if($totalSurcharges > 0 || $itemSublimationsTotal > 0): ?>
                    <tr style="background-color: #e8e8e8; font-weight: bold; border-top: 2px solid #000;">
                        <td colspan="4" style="text-align: right; padding-right: 10px;">Subtotal do Item:</td>
                        <td>R$ <?php echo e(number_format($itemTotalWithSurcharges, 2, ',', '.')); ?></td>
                    </tr>
                    <?php endif; ?>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <!-- Totais -->
    <div class="total-section">
        <div class="total-label">TOTAL DA VENDA</div>
        <div class="total-value">R$ <?php echo e(number_format($order->total, 2, ',', '.')); ?></div>
    </div>

    <!-- Formas de Pagamento -->
    <?php if($payment && $payment->payment_methods): ?>
    <div class="payment-section">
        <div class="section-title" style="border-bottom: 2px solid #000; margin-bottom: 10px; padding-bottom: 5px;">FORMA(S) DE PAGAMENTO</div>
        <?php
            $paymentMethods = is_array($payment->payment_methods) ? $payment->payment_methods : json_decode($payment->payment_methods, true);
        ?>
        <?php if(is_array($paymentMethods)): ?>
            <?php $__currentLoopData = $paymentMethods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $method): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="payment-method">
                <strong><?php echo e(ucfirst($method['method'] ?? 'N/A')); ?>:</strong> 
                R$ <?php echo e(number_format($method['amount'] ?? 0, 2, ',', '.')); ?>

            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        <div style="margin-top: 10px; padding-top: 10px; border-top: 1px solid #ccc; font-weight: bold;">
            Total Pago: R$ <?php echo e(number_format($payment->entry_amount ?? 0, 2, ',', '.')); ?>

            <?php if($payment->remaining_amount > 0): ?>
            <br><small style="color: #d32f2f;">Restante: R$ <?php echo e(number_format($payment->remaining_amount, 2, ',', '.')); ?></small>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>

    <!-- Rodapé -->
    <div class="footer">
        <p>Esta é uma nota de venda gerada automaticamente pelo sistema PDV.</p>
        <p>Data de impressão: <?php echo e(now()->format('d/m/Y H:i:s')); ?></p>
    </div>
</body>
</html>

<?php /**PATH /home2/dd173158/laravel/resources/views/pdv/pdf/sale-receipt.blade.php ENDPATH**/ ?>