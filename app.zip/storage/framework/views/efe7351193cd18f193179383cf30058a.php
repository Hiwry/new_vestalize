

<?php $__env->startSection('content'); ?>
<div class="max-w-7xl mx-auto">
        <!-- Progress Bar -->
        <div class="mb-8">
            <div class="flex items-center justify-between mb-4">
                <div class="flex items-center space-x-3">
                    <div class="w-10 h-10 bg-gradient-to-br from-indigo-500 to-indigo-600 dark:from-indigo-600 dark:to-indigo-700 text-white rounded-xl flex items-center justify-center text-sm font-bold shadow-lg shadow-indigo-500/20 dark:shadow-indigo-600/20">2</div>
                    <div>
                        <span class="text-lg font-bold text-gray-900 dark:text-white">Costura e Personalização</span>
                        <p class="text-xs text-gray-500 dark:text-slate-400 mt-0.5">Etapa 2 de 5</p>
                    </div>
                </div>
                <div class="text-right">
                    <div class="text-xs text-gray-500 dark:text-slate-400 font-medium">Progresso</div>
                    <div class="text-2xl font-bold text-indigo-600 dark:text-indigo-400">40%</div>
                </div>
            </div>
            <div class="w-full bg-gray-200 dark:bg-slate-800 rounded-full h-2.5 shadow-inner">
                <div class="bg-gradient-to-r from-indigo-600 to-indigo-500 dark:from-indigo-500 dark:to-indigo-600 h-2.5 rounded-full transition-all duration-500 ease-out shadow-lg shadow-indigo-500/30 dark:shadow-indigo-600/30" style="width: 40%"></div>
            </div>
        </div>

        <!-- Messages -->
        <?php if(session('success')): ?>
        <div class="mb-6 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg p-4 shadow-sm">
            <div class="flex items-center">
                <svg class="w-5 h-5 text-green-600 dark:text-green-400 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
                </svg>
                <p class="text-sm font-medium text-green-800 dark:text-green-200"><?php echo e(session('success')); ?></p>
            </div>
        </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
        <div class="mb-6 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg p-4 shadow-sm">
            <div class="flex items-center">
                <svg class="w-5 h-5 text-red-600 dark:text-red-400 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                </svg>
                <p class="text-sm font-medium text-red-800 dark:text-red-200"><?php echo e(session('error')); ?></p>
            </div>
        </div>
        <?php endif; ?>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <!-- Formulário de Adicionar Item -->
            <div class="lg:col-span-2">
                <div class="bg-white dark:bg-slate-900 rounded-xl shadow-xl dark:shadow-2xl dark:shadow-black/20 border border-gray-200 dark:border-slate-800 overflow-hidden">
                    <!-- Header -->
                    <div class="px-6 py-5 border-b border-gray-100 dark:border-slate-800 bg-gradient-to-r from-gray-50 to-white dark:from-slate-800/50 dark:to-slate-900/50">
                        <div class="flex items-center space-x-3">
                            <div class="w-12 h-12 bg-gradient-to-br from-indigo-500 to-indigo-600 dark:from-indigo-600 dark:to-indigo-700 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-500/20 dark:shadow-indigo-600/20">
                                <svg class="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"></path>
                                </svg>
                            </div>
                            <div>
                                <h1 class="text-xl font-bold text-gray-900 dark:text-white" id="form-title">Adicionar Novo Item</h1>
                                <p class="text-sm text-gray-500 dark:text-slate-400 mt-0.5">Configure os detalhes do item de costura</p>
                            </div>
                        </div>
                    </div>

                    <div class="p-6">
                        <form method="POST" action="<?php echo e(isset($editData) ? route('orders.edit.sewing') : route('orders.wizard.sewing')); ?>" id="sewing-form" class="space-y-5" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="action" value="add_item" id="form-action">
                            <input type="hidden" name="editing_item_id" value="" id="editing-item-id">

                            <!-- Personalização -->
                            <div class="p-5 bg-gray-50 dark:bg-slate-800/50 rounded-lg border border-gray-200 dark:border-slate-700">
                                <label class="block text-sm font-semibold text-gray-900 dark:text-white mb-3">Personalização *</label>
                                <div class="grid grid-cols-2 gap-2" id="personalizacao-options">
                                    <!-- Será preenchido via JavaScript -->
                                </div>
                            </div>

                            <!-- Tecido e Tipo -->
                            <div class="p-5 bg-gray-50 dark:bg-slate-800/50 rounded-lg border border-gray-200 dark:border-slate-700">
                                <label class="block text-sm font-semibold text-gray-900 dark:text-white mb-3">Tecido</label>
                                <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                                    <div>
                                        <select name="tecido" id="tecido" onchange="loadTiposTecido()" class="w-full px-4 py-2.5 rounded-lg border border-gray-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-indigo-500 dark:focus:ring-indigo-400 transition-all text-sm">
                                            <option value="">Selecione o tecido</option>
                                        </select>
                                    </div>
                                    <div id="tipo-tecido-container" style="display:none">
                                        <select name="tipo_tecido" id="tipo_tecido" onchange="onTipoTecidoChange()" class="w-full px-4 py-2.5 rounded-lg border border-gray-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-indigo-500 dark:focus:ring-indigo-400 transition-all text-sm">
                                            <option value="">Selecione o tipo</option>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <!-- Cor -->
                            <div class="p-5 bg-gray-50 dark:bg-slate-800/50 rounded-lg border border-gray-200 dark:border-slate-700">
                                <label class="block text-sm font-semibold text-gray-900 dark:text-white mb-3">Cor do Tecido *</label>
                                <select name="cor" id="cor" class="w-full px-4 py-2.5 rounded-lg border border-gray-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-indigo-500 dark:focus:ring-indigo-400 transition-all text-sm">
                                    <option value="">Selecione a cor</option>
                                </select>
                            </div>

                            <!-- Modelo e Detalhes -->
                            <div class="p-5 bg-gray-50 dark:bg-slate-800/50 rounded-lg border border-gray-200 dark:border-slate-700 space-y-3">
                                <label class="block text-sm font-semibold text-gray-900 dark:text-white">Modelo e Detalhes</label>
                                <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                                    <select name="tipo_corte" id="tipo_corte" onchange="onTipoCorteChange()" class="w-full px-4 py-2.5 rounded-lg border border-gray-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-indigo-500 dark:focus:ring-indigo-400 transition-all text-sm">
                                        <option value="">Tipo de Corte *</option>
                                    </select>
                                    <select name="detalhe" id="detalhe" onchange="updatePrice()" class="w-full px-4 py-2.5 rounded-lg border border-gray-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-indigo-500 dark:focus:ring-indigo-400 transition-all text-sm">
                                        <option value="">Detalhe</option>
                                    </select>
                                </div>
                                <select name="gola" id="gola" onchange="updatePrice()" class="w-full px-4 py-2.5 rounded-lg border border-gray-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-indigo-500 dark:focus:ring-indigo-400 transition-all text-sm">
                                    <option value="">Gola *</option>
                                </select>
                            </div>

                            <!-- Tamanhos -->
                            <div class="p-5 bg-gray-50 dark:bg-slate-800/50 rounded-lg border border-gray-200 dark:border-slate-700">
                                <label class="block text-sm font-semibold text-gray-900 dark:text-white mb-3">Tamanhos e Quantidades</label>
                                <div class="grid grid-cols-5 gap-2 mb-2">
                                    <div>
                                        <label class="block text-xs text-gray-600 dark:text-slate-400 mb-1 font-medium">PP</label>
                                        <input type="number" name="tamanhos[PP]" min="0" value="0" onchange="calculateTotal()" class="w-full px-2 py-2 border border-gray-300 dark:border-slate-600 rounded-lg text-center text-sm bg-white dark:bg-slate-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-indigo-500 dark:focus:ring-indigo-400 transition-all">
                                    </div>
                                    <div>
                                        <label class="block text-xs text-gray-600 dark:text-slate-400 mb-1 font-medium">P</label>
                                        <input type="number" name="tamanhos[P]" min="0" value="0" onchange="calculateTotal()" class="w-full px-2 py-2 border border-gray-300 dark:border-slate-600 rounded-lg text-center text-sm bg-white dark:bg-slate-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-indigo-500 dark:focus:ring-indigo-400 transition-all">
                                    </div>
                                    <div>
                                        <label class="block text-xs text-gray-600 dark:text-slate-400 mb-1 font-medium">M</label>
                                        <input type="number" name="tamanhos[M]" min="0" value="0" onchange="calculateTotal()" class="w-full px-2 py-2 border border-gray-300 dark:border-slate-600 rounded-lg text-center text-sm bg-white dark:bg-slate-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-indigo-500 dark:focus:ring-indigo-400 transition-all">
                                    </div>
                                    <div>
                                        <label class="block text-xs text-gray-600 dark:text-slate-400 mb-1 font-medium">G</label>
                                        <input type="number" name="tamanhos[G]" min="0" value="0" onchange="calculateTotal()" class="w-full px-2 py-2 border border-gray-300 dark:border-slate-600 rounded-lg text-center text-sm bg-white dark:bg-slate-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-indigo-500 dark:focus:ring-indigo-400 transition-all">
                                    </div>
                                    <div>
                                        <label class="block text-xs text-gray-600 dark:text-slate-400 mb-1 font-medium">GG</label>
                                        <input type="number" name="tamanhos[GG]" min="0" value="0" onchange="calculateTotal()" class="w-full px-2 py-2 border border-gray-300 dark:border-slate-600 rounded-lg text-center text-sm bg-white dark:bg-slate-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-indigo-500 dark:focus:ring-indigo-400 transition-all">
                                    </div>
                                </div>
                                <div class="grid grid-cols-5 gap-2 mb-3">
                                    <div>
                                        <label class="block text-xs text-gray-600 dark:text-slate-400 mb-1 font-medium">EXG</label>
                                        <input type="number" name="tamanhos[EXG]" min="0" value="0" onchange="calculateTotal()" class="size-input-restricted w-full px-2 py-2 border border-gray-300 dark:border-slate-600 rounded-lg text-center text-sm bg-white dark:bg-slate-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-indigo-500 dark:focus:ring-indigo-400 transition-all">
                                    </div>
                                    <div>
                                        <label class="block text-xs text-gray-600 dark:text-slate-400 mb-1 font-medium">G1</label>
                                        <input type="number" name="tamanhos[G1]" min="0" value="0" onchange="calculateTotal()" class="size-input-restricted w-full px-2 py-2 border border-gray-300 dark:border-slate-600 rounded-lg text-center text-sm bg-white dark:bg-slate-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-indigo-500 dark:focus:ring-indigo-400 transition-all">
                                    </div>
                                    <div>
                                        <label class="block text-xs text-gray-600 dark:text-slate-400 mb-1 font-medium">G2</label>
                                        <input type="number" name="tamanhos[G2]" min="0" value="0" onchange="calculateTotal()" class="size-input-restricted w-full px-2 py-2 border border-gray-300 dark:border-slate-600 rounded-lg text-center text-sm bg-white dark:bg-slate-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-indigo-500 dark:focus:ring-indigo-400 transition-all">
                                    </div>
                                    <div>
                                        <label class="block text-xs text-gray-600 dark:text-slate-400 mb-1 font-medium">G3</label>
                                        <input type="number" name="tamanhos[G3]" min="0" value="0" onchange="calculateTotal()" class="size-input-restricted w-full px-2 py-2 border border-gray-300 dark:border-slate-600 rounded-lg text-center text-sm bg-white dark:bg-slate-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-indigo-500 dark:focus:ring-indigo-400 transition-all">
                                    </div>
                                    <div>
                                        <label class="block text-xs text-gray-600 dark:text-slate-400 mb-1 font-medium">Especial</label>
                                        <input type="number" name="tamanhos[Especial]" min="0" value="0" onchange="calculateTotal()" class="w-full px-2 py-2 border border-gray-300 dark:border-slate-600 rounded-lg text-center text-sm bg-white dark:bg-slate-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-indigo-500 dark:focus:ring-indigo-400 transition-all">
                                    </div>
                                </div>
                                
                                <!-- Checkbox para acréscimo independente (apenas para Infantil/Baby look) -->
                                <div id="surcharge-checkbox-container" class="hidden mb-3 p-3 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg border border-yellow-200 dark:border-yellow-800">
                                    <label class="flex items-center cursor-pointer">
                                        <input type="checkbox" name="apply_surcharge" id="apply_surcharge" value="1" class="w-4 h-4 text-indigo-600 dark:text-indigo-500 border-gray-300 dark:border-slate-600 rounded focus:ring-indigo-500 dark:focus:ring-indigo-400 bg-white dark:bg-slate-700">
                                        <span class="ml-2 text-sm font-medium text-gray-900 dark:text-white">Aplicar acréscimo de tamanho especial (independente do tamanho)</span>
                                    </label>
                                    <p class="text-xs text-gray-500 dark:text-slate-400 mt-1 ml-6">Marque esta opção se desejar cobrar o acréscimo mesmo sendo modelo Infantil ou Baby look.</p>
                                </div>
                                <div class="p-3 bg-indigo-50 dark:bg-indigo-900/20 rounded-lg border border-indigo-200 dark:border-indigo-800">
                                    <div class="flex items-center justify-between">
                                        <span class="text-sm font-semibold text-gray-700 dark:text-slate-300">Total de peças:</span>
                                        <span class="text-xl font-bold text-indigo-600 dark:text-indigo-400" id="total-pecas">0</span>
                                    </div>
                                </div>
                                <input type="hidden" name="quantity" id="quantity" value="0">
                                
                                <!-- Informações de Estoque por Tamanho -->
                                <div id="stock-info-section" class="hidden mt-4 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-200 dark:border-blue-800">
                                    <h6 class="text-sm font-semibold text-gray-900 dark:text-white mb-3">Estoque Disponível por Tamanho:</h6>
                                    <div id="stock-by-size" class="space-y-2">
                                        <!-- Será preenchido via JavaScript -->
                                    </div>
                                </div>
                            </div>

                            <!-- Resumo de Preços -->
                            <div class="p-5 bg-gray-50 dark:bg-slate-800/50 rounded-lg border border-gray-200 dark:border-slate-700">
                                <label class="block text-sm font-semibold text-gray-900 dark:text-white mb-3">Resumo de Preços</label>
                                <div class="space-y-2 text-sm">
                                    <div class="flex justify-between p-2 bg-white dark:bg-slate-800 rounded">
                                        <span class="text-gray-600 dark:text-slate-400">Tipo de Corte:</span>
                                        <span class="font-semibold text-gray-900 dark:text-white" id="price-corte">R$ 0,00</span>
                                    </div>
                                    <div class="flex justify-between p-2 bg-white dark:bg-slate-800 rounded">
                                        <span class="text-gray-600 dark:text-slate-400">Detalhe:</span>
                                        <span class="font-semibold text-gray-900 dark:text-white" id="price-detalhe">R$ 0,00</span>
                                    </div>
                                    <div class="flex justify-between p-2 bg-white dark:bg-slate-800 rounded">
                                        <span class="text-gray-600 dark:text-slate-400">Gola:</span>
                                        <span class="font-semibold text-gray-900 dark:text-white" id="price-gola">R$ 0,00</span>
                                    </div>
                                    <div class="flex justify-between items-center p-3 bg-indigo-600 dark:bg-indigo-500 rounded-lg mt-2">
                                        <span class="text-white font-bold">Valor Unitário:</span>
                                        <span class="font-bold text-white text-xl" id="price-total">R$ 0,00</span>
                                    </div>
                                </div>
                                <input type="hidden" name="unit_price" id="unit_price" value="0">
                            </div>

                            <!-- Observações -->
                            <div class="p-5 bg-gray-50 dark:bg-slate-800/50 rounded-lg border border-gray-200 dark:border-slate-700">
                                <label class="block text-sm font-semibold text-gray-900 dark:text-white mb-3">Observações <span class="text-gray-500 dark:text-slate-400 font-normal text-xs">(opcional)</span></label>
                                <textarea name="art_notes" rows="3" placeholder="Informações importantes para a produção..." class="w-full px-4 py-2.5 border border-gray-300 dark:border-slate-600 rounded-lg bg-white dark:bg-slate-800 text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-slate-500 focus:ring-2 focus:ring-indigo-500 dark:focus:ring-indigo-400 transition-all text-sm"><?php echo e(old('art_notes', isset($editData) ? ($editData['art_notes'] ?? '') : '')); ?></textarea>
                            </div>

                            <!-- Botões -->
                            <div class="flex justify-between items-center pt-4 border-t border-gray-200 dark:border-slate-700">
                                <a href="<?php echo e(isset($editData) ? route('orders.edit.client') : route('orders.wizard.client')); ?>" class="px-4 py-2 text-gray-600 dark:text-slate-400 hover:text-gray-900 dark:hover:text-white text-sm font-medium">
                                    ← Voltar
                                </a>
                                <button type="submit" id="submit-button" class="px-6 py-2.5 bg-indigo-600 dark:bg-indigo-500 hover:bg-indigo-700 dark:hover:bg-indigo-600 text-white font-semibold rounded-lg transition-all text-sm">
                                    Adicionar Item
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Sidebar - Resumo dos Itens -->
            <div class="lg:col-span-1">
                <div class="bg-white dark:bg-slate-900 rounded-xl shadow-xl dark:shadow-2xl dark:shadow-black/20 border border-gray-200 dark:border-slate-800 sticky top-6">
                    <div class="px-5 py-4 border-b border-gray-200 dark:border-slate-800">
                        <h2 class="text-lg font-bold text-gray-900 dark:text-white">Itens do Pedido</h2>
                        <p class="text-sm text-gray-500 dark:text-slate-400 mt-1"><?php echo e($order->items->count()); ?> item(s)</p>
                    </div>
                    
                    <div class="p-5 max-h-[600px] overflow-y-auto">
                        <?php if($order->items->count() > 0): ?>
                            <div class="space-y-3">
                                <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="p-4 bg-gray-50 dark:bg-slate-800 rounded-lg border border-gray-200 dark:border-slate-700 hover:border-indigo-400 dark:hover:border-indigo-600 transition-colors">
                                    <div class="flex justify-between items-start mb-3">
                                        <span class="text-sm font-semibold text-gray-900 dark:text-white">Item <?php echo e($index + 1); ?></span>
                                        <div class="flex gap-1">
                                            <button type="button" onclick="editItem(<?php echo e($item->id); ?>)" class="p-1 text-indigo-600 hover:text-indigo-800 dark:text-indigo-400 dark:hover:text-indigo-300 transition-colors" title="Editar item">
                                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"></path>
                                                </svg>
                                            </button>
                                            <form method="POST" action="<?php echo e(isset($editData) ? route('orders.edit.sewing') : route('orders.wizard.sewing')); ?>" class="inline">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="action" value="delete_item">
                                                <input type="hidden" name="item_id" value="<?php echo e($item->id); ?>">
                                                <button type="submit" onclick="return confirm('Remover este item?')" class="p-1 text-red-600 hover:text-red-800 dark:text-red-400 dark:hover:text-red-300 transition-colors" title="Remover item">
                                                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path>
                                                    </svg>
                                                </button>
                                            </form>
                                        </div>
                                    </div>
                                    <div class="space-y-1 text-xs text-gray-600 dark:text-slate-400">
                                        <div class="flex justify-between"><span>Personalização:</span><span class="font-medium text-gray-900 dark:text-white"><?php echo e($item->print_type); ?></span></div>
                                        <div class="flex justify-between"><span>Tecido:</span><span class="font-medium text-gray-900 dark:text-white"><?php echo e($item->fabric); ?></span></div>
                                        <div class="flex justify-between"><span>Cor:</span><span class="font-medium text-gray-900 dark:text-white"><?php echo e($item->color); ?></span></div>
                                        <div class="flex justify-between"><span>Quantidade:</span><span class="font-medium text-gray-900 dark:text-white"><?php echo e($item->quantity); ?> pç</span></div>
                                        <div class="flex justify-between pt-2 border-t border-gray-200 dark:border-slate-700">
                                            <span class="font-semibold">Total:</span>
                                            <span class="font-bold text-indigo-600 dark:text-indigo-400">R$ <?php echo e(number_format($item->total_price, 2, ',', '.')); ?></span>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            
                            <div class="mt-4 p-4 bg-indigo-50 dark:bg-indigo-900/20 rounded-lg border border-indigo-200 dark:border-indigo-800">
                                <div class="flex justify-between items-center">
                                    <span class="text-sm font-bold text-gray-900 dark:text-white">Subtotal:</span>
                                    <span class="text-xl font-bold text-indigo-600 dark:text-indigo-400">R$ <?php echo e(number_format($order->items->sum('total_price'), 2, ',', '.')); ?></span>
                                </div>
                            </div>

                            <form method="POST" action="<?php echo e(isset($editData) ? route('orders.edit.sewing') : route('orders.wizard.sewing')); ?>" class="mt-4">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="action" value="finish">
                                <button type="submit" class="w-full px-4 py-2.5 bg-green-600 hover:bg-green-700 text-white font-semibold rounded-lg transition-all text-sm">
                                    Finalizar e Prosseguir →
                                </button>
                            </form>
                        <?php else: ?>
                            <div class="text-center py-8">
                                <p class="text-sm text-gray-500 dark:text-slate-400">Nenhum item adicionado</p>
                                <p class="text-xs text-gray-400 dark:text-slate-500 mt-1">Preencha o formulário para adicionar</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
        let options = {};
        let optionsWithParents = {};
        let selectedPersonalizacoes = [];

        document.addEventListener('DOMContentLoaded', function() {
            loadOptions();
        });

        function loadOptions() {
            fetch('/api/product-options')
                .then(response => response.json())
                .then(data => {
                    options = data;
                    return fetch('/api/product-options-with-parents');
                })
                .then(response => response.json())
                .then(data => {
                    optionsWithParents = data;
                    renderPersonalizacao();
                    renderTecidos();
                    renderCores();
                    renderTiposCorte();
                    renderDetalhes();
                    renderGolas();
                })
                .catch(error => {
                    console.error('Erro ao carregar opções:', error);
                    renderPersonalizacao();
                    renderTecidos();
                    renderCores();
                    renderTiposCorte();
                    renderDetalhes();
                    renderGolas();
                });
        }

        function renderPersonalizacao() {
            const container = document.getElementById('personalizacao-options');
            const items = options.personalizacao || [];
            
            container.innerHTML = items.map(item => `
                <label class="flex items-center px-3 py-2.5 border rounded-lg cursor-pointer transition-all ${
                    selectedPersonalizacoes.includes(item.id) 
                        ? 'border-indigo-500 dark:border-indigo-400 bg-indigo-50 dark:bg-indigo-900/20' 
                        : 'border-gray-300 dark:border-slate-600 bg-white dark:bg-slate-800 hover:border-indigo-300 dark:hover:border-indigo-600'
                }">
                    <input type="checkbox" name="personalizacao[]" value="${item.id}" 
                           onchange="togglePersonalizacao(${item.id})"
                           class="personalizacao-checkbox w-4 h-4 text-indigo-600 dark:text-indigo-500 border-gray-300 dark:border-slate-600 rounded focus:ring-indigo-500 dark:focus:ring-indigo-400 bg-white dark:bg-slate-700" ${selectedPersonalizacoes.includes(item.id) ? 'checked' : ''}>
                    <span class="ml-2 text-sm font-medium text-gray-900 dark:text-white">${item.name}</span>
                </label>
            `).join('');
        }

        function togglePersonalizacao(id) {
            const index = selectedPersonalizacoes.indexOf(id);
            if (index > -1) {
                selectedPersonalizacoes.splice(index, 1);
            } else {
                selectedPersonalizacoes.push(id);
                
                // Verificar se é SUB. TOTAL
                const personalizacaoItem = (options.personalizacao || []).find(item => item.id === id);
                if (personalizacaoItem && personalizacaoItem.name && 
                    (personalizacaoItem.name.toUpperCase().includes('SUB') && personalizacaoItem.name.toUpperCase().includes('TOTAL'))) {
                    // Definir cor como branco automaticamente
                    setTimeout(() => {
                        const corSelect = document.getElementById('cor');
                        if (corSelect) {
                            // Procurar opção "BRANCO" ou "Branco"
                            const brancaOption = Array.from(corSelect.options).find(opt => 
                                opt.text.toUpperCase().includes('BRANCO') || opt.text.toUpperCase().includes('BRANCA')
                            );
                            if (brancaOption) {
                                corSelect.value = brancaOption.value;
                            }
                        }
                        
                        // Zerar valores de modelo, detalhe e gola
                        const modeloSelect = document.getElementById('modelo');
                        const detalheSelect = document.getElementById('detalhe');
                        const golaSelect = document.getElementById('gola');
                        
                        if (modeloSelect) modeloSelect.value = '';
                        if (detalheSelect) detalheSelect.value = '';
                        if (golaSelect) golaSelect.value = '';
                    }, 300);
                }
            }
            renderPersonalizacao();
            renderTecidos();
            renderCores();
            renderTiposCorte();
        }

        function renderTecidos() {
            const select = document.getElementById('tecido');
            let items = optionsWithParents.tecido || options.tecido || [];
            
            if (selectedPersonalizacoes.length > 0 && optionsWithParents.tecido) {
                items = items.filter(tecido => {
                    // Se não tem parent_ids, mostrar sempre
                    if (!tecido.parent_ids || tecido.parent_ids.length === 0) {
                        return true;
                    }
                    return tecido.parent_ids.some(parentId => selectedPersonalizacoes.includes(parentId));
                });
            }
            
            const currentValue = select.value;
            select.innerHTML = '<option value="">Selecione o tecido</option>' + 
                items.map(item => `<option value="${item.id}">${item.name}</option>`).join('');
            
            if (currentValue && items.find(item => item.id == currentValue)) {
                select.value = currentValue;
            } else {
                select.value = '';
                loadTiposTecido();
                // Atualizar cores quando tecido mudar
                renderCores();
            }
        }

        function loadTiposTecido() {
            const tecidoId = document.getElementById('tecido').value;
            const container = document.getElementById('tipo-tecido-container');
            const select = document.getElementById('tipo_tecido');
            
            if (!tecidoId) {
                container.style.display = 'none';
                if (select) {
                    select.value = '';
                    select.required = false;
                }
                // Atualizar cores e tipos de corte quando tecido for removido
                renderCores();
                renderTiposCorte();
                return;
            }

            const items = (options.tipo_tecido || []).filter(t => t.parent_id == tecidoId);
            
            if (items.length > 0) {
                container.style.display = 'block';
                const currentValue = select.value;
                select.innerHTML = '<option value="">Selecione o tipo</option>' + 
                    items.map(item => `<option value="${item.id}">${item.name}</option>`).join('');
                select.required = true;
                
                // Restaurar valor se ainda existir
                if (currentValue && items.find(item => item.id == currentValue)) {
                    select.value = currentValue;
                } else {
                    select.value = '';
                }
            } else {
                container.style.display = 'none';
                if (select) {
                    select.value = '';
                    select.required = false;
                }
            }
            
            // Atualizar cores e tipos de corte quando tecido/tipo_tecido mudar
            renderCores();
            renderTiposCorte();
        }

        function renderCores() {
            const select = document.getElementById('cor');
            let items = optionsWithParents.cor || options.cor || [];
            
            // Filtrar cores baseado em personalização e tecido selecionados
            if (selectedPersonalizacoes.length > 0 || document.getElementById('tecido').value) {
                const tecidoId = document.getElementById('tecido').value;
                items = items.filter(cor => {
                    // Se não tem parent_ids, mostrar sempre
                    if (!cor.parent_ids || cor.parent_ids.length === 0) {
                        return true;
                    }
                    
                    // Verificar se algum parent_id corresponde às personalizações selecionadas
                    const matchesPersonalizacao = selectedPersonalizacoes.length > 0 && 
                        cor.parent_ids.some(parentId => selectedPersonalizacoes.includes(parentId));
                    
                    // Verificar se algum parent_id corresponde ao tecido selecionado
                    const matchesTecido = tecidoId && cor.parent_ids.includes(parseInt(tecidoId));
                    
                    return matchesPersonalizacao || matchesTecido;
                });
            }
            
            const currentValue = select.value;
            select.innerHTML = '<option value="">Selecione a cor</option>' + 
                items.map(item => `<option value="${item.id}">${item.name}</option>`).join('');
            
            // Restaurar valor selecionado se ainda existir
            if (currentValue && items.find(item => item.id == currentValue)) {
                select.value = currentValue;
            } else {
                select.value = '';
            }
        }

        function renderTiposCorte() {
            const select = document.getElementById('tipo_corte');
            let items = optionsWithParents.tipo_corte || options.tipo_corte || [];
            
            // Filtrar tipo_corte baseado em personalização, tecido e tipo_tecido selecionados
            const tecidoId = document.getElementById('tecido').value;
            const tipoTecidoSelect = document.getElementById('tipo_tecido');
            const tipoTecidoId = tipoTecidoSelect ? tipoTecidoSelect.value : null;
            
            // Se não tem nenhuma seleção, mostrar TODOS os tipos de corte
            if (selectedPersonalizacoes.length === 0 && !tecidoId && !tipoTecidoId) {
                // Mostrar todos
            } else {
                // Filtrar baseado nas seleções
                items = items.filter(corte => {
                    // Se não tem parent_ids, mostrar sempre
                    if (!corte.parent_ids || corte.parent_ids.length === 0) {
                        return true;
                    }
                    
                    // Verificar se algum parent_id corresponde às personalizações selecionadas
                    const matchesPersonalizacao = selectedPersonalizacoes.length > 0 && 
                        corte.parent_ids.some(parentId => selectedPersonalizacoes.includes(parentId));
                    
                    // Verificar se algum parent_id corresponde ao tecido selecionado
                    const matchesTecido = tecidoId && corte.parent_ids.includes(parseInt(tecidoId));
                    
                    // Verificar se algum parent_id corresponde ao tipo_tecido selecionado
                    const matchesTipoTecido = tipoTecidoId && corte.parent_ids.includes(parseInt(tipoTecidoId));
                    
                    // Mostrar se corresponder a qualquer um dos critérios
                    return matchesPersonalizacao || matchesTecido || matchesTipoTecido;
                });
                
                // Se não tem itens após filtro, mostrar os sem parent_ids como fallback
                if (items.length === 0) {
                    const allItems = optionsWithParents.tipo_corte || options.tipo_corte || [];
                    items = allItems.filter(corte => !corte.parent_ids || corte.parent_ids.length === 0);
                }
            }
            
            const currentValue = select.value;
            select.innerHTML = '<option value="">Selecione o corte</option>' + 
                items.map(item => `<option value="${item.id}" data-price="${item.price}">${item.name} ${item.price > 0 ? '(+R$ ' + parseFloat(item.price).toFixed(2).replace('.', ',') + ')' : ''}</option>`).join('');
            
            // Restaurar valor selecionado se ainda existir
            if (currentValue && items.find(item => item.id == currentValue)) {
                select.value = currentValue;
            } else {
                select.value = '';
                // Se o tipo_corte mudou, atualizar detalhes e golas
                loadDetalhes();
                loadGolas();
            }
            
            updatePrice();
        }

        function renderDetalhes() {
            const select = document.getElementById('detalhe');
            let items = optionsWithParents.detalhe || options.detalhe || [];
            
            // Filtrar detalhes baseado em tipo_corte selecionado
            const tipoCorteId = document.getElementById('tipo_corte').value;
            if (tipoCorteId) {
                items = items.filter(detalhe => {
                    // Se não tem parent_ids, mostrar sempre
                    if (!detalhe.parent_ids || detalhe.parent_ids.length === 0) {
                        return true;
                    }
                    
                    // Verificar se algum parent_id corresponde ao tipo_corte selecionado
                    return detalhe.parent_ids.includes(parseInt(tipoCorteId));
                });
            } else {
                // Se não tem tipo_corte selecionado, mostrar apenas detalhes sem parent_ids
                items = items.filter(detalhe => !detalhe.parent_ids || detalhe.parent_ids.length === 0);
            }
            
            const currentValue = select.value;
            select.innerHTML = '<option value="">Selecione o detalhe</option>' + 
                items.map(item => `<option value="${item.id}" data-price="${item.price}">${item.name} ${item.price > 0 ? '(+R$ ' + parseFloat(item.price).toFixed(2).replace('.', ',') + ')' : ''}</option>`).join('');
            
            // Restaurar valor selecionado se ainda existir
            if (currentValue && items.find(item => item.id == currentValue)) {
                select.value = currentValue;
            } else {
                select.value = '';
            }
            
            updatePrice();
        }

        function loadDetalhes() {
            renderDetalhes();
            checkRestrictedSizes();
        }

        function renderGolas() {
            const select = document.getElementById('gola');
            let items = optionsWithParents.gola || options.gola || [];
            
            // Filtrar golas baseado em tipo_corte selecionado
            const tipoCorteId = document.getElementById('tipo_corte').value;
            if (tipoCorteId) {
                items = items.filter(gola => {
                    // Se não tem parent_ids, mostrar sempre
                    if (!gola.parent_ids || gola.parent_ids.length === 0) {
                        return true;
                    }
                    
                    // Verificar se algum parent_id corresponde ao tipo_corte selecionado
                    return gola.parent_ids.includes(parseInt(tipoCorteId));
                });
            } else {
                // Se não tem tipo_corte selecionado, mostrar apenas golas sem parent_ids
                items = items.filter(gola => !gola.parent_ids || gola.parent_ids.length === 0);
            }
            
            const currentValue = select.value;
            select.innerHTML = '<option value="">Selecione a gola</option>' + 
                items.map(item => `<option value="${item.id}" data-price="${item.price}">${item.name} ${item.price > 0 ? '(+R$ ' + parseFloat(item.price).toFixed(2).replace('.', ',') + ')' : ''}</option>`).join('');
            
            // Restaurar valor selecionado se ainda existir
            if (currentValue && items.find(item => item.id == currentValue)) {
                select.value = currentValue;
            } else {
                select.value = '';
            }
            
            updatePrice();
        }

        function loadGolas() {
            renderGolas();
        }

        function onTipoTecidoChange() {
            renderCores();
            renderTiposCorte();
        }

        function onTipoCorteChange() {
            loadDetalhes();
            loadGolas();
            updatePrice();
            loadStockByCutType();
            checkRestrictedSizes();
        }
        
        function checkRestrictedSizes() {
            const tipoCorteSelect = document.getElementById('tipo_corte');
            const detalheSelect = document.getElementById('detalhe');
            
            const tipoCorteText = tipoCorteSelect.options[tipoCorteSelect.selectedIndex]?.text || '';
            const detalheText = detalheSelect.options[detalheSelect.selectedIndex]?.text || '';
            
            const isRestricted = (tipoCorteText.toUpperCase().includes('INFANTIL') || tipoCorteText.toUpperCase().includes('BABY LOOK')) || 
                                 (detalheText.toUpperCase().includes('INFANTIL') || detalheText.toUpperCase().includes('BABY LOOK'));
            
            const restrictedInputs = document.querySelectorAll('.size-input-restricted');
            const surchargeCheckboxContainer = document.getElementById('surcharge-checkbox-container');
            const surchargeCheckbox = document.getElementById('apply_surcharge');
            
            if (isRestricted) {
                // Mostrar checkbox de acréscimo
                if (surchargeCheckboxContainer) {
                    surchargeCheckboxContainer.classList.remove('hidden');
                }
            } else {
                // Ocultar checkbox de acréscimo e desmarcar
                if (surchargeCheckboxContainer) {
                    surchargeCheckboxContainer.classList.add('hidden');
                }
                if (surchargeCheckbox) {
                    surchargeCheckbox.checked = false;
                }
            }
        }
        
        // Buscar estoque por tipo de corte
        async function loadStockByCutType() {
            const cutTypeId = document.getElementById('tipo_corte')?.value;
            const currentStoreId = <?php echo e($currentStoreId ?? 'null'); ?>;
            
            if (!cutTypeId || !currentStoreId) {
                const stockSection = document.getElementById('stock-info-section');
                if (stockSection) stockSection.classList.add('hidden');
                return;
            }
            
            try {
                const params = new URLSearchParams({
                    store_id: currentStoreId,
                    cut_type_id: cutTypeId
                });
                
                const response = await fetch(`/api/stocks/by-cut-type?${params}`);
                const data = await response.json();
                
                const stockSection = document.getElementById('stock-info-section');
                const stockBySize = document.getElementById('stock-by-size');
                
                if (data.success && data.stock_by_size && data.stock_by_size.length > 0) {
                    let html = '';
                    data.stock_by_size.forEach(item => {
                        const hasStock = item.available > 0;
                        const bgColor = hasStock ? 'bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800' : 'bg-gray-50 dark:bg-gray-700 border-gray-200 dark:border-gray-600';
                        const textColor = hasStock ? 'text-green-700 dark:text-green-300' : 'text-gray-500 dark:text-gray-400';
                        
                        html += `
                            <div class="flex items-center justify-between p-2 ${bgColor} rounded border">
                                <div>
                                    <span class="text-sm font-semibold text-gray-900 dark:text-gray-100">${item.size}:</span>
                                    <span class="text-sm ${textColor} ml-2">
                                        ${item.available} disponível
                                        ${item.reserved > 0 ? `(${item.reserved} reservado)` : ''}
                                    </span>
                                </div>
                                ${hasStock ? `
                                    <span class="px-2 py-1 text-xs font-semibold rounded-full bg-green-100 dark:bg-green-800 text-green-800 dark:text-green-200">
                                        ✓
                                    </span>
                                ` : `
                                    <span class="px-2 py-1 text-xs font-semibold rounded-full bg-red-100 dark:bg-red-800 text-red-800 dark:text-red-200">
                                        ✗
                                    </span>
                                `}
                            </div>
                        `;
                    });
                    
                    if (stockSection && stockBySize) {
                        stockSection.classList.remove('hidden');
                        stockBySize.innerHTML = html;
                    }
                } else {
                    if (stockSection) {
                        stockSection.classList.remove('hidden');
                        if (stockBySize) {
                            stockBySize.innerHTML = '<p class="text-sm text-yellow-600 dark:text-yellow-400 text-center py-2">⚠ Nenhum estoque cadastrado para este produto</p>';
                        }
                    }
                }
            } catch (error) {
                console.error('Erro ao buscar estoque:', error);
                const stockSection = document.getElementById('stock-info-section');
                if (stockSection) stockSection.classList.add('hidden');
            }
        }
        
        // Adicionar listeners para mudanças nos tamanhos
        document.addEventListener('DOMContentLoaded', function() {
            document.querySelectorAll('input[name^="tamanhos"]').forEach(input => {
                input.addEventListener('change', function() {
                    calculateTotal();
                });
            });
        });

        function updatePrice() {
            const corteSelect = document.getElementById('tipo_corte');
            const detalheSelect = document.getElementById('detalhe');
            const golaSelect = document.getElementById('gola');

            // Verificar se SUB. TOTAL está selecionado
            const isSubTotal = selectedPersonalizacoes.some(id => {
                const item = (options.personalizacao || []).find(p => p.id === id);
                return item && item.name && 
                       (item.name.toUpperCase().includes('SUB') && item.name.toUpperCase().includes('TOTAL'));
            });

            // Se SUB. TOTAL estiver selecionado, zerar todos os valores
            let cortePrice = 0;
            let detalhePrice = 0;
            let golaPrice = 0;

            if (!isSubTotal) {
                cortePrice = parseFloat(corteSelect.options[corteSelect.selectedIndex]?.dataset.price || 0);
                detalhePrice = parseFloat(detalheSelect.options[detalheSelect.selectedIndex]?.dataset.price || 0);
                golaPrice = parseFloat(golaSelect.options[golaSelect.selectedIndex]?.dataset.price || 0);
            }

            const total = cortePrice + detalhePrice + golaPrice;

            document.getElementById('price-corte').textContent = 'R$ ' + cortePrice.toFixed(2).replace('.', ',');
            document.getElementById('price-detalhe').textContent = 'R$ ' + detalhePrice.toFixed(2).replace('.', ',');
            document.getElementById('price-gola').textContent = 'R$ ' + golaPrice.toFixed(2).replace('.', ',');
            document.getElementById('price-total').textContent = 'R$ ' + total.toFixed(2).replace('.', ',');
            
            document.getElementById('unit_price').value = total.toFixed(2);
        }

        function calculateTotal() {
            const inputs = document.querySelectorAll('input[name^="tamanhos"]');
            let total = 0;
            
            inputs.forEach(input => {
                total += parseInt(input.value) || 0;
            });
            
            document.getElementById('total-pecas').textContent = total;
            document.getElementById('quantity').value = total;
        }
        
        // Função antiga removida - agora usamos loadStockByCutType() que busca automaticamente
        // Mantida apenas para compatibilidade se houver outras referências
        async function checkStockForAllSizes() {
            const fabricId = document.getElementById('tecido')?.value;
            const colorId = document.getElementById('cor')?.value;
            const cutTypeId = document.getElementById('tipo_corte')?.value;
            const currentStoreId = <?php echo e($currentStoreId ?? 'null'); ?>;
            
            const stockInfoSection = document.getElementById('stock-info-section');
            const stockBySize = document.getElementById('stock-by-size');
            
            // Verificar se todos os campos necessários estão preenchidos
            if (!fabricId || !colorId || !cutTypeId || !currentStoreId) {
                if (stockInfoSection) stockInfoSection.classList.add('hidden');
                return;
            }
            
            const sizes = ['PP', 'P', 'M', 'G', 'GG', 'EXG', 'G1', 'G2', 'G3'];
            let stockHtml = '';
            let hasAnyStock = false;
            
            for (const size of sizes) {
                const sizeInput = document.querySelector(`input[name="tamanhos[${size}]"]`);
                const quantity = parseInt(sizeInput?.value || 0);
                
                if (quantity > 0) {
                    try {
                        const params = new URLSearchParams({
                            store_id: currentStoreId,
                            fabric_id: fabricId,
                            color_id: colorId,
                            cut_type_id: cutTypeId,
                            size: size,
                            quantity: quantity
                        });
                        
                        const response = await fetch(`/api/stocks/check?${params}`);
                        const data = await response.json();
                        
                        if (data.success) {
                            const available = data.available_quantity || 0;
                            const hasStock = data.has_stock || false;
                            hasAnyStock = true;
                            
                            if (hasStock) {
                                stockHtml += `
                                    <div class="flex items-center justify-between p-2 bg-green-50 dark:bg-green-900/20 rounded border border-green-200 dark:border-green-800">
                                        <span class="text-sm text-gray-700 dark:text-gray-300">${size}:</span>
                                        <span class="text-sm font-semibold text-green-600 dark:text-green-400">${available} disponível</span>
                                    </div>
                                `;
                            } else {
                                stockHtml += `
                                    <div class="flex items-center justify-between p-2 bg-red-50 dark:bg-red-900/20 rounded border border-red-200 dark:border-red-800">
                                        <span class="text-sm text-gray-700 dark:text-gray-300">${size}:</span>
                                        <span class="text-sm font-semibold text-red-600 dark:text-red-400">${available} disponível (insuficiente)</span>
                                        <button type="button" onclick="createStockRequestForSize('${size}', ${quantity})" class="text-xs text-blue-600 dark:text-blue-400 underline ml-2">
                                            Solicitar
                                        </button>
                                    </div>
                                `;
                            }
                        }
                    } catch (error) {
                        console.error(`Erro ao verificar estoque para ${size}:`, error);
                    }
                }
            }
            
            if (hasAnyStock && stockInfoSection && stockBySize) {
                stockInfoSection.classList.remove('hidden');
                stockBySize.innerHTML = stockHtml || '<p class="text-sm text-gray-500">Nenhum tamanho selecionado</p>';
            } else {
                if (stockInfoSection) stockInfoSection.classList.add('hidden');
            }
        }
        
        // Criar solicitação de estoque para um tamanho específico
        async function createStockRequestForSize(size, quantity) {
            const fabricId = document.getElementById('tecido')?.value;
            const colorId = document.getElementById('cor')?.value;
            const cutTypeId = document.getElementById('tipo_corte')?.value;
            const currentStoreId = <?php echo e($currentStoreId ?? 'null'); ?>;
            
            if (!fabricId || !colorId || !cutTypeId || !currentStoreId) {
                alert('Preencha todos os campos de especificação');
                return;
            }
            
            const fabricName = document.getElementById('tecido')?.selectedOptions[0]?.text || 'Tecido';
            const colorName = document.getElementById('cor')?.selectedOptions[0]?.text || 'Cor';
            const cutTypeName = document.getElementById('tipo_corte')?.selectedOptions[0]?.text || 'Tipo de Corte';
            
            if (!confirm(`Deseja criar uma solicitação de estoque para:\n\nTecido: ${fabricName}\nCor: ${colorName}\nTipo de Corte: ${cutTypeName}\nTamanho: ${size}\nQuantidade: ${quantity} unidade(s)?`)) {
                return;
            }
            
            try {
                const response = await fetch('/stock-requests', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
                    },
                    body: JSON.stringify({
                        requesting_store_id: currentStoreId,
                        fabric_id: fabricId,
                        color_id: colorId,
                        cut_type_id: cutTypeId,
                        size: size,
                        requested_quantity: quantity,
                        request_notes: `Solicitação criada automaticamente do wizard de pedidos - Quantidade necessária: ${quantity}`
                    })
                });
                
                const data = await response.json();
                
                if (data.success) {
                    alert('Solicitação de estoque criada com sucesso!');
                    // Atualizar informações de estoque
                    checkStockForAllSizes();
                } else {
                    alert('Erro ao criar solicitação: ' + (data.message || 'Erro desconhecido'));
                }
            } catch (error) {
                console.error('Erro ao criar solicitação:', error);
                alert('Erro ao criar solicitação de estoque');
            }
        }

        document.getElementById('sewing-form').addEventListener('submit', function(e) {
            const checkboxes = document.querySelectorAll('.personalizacao-checkbox');
            const checkedCount = Array.from(checkboxes).filter(cb => cb.checked).length;
            
            if (checkedCount === 0) {
                e.preventDefault();
                alert('Por favor, selecione pelo menos uma personalização.');
                return false;
            }

            const quantity = parseInt(document.getElementById('quantity').value);
            if (quantity === 0) {
                e.preventDefault();
                alert('Por favor, adicione pelo menos uma peça nos tamanhos.');
                return false;
            }
            
            return true;
        });

        const itemsData = <?php echo json_encode($order->items->toArray()); ?>;

        function editItem(itemId) {
            const itemData = itemsData.find(item => item.id == itemId);
            
            if (!itemData) {
                alert('Item não encontrado');
                return;
            }

            document.getElementById('editing-item-id').value = itemId;
            document.getElementById('form-action').value = 'update_item';
            document.getElementById('form-title').textContent = 'Editar Item ' + itemData.item_number;
            document.getElementById('submit-button').innerHTML = 'Salvar Alterações';

            const personalizacoes = itemData.print_type.split(', ');
            document.querySelectorAll('.personalizacao-checkbox').forEach(checkbox => {
                checkbox.checked = personalizacoes.includes(checkbox.value);
            });

            document.getElementById('tecido').value = itemData.fabric;
            loadTiposTecido();

            setTimeout(() => {
                if (itemData.tipo_tecido) {
                    document.getElementById('tipo_tecido').value = itemData.tipo_tecido;
                }
            }, 500);

            document.getElementById('cor').value = itemData.color;

            if (itemData.model) {
                document.getElementById('tipo_corte').value = itemData.model;
            }

            if (itemData.detail) {
                document.getElementById('detalhe').value = itemData.detail;
            }

            document.getElementById('gola').value = itemData.collar;

            const sizeInputs = document.querySelectorAll('input[name^="tamanhos"]');
            sizeInputs.forEach(input => input.value = 0);
            
            if (itemData.sizes && typeof itemData.sizes === 'object') {
                Object.entries(itemData.sizes).forEach(([size, qty]) => {
                    const input = document.querySelector(`input[name="tamanhos[${size}]"]`);
                    if (input) {
                        input.value = qty || 0;
                    }
                });
            }

            document.getElementById('unit_price').value = itemData.unit_price;

            // Restaurar estado do checkbox de acréscimo
            const surchargeCheckbox = document.getElementById('apply_surcharge');
            if (surchargeCheckbox && itemData.print_desc) {
                try {
                    const printDesc = JSON.parse(itemData.print_desc);
                    surchargeCheckbox.checked = !!printDesc.apply_surcharge;
                } catch (e) {
                    console.error('Erro ao parsing print_desc:', e);
                    surchargeCheckbox.checked = false;
                }
            } else if (surchargeCheckbox) {
                surchargeCheckbox.checked = false;
            }

            updatePrice();
            calculateTotal();
            checkRestrictedSizes();

            document.getElementById('sewing-form').scrollIntoView({ behavior: 'smooth' });
        }

        function cancelEdit() {
            document.getElementById('editing-item-id').value = '';
            document.getElementById('form-action').value = 'add_item';
            document.getElementById('form-title').textContent = 'Adicionar Novo Item';
            document.getElementById('submit-button').innerHTML = 'Adicionar Item';
            
            document.getElementById('sewing-form').reset();
            
            document.querySelectorAll('.personalizacao-checkbox').forEach(checkbox => {
                checkbox.checked = false;
            });
        }

        <?php if(isset($editData)): ?>
        document.addEventListener('DOMContentLoaded', function() {
            const submitButton = document.getElementById('submit-button');
            const cancelButton = document.createElement('button');
            cancelButton.type = 'button';
            cancelButton.className = 'px-4 py-2 bg-gray-500 hover:bg-gray-600 text-white font-semibold rounded-lg';
            cancelButton.innerHTML = 'Cancelar Edição';
            cancelButton.onclick = cancelEdit;
            
            submitButton.parentNode.insertBefore(cancelButton, submitButton.nextSibling);
        });
        <?php endif; ?>
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home2/dd173158/laravel/resources/views/orders/wizard/sewing.blade.php ENDPATH**/ ?>