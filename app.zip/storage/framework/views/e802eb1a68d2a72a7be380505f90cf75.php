

<?php $__env->startSection('content'); ?>
<div class="max-w-5xl mx-auto px-4 py-6">
        <?php if(session('success')): ?>
        <div class="mb-6 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-600/30 text-green-700 dark:text-green-300 px-4 py-3 rounded-md">
            <?php echo e(session('success')); ?>

        </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
        <div class="mb-6 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-600/30 text-red-700 dark:text-red-300 px-4 py-3 rounded-md">
            <?php echo e(session('error')); ?>

        </div>
        <?php endif; ?>

        <!-- Header -->
        <div class="mb-6 flex items-center justify-between">
            <div>
                <h1 class="text-2xl font-bold text-gray-900 dark:text-gray-100">
                    Orçamento #<?php echo e($budget->budget_number); ?>

                    <?php if($budget->order_number): ?>
                    <span class="text-lg text-indigo-600 dark:text-indigo-400">→ Pedido #<?php echo e($budget->order_number); ?></span>
                    <?php endif; ?>
                </h1>
                <p class="text-sm text-gray-600 dark:text-gray-400 mt-1">
                    Criado em <?php echo e($budget->created_at->format('d/m/Y H:i')); ?>

                </p>
            </div>
            <div class="flex items-center space-x-3">
                <span class="px-3 py-1 text-sm rounded-full
                    <?php if($budget->status === 'pending'): ?> bg-yellow-100 dark:bg-yellow-900/30 text-yellow-700 dark:text-yellow-400
                    <?php elseif($budget->status === 'approved'): ?> bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400
                    <?php elseif($budget->status === 'rejected'): ?> bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-400
                    <?php endif; ?>">
                    <?php if($budget->status === 'pending'): ?> Pendente
                    <?php elseif($budget->status === 'approved'): ?> Aprovado
                    <?php elseif($budget->status === 'rejected'): ?> Rejeitado
                    <?php endif; ?>
                </span>
                <a href="<?php echo e(route('budget.pdf', $budget->id)); ?>" 
                   class="px-4 py-2 bg-indigo-600 dark:bg-indigo-600 text-white rounded-md hover:bg-indigo-700 dark:hover:bg-indigo-700 text-sm font-medium inline-flex items-center gap-2">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z"/>
                    </svg>
                    Baixar PDF
                </a>
            </div>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <!-- Coluna Principal -->
            <div class="lg:col-span-2 space-y-6">
                <!-- Cliente -->
                <div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm dark:shadow-gray-900/25 border border-gray-200 dark:border-gray-700 p-6">
                    <h2 class="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">Cliente</h2>
                    <div class="space-y-2 text-sm">
                        <div class="flex justify-between">
                            <span class="text-gray-600 dark:text-gray-400">Nome:</span>
                            <span class="font-medium text-gray-900 dark:text-gray-100"><?php echo e($budget->client->name); ?></span>
                        </div>
                        <div class="flex justify-between">
                            <span class="text-gray-600 dark:text-gray-400">Telefone:</span>
                            <span class="font-medium text-gray-900 dark:text-gray-100"><?php echo e($budget->client->phone_primary); ?></span>
                        </div>
                        <?php if($budget->client->email): ?>
                        <div class="flex justify-between">
                            <span class="text-gray-600 dark:text-gray-400">Email:</span>
                            <span class="font-medium text-gray-900 dark:text-gray-100"><?php echo e($budget->client->email); ?></span>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Personalizações -->
                <?php
                    $allCustomizations = $budget->items->flatMap(function($item) {
                        return $item->customizations;
                    });
                ?>
                <?php if($allCustomizations->count() > 0): ?>
                <div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm dark:shadow-gray-900/25 border border-gray-200 dark:border-gray-700 p-6">
                    <h2 class="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">Personalizações</h2>
                    <div class="space-y-2">
                        <?php $__currentLoopData = $allCustomizations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $custom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="bg-indigo-50 dark:bg-indigo-900/20 rounded-md p-3 border border-indigo-100 dark:border-indigo-800">
                            <div class="flex items-center justify-between">
                                <div class="flex-1 space-y-3">
                                    <div class="grid grid-cols-5 gap-3 text-sm">
                                        <div>
                                            <span class="text-gray-600 dark:text-gray-400 text-xs">Tipo:</span>
                                            <p class="font-medium text-indigo-700 dark:text-indigo-300"><?php echo e($custom->personalization_type ?? 'N/A'); ?></p>
                                        </div>
                                        <div>
                                            <span class="text-gray-600 dark:text-gray-400 text-xs">Localização:</span>
                                            <p class="font-medium text-gray-900 dark:text-gray-100"><?php echo e($custom->location); ?></p>
                                        </div>
                                        <div>
                                            <span class="text-gray-600 dark:text-gray-400 text-xs">Tamanho:</span>
                                            <p class="font-medium text-gray-900 dark:text-gray-100"><?php echo e($custom->size); ?></p>
                                        </div>
                                        <div>
                                            <span class="text-gray-600 dark:text-gray-400 text-xs">Quantidade:</span>
                                            <p class="font-medium text-gray-900 dark:text-gray-100"><?php echo e($custom->quantity ?? 0); ?> peças</p>
                                        </div>
                                        <?php if(in_array($custom->personalization_type, ['SERIGRAFIA', 'EMBORRACHADO'])): ?>
                                        <div>
                                            <span class="text-gray-600 dark:text-gray-400 text-xs">Cores:</span>
                                            <p class="font-medium text-gray-900 dark:text-gray-100"><?php echo e($custom->color_count ?? 1); ?> <?php echo e(($custom->color_count ?? 1) > 1 ? 'aplicações' : 'aplicação'); ?></p>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <!-- Breakdown de valores -->
                                    <div class="bg-gray-50 dark:bg-gray-700/50 rounded p-2 text-xs space-y-1">
                                        <div class="flex justify-between">
                                            <span class="text-gray-600 dark:text-gray-400">Valor unitário:</span>
                                            <span class="text-gray-900 dark:text-gray-100 font-medium">R$ <?php echo e(number_format($custom->unit_price, 2, ',', '.')); ?></span>
                                        </div>
                                        <?php if(in_array($custom->personalization_type, ['SERIGRAFIA', 'EMBORRACHADO']) && ($custom->color_count ?? 1) > 1): ?>
                                        <div class="flex justify-between">
                                            <span class="text-gray-500 dark:text-gray-400">Com <?php echo e($custom->color_count); ?> cores<?php echo e(($custom->color_count ?? 1) >= 3 ? ' (desconto na 3ª+)' : ''); ?></span>
                                        </div>
                                        <?php endif; ?>
                                        <div class="flex justify-between pt-1 border-t border-gray-200 dark:border-gray-600">
                                            <span class="text-gray-700 dark:text-gray-300 font-medium">Total:</span>
                                            <span class="text-indigo-600 dark:text-indigo-400 font-bold">R$ <?php echo e(number_format($custom->total_price, 2, ',', '.')); ?></span>
                                        </div>
                                        <div class="text-gray-500 dark:text-gray-400 italic">
                                            (R$ <?php echo e(number_format($custom->unit_price, 2, ',', '.')); ?> × <?php echo e($custom->quantity ?? 0); ?> peças)
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Itens -->
                <div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm dark:shadow-gray-900/25 border border-gray-200 dark:border-gray-700 p-6">
                    <h2 class="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">Itens do Orçamento</h2>
                    <div class="space-y-4">
                        <?php $__currentLoopData = $budget->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $personalizationTypes = json_decode($item->personalization_types, true) ?? [];
                            $itemQuantity = $item->quantity;
                            $itemUnitPrice = $personalizationTypes['unit_price'] ?? 0;
                            $itemTotal = $item->item_total;
                            
                            // Calcular total de personalizações deste item
                            $itemPersonalizationsTotal = $item->customizations->sum('total_price');
                            
                            // Calcular valor unitário com personalização
                            $personalizationPerPiece = $itemQuantity > 0 ? ($itemPersonalizationsTotal / $itemQuantity) : 0;
                            $unitPriceWithPersonalization = $itemUnitPrice + $personalizationPerPiece;
                            
                            // Total geral do item
                            $itemGrandTotal = $itemTotal + $itemPersonalizationsTotal;
                        ?>
                        <div class="border border-gray-200 dark:border-gray-700 rounded-md p-4">
                            <div class="flex justify-between items-start mb-3">
                                <div class="flex items-center space-x-2">
                                    <div class="w-6 h-6 bg-indigo-100 dark:bg-indigo-900/30 rounded-md flex items-center justify-center">
                                        <span class="text-xs font-medium text-indigo-600 dark:text-indigo-400"><?php echo e($item->item_number); ?></span>
                                    </div>
                                    <h3 class="font-medium text-gray-900 dark:text-gray-100"><?php echo e($personalizationTypes['print_type'] ?? 'Item ' . $item->item_number); ?></h3>
                                </div>
                            </div>
                            <div class="grid grid-cols-2 gap-3 text-xs mb-3">
                                <div>
                                    <span class="text-gray-600 dark:text-gray-400">Tecido:</span>
                                    <span class="font-medium text-gray-900 dark:text-gray-100 block"><?php echo e($item->fabric); ?></span>
                                </div>
                                <div>
                                    <span class="text-gray-600 dark:text-gray-400">Cor:</span>
                                    <span class="font-medium text-gray-900 dark:text-gray-100 block"><?php echo e($item->color); ?></span>
                                </div>
                                <?php if(!empty($personalizationTypes['model'])): ?>
                                <div>
                                    <span class="text-gray-600 dark:text-gray-400">Modelo:</span>
                                    <span class="font-medium text-gray-900 dark:text-gray-100 block"><?php echo e($personalizationTypes['model']); ?></span>
                                </div>
                                <?php endif; ?>
                                <?php if(!empty($personalizationTypes['collar'])): ?>
                                <div>
                                    <span class="text-gray-600 dark:text-gray-400">Gola:</span>
                                    <span class="font-medium text-gray-900 dark:text-gray-100 block"><?php echo e($personalizationTypes['collar']); ?></span>
                                </div>
                                <?php endif; ?>
                                <?php if(!empty($personalizationTypes['detail'])): ?>
                                <div>
                                    <span class="text-gray-600 dark:text-gray-400">Detalhe:</span>
                                    <span class="font-medium text-gray-900 dark:text-gray-100 block"><?php echo e($personalizationTypes['detail']); ?></span>
                                </div>
                                <?php endif; ?>
                                <div>
                                    <span class="text-gray-600 dark:text-gray-400">Quantidade:</span>
                                    <span class="font-medium text-gray-900 dark:text-gray-100 block"><?php echo e($itemQuantity); ?> peças</span>
                                </div>
                            </div>

                            <!-- Breakdown de Valores -->
                            <div class="mt-3 pt-3 border-t border-gray-200 dark:border-gray-600">
                                <div class="space-y-2 text-xs">
                                    <div class="flex justify-between">
                                        <span class="text-gray-600 dark:text-gray-400">Costura (unitário):</span>
                                        <span class="font-medium text-gray-900 dark:text-gray-100">R$ <?php echo e(number_format($itemUnitPrice, 2, ',', '.')); ?></span>
                                    </div>
                                    <div class="flex justify-between">
                                        <span class="text-gray-600 dark:text-gray-400">Costura (total):</span>
                                        <span class="font-medium text-gray-900 dark:text-gray-100">R$ <?php echo e(number_format($itemTotal, 2, ',', '.')); ?></span>
                                    </div>
                                    
                                    <?php if($itemPersonalizationsTotal > 0): ?>
                                    <div class="flex justify-between text-indigo-600 dark:text-indigo-400">
                                        <span>Personalização (unitário):</span>
                                        <span class="font-medium">R$ <?php echo e(number_format($personalizationPerPiece, 2, ',', '.')); ?></span>
                                    </div>
                                    <div class="flex justify-between text-indigo-600 dark:text-indigo-400">
                                        <span>Personalização (total):</span>
                                        <span class="font-medium">R$ <?php echo e(number_format($itemPersonalizationsTotal, 2, ',', '.')); ?></span>
                                    </div>
                                    <div class="flex justify-between pt-2 border-t border-gray-200 dark:border-gray-600">
                                        <span class="font-semibold text-gray-900 dark:text-gray-100">Unitário Total:</span>
                                        <span class="font-bold text-green-600 dark:text-green-400">R$ <?php echo e(number_format($unitPriceWithPersonalization, 2, ',', '.')); ?></span>
                                    </div>
                                    <?php endif; ?>
                                    
                                    <div class="flex justify-between pt-2 border-t border-gray-300 dark:border-gray-500">
                                        <span class="font-bold text-gray-900 dark:text-gray-100">TOTAL DO ITEM:</span>
                                        <span class="font-bold text-lg text-indigo-600 dark:text-indigo-400">R$ <?php echo e(number_format($itemGrandTotal, 2, ',', '.')); ?></span>
                                    </div>
                                </div>
                            </div>

                            <?php if(!empty($personalizationTypes['notes'])): ?>
                            <div class="mt-3 pt-3 border-t border-gray-200 dark:border-gray-600">
                                <span class="text-xs text-gray-600 dark:text-gray-400">Observações:</span>
                                <p class="text-xs text-gray-900 dark:text-gray-100 mt-1"><?php echo e($personalizationTypes['notes']); ?></p>
                            </div>
                            <?php endif; ?>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

                <?php if($budget->observations): ?>
                <!-- Observações -->
                <div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm dark:shadow-gray-900/25 border border-gray-200 dark:border-gray-700 p-6">
                    <h2 class="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-3">Observações Gerais</h2>
                    <p class="text-sm text-gray-700 dark:text-gray-300"><?php echo e($budget->observations); ?></p>
                </div>
                <?php endif; ?>

                <?php if($budget->admin_notes): ?>
                <!-- Observações do Vendedor -->
                <div class="bg-yellow-50 dark:bg-yellow-900/20 rounded-lg shadow-sm border border-yellow-200 dark:border-yellow-800 p-6">
                    <h2 class="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-3 flex items-center">
                        <span class="text-xl mr-2">📌</span>
                        Observações do Vendedor
                    </h2>
                    <div class="text-sm text-gray-700 dark:text-gray-300 whitespace-pre-line"><?php echo e($budget->admin_notes); ?></div>
                    <p class="text-xs text-yellow-700 dark:text-yellow-400 mt-3 italic">
                        Acréscimo GG/EXG, Prazo, Pagamento, etc.
                    </p>
                </div>
                <?php endif; ?>
            </div>

            <!-- Sidebar -->
            <div class="space-y-6">
                <!-- Resumo Financeiro -->
                <?php
                    $itemsSubtotal = $budget->items->sum('item_total');
                    $customizationsSubtotal = $budget->items->flatMap(fn($item) => $item->customizations)->sum('total_price');
                ?>
                <div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm dark:shadow-gray-900/25 border border-gray-200 dark:border-gray-700 p-6">
                    <h2 class="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">Resumo Financeiro</h2>
                    <div class="space-y-3">
                        <div class="flex justify-between text-sm">
                            <span class="text-gray-600 dark:text-gray-400">Subtotal Itens:</span>
                            <span class="font-medium text-gray-900 dark:text-gray-100">R$ <?php echo e(number_format($itemsSubtotal, 2, ',', '.')); ?></span>
                        </div>
                        <?php if($customizationsSubtotal > 0): ?>
                        <div class="flex justify-between text-sm">
                            <span class="text-gray-600 dark:text-gray-400">Personalizações:</span>
                            <span class="font-medium text-indigo-600 dark:text-indigo-400">R$ <?php echo e(number_format($customizationsSubtotal, 2, ',', '.')); ?></span>
                        </div>
                        <?php endif; ?>
                        <?php if($budget->discount > 0): ?>
                        <div class="flex justify-between text-sm">
                            <span class="text-gray-600 dark:text-gray-400">Desconto:</span>
                            <span class="font-medium text-red-600 dark:text-red-400">
                                - R$ <?php echo e(number_format($budget->discount, 2, ',', '.')); ?>

                            </span>
                        </div>
                        <?php endif; ?>
                        <div class="pt-3 border-t border-gray-200 dark:border-gray-700">
                            <div class="flex justify-between">
                                <span class="text-base font-semibold text-gray-900 dark:text-gray-100">Valor Total:</span>
                                <span class="text-xl font-bold text-indigo-600 dark:text-indigo-400">
                                    R$ <?php echo e(number_format($budget->total, 2, ',', '.')); ?>

                                </span>
                            </div>
                        </div>
                        <p class="text-xs text-gray-500 dark:text-gray-400 mt-3 text-center bg-gray-100 dark:bg-gray-700 rounded py-2">
                            Válido até <?php echo e(\Carbon\Carbon::parse($budget->valid_until)->format('d/m/Y')); ?>

                        </p>
                    </div>
                </div>

                <!-- Informações -->
                <div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm dark:shadow-gray-900/25 border border-gray-200 dark:border-gray-700 p-6">
                    <h2 class="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">Informações</h2>
                    <div class="space-y-3 text-sm">
                        <div>
                            <span class="text-gray-600 dark:text-gray-400">Criado por:</span>
                            <p class="font-medium text-gray-900 dark:text-gray-100 mt-1"><?php echo e($budget->user->name); ?></p>
                        </div>
                        <div>
                            <span class="text-gray-600 dark:text-gray-400">Data de criação:</span>
                            <p class="font-medium text-gray-900 dark:text-gray-100 mt-1"><?php echo e($budget->created_at->format('d/m/Y H:i')); ?></p>
                        </div>
                        <div>
                            <span class="text-gray-600 dark:text-gray-400">Última atualização:</span>
                            <p class="font-medium text-gray-900 dark:text-gray-100 mt-1"><?php echo e($budget->updated_at->format('d/m/Y H:i')); ?></p>
                        </div>
                    </div>
                </div>

                <!-- Ações -->
                <div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm dark:shadow-gray-900/25 border border-gray-200 dark:border-gray-700 p-6">
                    <h2 class="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">Ações</h2>
                    <div class="space-y-3">
                        <?php if($budget->status === 'pending'): ?>
                        <form action="<?php echo e(route('budget.approve', $budget->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <button type="submit"
                                    class="flex items-center justify-center gap-2 w-full px-4 py-2 bg-green-600 dark:bg-green-600 text-white text-center rounded-md hover:bg-green-700 dark:hover:bg-green-700 text-sm font-medium transition-colors">
                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/>
                                </svg>
                                Aprovar Orçamento
                            </button>
                        </form>
                        
                        <form action="<?php echo e(route('budget.reject', $budget->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <button type="submit"
                                    onclick="return confirm('Tem certeza que deseja rejeitar este orçamento?')"
                                    class="flex items-center justify-center gap-2 w-full px-4 py-2 bg-red-600 dark:bg-red-600 text-white text-center rounded-md hover:bg-red-700 dark:hover:bg-red-700 text-sm font-medium transition-colors">
                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                                </svg>
                                Rejeitar Orçamento
                            </button>
                        </form>
                        <?php endif; ?>
                        
                        <?php if($budget->status === 'approved'): ?>
                        <a href="<?php echo e(route('budget.convert-to-order', $budget->id)); ?>"
                           class="flex items-center justify-center gap-2 w-full px-4 py-2 bg-blue-600 dark:bg-blue-600 text-white text-center rounded-md hover:bg-blue-700 dark:hover:bg-blue-700 text-sm font-medium transition-colors">
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/>
                            </svg>
                            Converter em Pedido
                        </a>
                        <?php endif; ?>
                        
                        <?php if(!Auth::user()->isAdmin()): ?>
                        <form action="<?php echo e(route('budget.request-edit', $budget->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <button type="submit"
                                    class="flex items-center justify-center gap-2 w-full px-4 py-2 bg-orange-500 dark:bg-orange-500 text-white text-center rounded-md hover:bg-orange-600 dark:hover:bg-orange-600 text-sm font-medium transition-colors">
                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/>
                                </svg>
                                Solicitar Edição
                            </button>
                        </form>
                        <?php endif; ?>

                        <a href="<?php echo e(route('budget.index')); ?>" 
                           class="flex items-center justify-center gap-2 w-full px-4 py-2 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 text-center rounded-md hover:bg-gray-200 dark:hover:bg-gray-600 text-sm font-medium transition-colors">
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/>
                            </svg>
                            Voltar para Lista
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home2/dd173158/laravel/resources/views/budgets/show.blade.php ENDPATH**/ ?>