<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

class User extends Authenticatable
{
    /** @use HasFactory<\Database\Factories\UserFactory> */
    use HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var list<string>
     */
    protected $fillable = [
        'name',
        'email',
        'password',
        'role',
        'store',
        'store_name',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var list<string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * Get the attributes that should be cast.
     *
     * @return array<string, string>
     */
    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password' => 'hashed',
        ];
    }

    /**
     * Lojas que o usuário administra
     */
    public function stores(): BelongsToMany
    {
        return $this->belongsToMany(Store::class, 'store_user')
                    ->withPivot('role')
                    ->withTimestamps();
    }

    /**
     * Verificar se é admin geral
     */
    public function isAdminGeral(): bool
    {
        return $this->role === 'admin_geral' || $this->role === 'admin';
    }

    /**
     * Verificar se é admin de loja
     */
    public function isAdminLoja(): bool
    {
        return $this->role === 'admin_loja'
            || $this->stores()->wherePivot('role', 'admin_loja')->exists();
    }

    /**
     * Verificar se é admin (geral ou loja)
     */
    public function isAdmin(): bool
    {
        return $this->isAdminGeral() || $this->isAdminLoja() || $this->role === 'admin';
    }

    /**
     * Verificar se é vendedor
     */
    public function isVendedor(): bool
    {
        return $this->role === 'vendedor';
    }

    /**
     * Verificar se é usuário de produção
     */
    public function isProducao(): bool
    {
        return $this->role === 'producao';
    }

    /**
     * Verificar se é usuário de caixa
     */
    public function isCaixa(): bool
    {
        return $this->role === 'caixa';
    }

    /**
     * Verificar se é usuário de estoque
     */
    public function isEstoque(): bool
    {
        return $this->role === 'estoque';
    }

    /**
     * Obter IDs das lojas que o usuário pode acessar (incluindo sub-lojas)
     */
    public function getStoreIds(): array
    {
        if ($this->isAdminGeral() || $this->isEstoque()) {
            // Admin geral e estoque vêem todas as lojas
            return Store::active()->pluck('id')->toArray();
        }

        if ($this->isAdminLoja()) {
            // Admin loja vê suas lojas + sub-lojas
            $storeIds = [];
            
            foreach ($this->stores as $store) {
                $storeIds = array_merge($storeIds, $store->getAllStoreIds());
            }
            
            return array_unique($storeIds);
        }

        // Vendedor não tem acesso por loja, apenas por user_id
        return [];
    }

    /**
     * Verificar se o usuário pode acessar uma loja específica
     */
    public function canAccessStore($storeId): bool
    {
        if ($this->isAdminGeral() || $this->isEstoque()) {
            return true;
        }

        if ($this->isAdminLoja()) {
            $storeIds = $this->getStoreIds();
            return in_array($storeId, $storeIds);
        }

        return false;
    }
    /**
     * Get the role label.
     */
    public function getRoleLabelAttribute(): string
    {
        $roleNames = [
            'admin' => 'Administrador',
            'admin_geral' => 'Admin Geral',
            'admin_loja' => 'Admin de Loja',
            'vendedor' => 'Vendedor',
            'producao' => 'Produção',
            'caixa' => 'Caixa',
            'estoque' => 'Estoque',
        ];

        return $roleNames[$this->role] ?? ucfirst($this->role);
    }

    /**
     * Get the role color class.
     */
    public function getRoleColorAttribute(): string
    {
        $roleColors = [
            'admin' => 'bg-purple-100 dark:bg-purple-900/30 text-purple-800 dark:text-purple-300',
            'admin_geral' => 'bg-purple-100 dark:bg-purple-900/30 text-purple-800 dark:text-purple-300',
            'admin_loja' => 'bg-indigo-100 dark:bg-indigo-900/30 text-indigo-800 dark:text-indigo-300',
            'vendedor' => 'bg-blue-100 dark:bg-blue-900/30 text-blue-800 dark:text-blue-300',
            'producao' => 'bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-300',
        ];

        return $roleColors[$this->role] ?? 'bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-300';
    }
}
