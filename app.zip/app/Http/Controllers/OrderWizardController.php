<?php

namespace App\Http\Controllers;

use App\Models\Client;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Payment;
use App\Models\Status;
use App\Models\CashTransaction;
use App\Models\Store;
use App\Models\SizeSurcharge;
use App\Helpers\DateHelper;
use App\Helpers\StoreHelper;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Arr;
use Carbon\Carbon;
use App\Services\ImageProcessor;

class OrderWizardController extends Controller
{
    public function __construct(private readonly ImageProcessor $imageProcessor)
    {
    }

    public function start(Request $request): View
    {
        return view('orders.wizard.client');
    }

    public function storeClient(Request $request): RedirectResponse
    {
        \Log::info('=== STORE CLIENT DEBUG START ===');
        \Log::info('Request method:', ['method' => $request->method()]);
        \Log::info('Request data:', $request->all());
        \Log::info('User authenticated:', ['auth' => auth()->check(), 'user_id' => auth()->id()]);
        
        try {
            $validated = $request->validate([
            'client_id' => 'nullable|exists:clients,id',
            'name' => 'required|string|max:255',
            'phone_primary' => 'required|string|max:50',
            'phone_secondary' => 'nullable|string|max:50',
            'email' => 'nullable|email|max:255',
            'cpf_cnpj' => 'nullable|string|max:20',
            'address' => 'nullable|string|max:255',
            'city' => 'nullable|string|max:100',
            'state' => 'nullable|string|max:2',
            'zip_code' => 'nullable|string|max:12',
            'category' => 'nullable|string|max:50',
        ]);

        // Obter store_id do usuário (primeira loja ou loja principal)
        $user = Auth::user();
        $storeId = null;
        
        if ($user->isAdminLoja()) {
            $storeIds = $user->getStoreIds();
            $storeId = !empty($storeIds) ? $storeIds[0] : null;
        } elseif ($user->isVendedor()) {
            // Vendedor: buscar loja associada através da tabela store_user ou campo store
            $userStores = $user->stores()->get();
            if ($userStores->isNotEmpty()) {
                // Se tem loja associada na tabela store_user, usar a primeira
                $storeId = $userStores->first()->id;
            } elseif ($user->store) {
                // Se tem campo store (string), tentar buscar pelo nome
                $store = Store::where('name', 'like', '%' . $user->store . '%')->first();
                if ($store) {
                    $storeId = $store->id;
                }
            }
            
            // Se ainda não encontrou, usar loja principal
            if (!$storeId) {
                $mainStore = Store::where('is_main', true)->first();
                $storeId = $mainStore ? $mainStore->id : null;
            }
            
            \Log::info('Store ID para vendedor', [
                'user_id' => $user->id,
                'user_name' => $user->name,
                'store_id' => $storeId,
                'user_stores_count' => $userStores->count()
            ]);
        } else {
            // Admin geral: usar loja principal
            $mainStore = Store::where('is_main', true)->first();
            $storeId = $mainStore ? $mainStore->id : null;
        }
        
        // Se client_id foi enviado, atualiza o cliente existente
        if (!empty($validated['client_id'])) {
            $client = Client::findOrFail($validated['client_id']);
            $client->update($validated);
        } else {
            // Senão, cria um novo cliente com store_id
            $validated['store_id'] = $storeId;
            $client = Client::create($validated);
        }

        $status = Status::orderBy('position')->first();

        // Calcular data de entrega (15 dias úteis)
        $deliveryDate = DateHelper::calculateDeliveryDate(Carbon::now(), 15);

        $order = Order::create([
            'client_id' => $client->id,
            'user_id' => Auth::id(),
            'store_id' => $storeId,
            'status_id' => $status?->id ?? 1,
            'order_date' => now()->toDateString(),
            'delivery_date' => $deliveryDate->toDateString(),
            'is_draft' => true, // Criar como rascunho
        ]);

        session(['current_order_id' => $order->id]);

        \Log::info('=== STORE CLIENT DEBUG END - SUCCESS ===');
        return redirect()->route('orders.wizard.sewing');
        
        } catch (\Illuminate\Validation\ValidationException $e) {
            \Log::error('=== VALIDATION ERROR ===', ['errors' => $e->errors()]);
            throw $e;
        } catch (\Exception $e) {
            \Log::error('=== GENERAL ERROR ===', ['message' => $e->getMessage(), 'trace' => $e->getTraceAsString()]);
            throw $e;
        }
    }

    public function sewing(Request $request)
    {
        if ($request->isMethod('get')) {
            // Buscar pedido com fresh() para garantir dados atualizados do banco
            $order = Order::with(['items' => function($query) {
                $query->orderBy('id', 'asc');
            }])->findOrFail(session('current_order_id'));
            
            // Forçar reload dos items para garantir dados frescos
            $order->load('items');
            
            // Buscar tecidos e cores para controle de estoque
            $fabrics = \App\Models\ProductOption::where('type', 'tecido')
                ->where('active', true)
                ->orderBy('name')
                ->get();
            $colors = \App\Models\ProductOption::where('type', 'cor')
                ->where('active', true)
                ->orderBy('name')
                ->get();
            
            // Obter loja atual do usuário
            $user = Auth::user();
            $currentStoreId = null;
            if ($user->isAdminLoja()) {
                $storeIds = $user->getStoreIds();
                $currentStoreId = !empty($storeIds) ? $storeIds[0] : null;
            } elseif ($user->isVendedor()) {
                $userStores = $user->stores()->get();
                if ($userStores->isNotEmpty()) {
                    $currentStoreId = $userStores->first()->id;
                }
            }
            
            if (!$currentStoreId) {
                $mainStore = Store::where('is_main', true)->first();
                $currentStoreId = $mainStore ? $mainStore->id : null;
            }
            
            return view('orders.wizard.sewing', compact('order', 'fabrics', 'colors', 'currentStoreId'));
        }

        $action = $request->input('action', 'add');

        if ($action === 'add_item') {
            return $this->addItem($request);
        } elseif ($action === 'update_item') {
            return $this->updateItem($request);
        } elseif ($action === 'finish') {
            return $this->finishSewing($request);
        } elseif ($action === 'delete_item') {
            return $this->deleteItem($request);
        }

        return $this->addItem($request);
    }

    private function addItem(Request $request)
    {
        $validated = $request->validate([
            'personalizacao' => 'required|array|min:1',
            'personalizacao.*' => 'exists:product_options,id',
            'tecido' => 'required|exists:product_options,id',
            'tipo_tecido' => 'nullable|exists:product_options,id',
            'cor' => 'required|exists:product_options,id',
            'tipo_corte' => 'required|exists:product_options,id',
            'detalhe' => 'nullable|exists:product_options,id',
            'gola' => 'required|exists:product_options,id',
            'tamanhos' => 'required|array',
            'quantity' => 'required|integer|min:1',
            'unit_price' => 'required|numeric|min:0',
            'item_cover_image' => 'nullable|image|max:10240',
            'art_notes' => 'nullable|string|max:1000',
            'apply_surcharge' => 'nullable|boolean',
        ]);

        $order = Order::with('items')->findOrFail(session('current_order_id'));

        // Processar upload da imagem de capa do item
        $coverImagePath = null;
        if ($request->hasFile('item_cover_image')) {
            $coverImagePath = $this->imageProcessor->processAndStore(
                $request->file('item_cover_image'),
                'orders/items/covers',
                [
                    'max_width' => 1200,
                    'max_height' => 1200,
                    'quality' => 85,
                ]
            );
        }

        // Buscar nomes das opções
        $personalizacoes = \App\Models\ProductOption::whereIn('id', $validated['personalizacao'])->get();
        $personalizacaoNames = $personalizacoes->pluck('name')->join(', ');
        
        $tecido = \App\Models\ProductOption::find($validated['tecido']);
        $cor = \App\Models\ProductOption::find($validated['cor']);
        $tipoCorte = \App\Models\ProductOption::find($validated['tipo_corte']);
        $gola = \App\Models\ProductOption::find($validated['gola']);
        $detalhe = !empty($validated['detalhe']) ? \App\Models\ProductOption::find($validated['detalhe']) : null;
        $tipoTecido = !empty($validated['tipo_tecido']) ? \App\Models\ProductOption::find($validated['tipo_tecido']) : null;

        $itemNumber = $order->items()->count() + 1;

        $item = new OrderItem([
            'item_number' => $itemNumber,
            'fabric' => $tecido->name . ($tipoTecido ? ' - ' . $tipoTecido->name : ''),
            'color' => $cor->name,
            'collar' => $gola->name,
            'model' => $tipoCorte->name,
            'detail' => $detalhe ? $detalhe->name : null,
            'print_type' => $personalizacaoNames,
            'sizes' => $validated['tamanhos'],
            'quantity' => $validated['quantity'],
            'unit_price' => $validated['unit_price'],
            'total_price' => $validated['unit_price'] * $validated['quantity'],
            'cover_image' => $coverImagePath,
            'art_notes' => $validated['art_notes'] ?? null,
            'print_desc' => json_encode(['apply_surcharge' => $request->boolean('apply_surcharge')]),
        ]);
        $order->items()->save($item);
        $item->refresh(); // Garantir que temos o ID correto gerado pelo banco

        $order->update([
            'subtotal' => $order->items()->sum('total_price'),
            'total_items' => $order->items()->sum('quantity'),
        ]);

        // Salvar IDs de personalização vinculadas a este item
        session()->push('item_personalizations.' . $item->id, $validated['personalizacao']);

        return redirect()->route('orders.wizard.sewing')->with('success', 'Item ' . $itemNumber . ' adicionado com sucesso!');
    }

    private function updateItem(Request $request)
    {
        $validated = $request->validate([
            'editing_item_id' => 'required|integer',
            'personalizacao' => 'required|array|min:1',
            'personalizacao.*' => 'exists:product_options,id',
            'tecido' => 'required|exists:product_options,id',
            'tipo_tecido' => 'nullable|exists:product_options,id',
            'cor' => 'required|exists:product_options,id',
            'tipo_corte' => 'required|exists:product_options,id',
            'detalhe' => 'nullable|exists:product_options,id',
            'gola' => 'required|exists:product_options,id',
            'tamanhos' => 'required|array',
            'quantity' => 'required|integer|min:1',
            'unit_price' => 'required|numeric|min:0',
            'item_cover_image' => 'nullable|image|max:10240',
            'art_notes' => 'nullable|string|max:1000',
            'apply_surcharge' => 'nullable|boolean',
        ]);

        $order = Order::with('items')->findOrFail(session('current_order_id'));
        $item = $order->items()->findOrFail($validated['editing_item_id']);

        // Processar upload da imagem de capa do item
        $coverImagePath = $item->cover_image; // Manter imagem atual se não houver nova
        if ($request->hasFile('item_cover_image')) {
            $newCoverImagePath = $this->imageProcessor->processAndStore(
                $request->file('item_cover_image'),
                'orders/items/covers',
                [
                    'max_width' => 1200,
                    'max_height' => 1200,
                    'quality' => 85,
                ]
            );

            if ($newCoverImagePath) {
                $this->imageProcessor->delete($coverImagePath);
                $coverImagePath = $newCoverImagePath;
            }
        }

        // Buscar nomes das opções
        $personalizacoes = \App\Models\ProductOption::whereIn('id', $validated['personalizacao'])->get();
        $personalizacaoNames = $personalizacoes->pluck('name')->join(', ');

        $tecido = \App\Models\ProductOption::find($validated['tecido']);
        $tipoTecido = $validated['tipo_tecido'] ? \App\Models\ProductOption::find($validated['tipo_tecido']) : null;
        $cor = \App\Models\ProductOption::find($validated['cor']);
        $tipoCorte = \App\Models\ProductOption::find($validated['tipo_corte']);
        $detalhe = $validated['detalhe'] ? \App\Models\ProductOption::find($validated['detalhe']) : null;
        $gola = \App\Models\ProductOption::find($validated['gola']);

        // Calcular preço base
        $basePrice = $tipoCorte->price ?? 0;
        if ($detalhe) {
            $basePrice += $detalhe->price ?? 0;
        }
        if ($gola) {
            $basePrice += $gola->price ?? 0;
        }

        // Processar tamanhos
        $sizes = [];
        $totalQuantity = 0;
        foreach ($validated['tamanhos'] as $size => $quantity) {
            if ($quantity > 0) {
                $sizes[$size] = $quantity;
                $totalQuantity += $quantity;
            }
        }

        // Atualizar item
        $item->update([
            'print_type' => $personalizacaoNames,
            'fabric' => $tecido->name . ($tipoTecido ? ' - ' . $tipoTecido->name : ''),
            'color' => $cor->name,
            'collar' => $gola->name,
            'model' => $tipoCorte->name,
            'detail' => $detalhe ? $detalhe->name : null,
            'sizes' => json_encode($sizes),
            'quantity' => $totalQuantity,
            'unit_price' => $basePrice,
            'total_price' => $totalQuantity * $basePrice,
            'cover_image' => $coverImagePath,
            'art_notes' => $validated['art_notes'] ?? null,
            'print_desc' => json_encode(['apply_surcharge' => $request->boolean('apply_surcharge')]),
        ]);

        // Forçar refresh do modelo para garantir que os dados estão atualizados
        $item->refresh();

        $order->update([
            'subtotal' => $order->items()->sum('total_price'),
            'total_items' => $order->items()->sum('quantity'),
        ]);

        // Forçar refresh do pedido para garantir dados atualizados
        $order->refresh();

        // Atualizar personalizações na sessão
        session(['item_personalizations.' . $item->id => [$validated['personalizacao']]]);

        \Log::info('Item atualizado com sucesso', [
            'item_id' => $item->id,
            'order_id' => $order->id,
            'new_quantity' => $totalQuantity,
            'new_unit_price' => $basePrice,
            'new_data' => $item->toArray()
        ]);

        return redirect()->route('orders.wizard.sewing')->with('success', 'Item atualizado com sucesso!');
    }

    private function deleteItem(Request $request)
    {
        $itemId = $request->input('item_id');
        $order = Order::with('items')->findOrFail(session('current_order_id'));
        
        $item = $order->items()->findOrFail($itemId);
        $item->delete();

        // Renumerar itens
        $items = $order->items()->orderBy('id')->get();
        foreach ($items as $index => $it) {
            $it->update(['item_number' => $index + 1]);
        }

        $order->update([
            'subtotal' => $order->items()->sum('total_price'),
            'total_items' => $order->items()->sum('quantity'),
        ]);

        return redirect()->route('orders.wizard.sewing')->with('success', 'Item removido com sucesso!');
    }

    private function finishSewing(Request $request)
    {
        $order = Order::with('items')->findOrFail(session('current_order_id'));
        
        if ($order->items()->count() === 0) {
            return redirect()->route('orders.wizard.sewing')->with('error', 'Adicione pelo menos um item antes de continuar.');
        }

        // Coletar todas as personalizações únicas de todos os itens
        $allPersonalizations = [];
        foreach ($order->items as $item) {
            $itemPersonalizations = session('item_personalizations.' . $item->id, [[]]);
            $allPersonalizations = array_merge($allPersonalizations, $itemPersonalizations[0] ?? []);
        }
        $allPersonalizations = array_unique($allPersonalizations);

        // Salvar total de camisas na sessão para usar na personalização
        session(['total_shirts' => $order->items()->sum('quantity')]);
        
        // Salvar personalizações selecionadas na sessão
        session(['selected_personalizations' => $allPersonalizations]);

        return redirect()->route('orders.wizard.customization');
    }

    public function customization(Request $request)
    {
        if ($request->isMethod('get')) {
            $order = Order::with('items')->findOrFail(session('current_order_id'));
            
            // Debug: Log item IDs
            \Log::info('DEBUG ITEM IDS BEFORE VIEW:', ['ids' => $order->items->pluck('id')->toArray()]);
            // dd($order->items->pluck('id')); // Uncomment to force dump in browser if needed, using Log for non-blocking.
            
            // Coletar personalizações por item
            $itemPersonalizations = [];
            foreach ($order->items as $item) {
                $itemPers = session('item_personalizations.' . $item->id, [[]]);
                \Log::info('Checking session for item:', ['item_id' => $item->id, 'session_key' => 'item_personalizations.'.$item->id, 'result' => $itemPers]);
                $persIds = $itemPers[0] ?? [];
                
                if (!empty($persIds)) {
                    $persNames = \App\Models\ProductOption::whereIn('id', $persIds)
                        ->pluck('name', 'id')
                        ->toArray();
                    
                    $itemPersonalizations[$item->id] = [
                        'item' => $item,
                        'personalization_ids' => $persIds,
                        'personalization_names' => $persNames,
                    ];
                }
            }
            
            // Buscar tamanhos e localizações para cada tipo de personalização
            $personalizationData = [];
            $allTypes = ['DTF', 'SERIGRAFIA', 'BORDADO', 'SUBLIMACAO', 'EMBORRACHADO', 'SUB. LOCAL', 'SUB. TOTAL'];
            
            foreach ($allTypes as $type) {
                $sizes = \App\Models\PersonalizationPrice::where('personalization_type', $type)
                    ->where('active', true)
                    ->select('size_name', 'size_dimensions', 'order')
                    ->orderBy('order')
                    ->get()
                    ->unique(function ($item) {
                        return $item->size_name . $item->size_dimensions;
                    });
                
                $personalizationData[$type] = [
                    'sizes' => $sizes
                ];
            }
            
            // Localizações disponíveis
            $locations = \App\Models\SublimationLocation::where('active', true)
                ->orderBy('order')
                ->get();
            
            // Usar view unificada que mostra todas as personalizações
            return view('orders.wizard.customization-multiple', compact('order', 'itemPersonalizations', 'personalizationData', 'locations'));
        }

        // Debug: Log dos dados recebidos antes da validação
        \Log::info('=== PERSONALIZATION FORM DEBUG ===');
        \Log::info('Request data:', $request->all());
        \Log::info('Files received: ' . ($request->file('art_files') ? 'YES' : 'NO'));
        
        try {
            // Validação dos campos do formulário
            $validated = $request->validate([
                'item_id' => 'required',
                'personalization_type' => 'required|string',
                'personalization_id' => 'required|integer',
                'art_name' => 'nullable|string|max:255',
                'location' => 'nullable', // Tornado opcional para SUB. TOTAL
                'size' => 'nullable|string', // Tornado opcional para SUB. TOTAL
                'quantity' => 'nullable|integer|min:1', // Tornado opcional para SUB. TOTAL
                'color_count' => 'nullable|integer|min:1',
                'unit_price' => 'nullable|numeric|min:0',
                'final_price' => 'nullable|numeric|min:0',
                'application_image' => 'nullable|image|max:10240',
                'art_files' => 'required|array|min:1',
                'art_files.*' => 'required|file|max:51200', // Máximo 50MB por arquivo
                'color_details' => 'nullable|string|max:500',
                'seller_notes' => 'nullable|string|max:1000',
                'addons' => 'nullable|array', // Para adicionais de SUB. TOTAL
                'regata_discount' => 'nullable|boolean', // Para desconto REGATA
            ]);
            
            \Log::info('Validation passed successfully');
        } catch (\Illuminate\Validation\ValidationException $e) {
            \Log::error('Validation failed:', $e->errors());
            return response()->json([
                'success' => false,
                'message' => 'Erro de validação: ' . implode(', ', Arr::flatten($e->errors())),
                'errors' => $e->errors()
            ], 422);
        } catch (\Exception $e) {
            \Log::error('Unexpected error during validation:', [
                'message' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            return response()->json([
                'success' => false,
                'message' => 'Erro inesperado: ' . $e->getMessage()
            ], 500);
        }

        try {
            $order = Order::with('items')->findOrFail(session('current_order_id'));
            
            if ($validated['item_id'] == 0) {
                 // Fallback for new items in budget mode (implied context)
                 $item = $order->items()->first();
            } else {
                 $item = $order->items()->findOrFail($validated['item_id']);
            }

            // Processar imagem da aplicação
        $applicationImagePath = null;
        if ($request->hasFile('application_image')) {
            $appImage = $request->file('application_image');
            $appImageName = time() . '_' . uniqid() . '_' . $appImage->getClientOriginalName();
            $applicationImagePath = $appImage->storeAs('orders/applications', $appImageName, 'public');
        }

        // Debug: Log dos dados recebidos
        \Log::info('=== PERSONALIZATION LOCATION DEBUG ===');
        \Log::info('Received data:', [
            'personalization_type' => $validated['personalization_type'],
            'location' => $validated['location'] ?? 'NOT_SET',
            'size' => $validated['size'] ?? 'NOT_SET',
            'art_name' => $validated['art_name'] ?? 'NOT_SET'
        ]);

        // Buscar localização (apenas se não for SUB. TOTAL)
        $locationId = null;
        $locationName = null;
        if ($validated['personalization_type'] !== 'SUB. TOTAL' && isset($validated['location']) && $validated['location']) {
            $location = \App\Models\SublimationLocation::find($validated['location']);
            $locationId = $location ? $location->id : null;
            $locationName = $location ? $location->name : ($validated['location'] ?? null);
            
            \Log::info('Location found:', [
                'location_id' => $locationId,
                'location_name' => $locationName
            ]);
        } else {
            \Log::info('Location not set or SUB. TOTAL type');
        }

        // Para SUB. TOTAL, buscar quantidade do "Total de Peças" do item
        $quantity = $validated['quantity'] ?? 1;
        if ($validated['personalization_type'] === 'SUB. TOTAL') {
            // Para SUB. TOTAL, usar a quantidade total do item
            $quantity = $item->quantity;
        }

        // Debug: Log dos preços recebidos
        \Log::info('=== PERSONALIZATION PRICE DEBUG ===');
        \Log::info('Received prices:', [
            'unit_price' => $validated['unit_price'] ?? 'null',
            'final_price' => $validated['final_price'] ?? 'null',
            'personalization_type' => $validated['personalization_type'],
            'quantity' => $quantity
        ]);

        // Criar a personalização
        $personalization = \App\Models\OrderSublimation::create([
            'order_item_id' => $item->id,
            'application_type' => strtolower($validated['personalization_type']),
            'art_name' => $validated['art_name'] ?? null,
            'size_id' => null,
            'size_name' => $validated['personalization_type'] === 'SUB. TOTAL' ? 'CACHARREL' : ($validated['size'] ?? null),
            'location_id' => $locationId,
            'location_name' => $locationName,
            'quantity' => $quantity,
            'color_count' => $validated['color_count'] ?? 0,
            'has_neon' => false,
            'neon_surcharge' => 0,
            'unit_price' => $validated['unit_price'] ?? 0,
            'discount_percent' => 0,
            'final_price' => $validated['final_price'] ?? 0,
            'application_image' => $applicationImagePath,
            'color_details' => $validated['color_details'] ?? null,
            'seller_notes' => $validated['seller_notes'] ?? null,
        ]);

        // Debug: Log da personalização criada
        \Log::info('Personalization created:', [
            'id' => $personalization->id,
            'unit_price' => $personalization->unit_price,
            'final_price' => $personalization->final_price,
            'quantity' => $personalization->quantity
        ]);

        // TODO: Processar adicionais para SUB. TOTAL (após criar migration)
        // if ($validated['personalization_type'] === 'SUB. TOTAL' && $request->has('addons')) {
        //     $addons = $request->input('addons', []);
        //     $regataDiscount = $request->boolean('regata_discount', false);
        //     
        //     // Adicionar desconto REGATA se marcado
        //     if ($regataDiscount) {
        //         $addons[] = 'REGATA_DISCOUNT';
        //     }
        //     
        //     // Salvar adicionais como JSON na personalização
        //     $personalization->update([
        //         'addons' => json_encode($addons),
        //         'regata_discount' => $regataDiscount,
        //     ]);
        // }

        // Processar arquivos da arte (CDR, PDF, etc.)
        if ($request->hasFile('art_files')) {
            foreach ($request->file('art_files') as $file) {
                $originalName = $file->getClientOriginalName();
                $fileName = time() . '_' . uniqid() . '_' . $originalName;
                $filePath = $file->storeAs('orders/art_files', $fileName, 'public');
                
                \App\Models\OrderSublimationFile::create([
                    'order_sublimation_id' => $personalization->id,
                    'file_name' => $originalName,
                    'file_path' => $filePath,
                    'file_type' => $file->getMimeType(),
                    'file_size' => $file->getSize(),
                ]);
            }
        }

        // Aplicar descontos automáticos nas personalizações
        \App\Helpers\PersonalizationDiscountHelper::applyDiscounts($item->id);

        // Atualizar o preço total do item somando todas as personalizações
        $totalPersonalizations = \App\Models\OrderSublimation::where('order_item_id', $item->id)
            ->sum('final_price');
        
        // Calcular novo total do item (preço base + personalizações)
        $basePrice = $item->unit_price * $item->quantity;
        $newTotalPrice = $basePrice + $totalPersonalizations;
        
        $item->update([
            'total_price' => $newTotalPrice
        ]);

        // Atualizar subtotal do pedido
            $order->update([
                'subtotal' => $order->items()->sum('total_price'),
            ]);

            // Retornar resposta JSON
            return response()->json([
                'success' => true,
                'message' => 'Personalização adicionada com sucesso!'
            ]);
        } catch (\Exception $e) {
            \Log::error('Error adding personalization:', [
                'message' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            return response()->json([
                'success' => false,
                'message' => 'Erro ao adicionar personalização: ' . $e->getMessage()
            ], 500);
        }
    }

    public function refreshCustomizations(Request $request)
    {
        try {
            $order = Order::with('items')->findOrFail(session('current_order_id'));
            
            // Recarregar o pedido para pegar valores atualizados
            $order->refresh();
            $order->load('items');
            
            // Buscar personalizações existentes por item
            $itemPersonalizations = [];
            foreach ($order->items as $item) {
                // Buscar IDs das personalizações do item
                $itemPers = session('item_personalizations.' . $item->id, [[]]);
                $persIds = $itemPers[0] ?? [];
                
                if (!empty($persIds)) {
                    $persNames = \App\Models\ProductOption::whereIn('id', $persIds)
                        ->pluck('name', 'id')
                        ->toArray();
                    
                    $itemPersonalizations[$item->id] = [
                        'item' => $item,
                        'personalization_ids' => $persIds,
                        'personalization_names' => $persNames,
                    ];
                }
            }
            
            // Dados de personalização por tipo
            $personalizationData = [];
            $types = ['DTF', 'SERIGRAFIA', 'BORDADO', 'SUBLIMACAO', 'EMBORRACHADO', 'SUB. LOCAL', 'SUB. TOTAL'];
            
            foreach ($types as $type) {
                $sizes = \App\Models\PersonalizationPrice::where('personalization_type', $type)
                    ->where('active', true)
                    ->select('size_name', 'size_dimensions', 'order')
                    ->orderBy('order')
                    ->get()
                    ->unique(function ($item) {
                        return $item->size_name . $item->size_dimensions;
                    });
                    
                $personalizationData[$type] = [
                    'sizes' => $sizes
                ];
            }
            
            // Localizações disponíveis
            $locations = \App\Models\SublimationLocation::where('active', true)
                ->orderBy('order')
                ->get();
            
            // Retornar apenas a seção de conteúdo
            return view('orders.wizard.customization-multiple', compact('order', 'itemPersonalizations', 'personalizationData', 'locations'))
                ->render();
                
        } catch (\Exception $e) {
            \Log::error('Error refreshing customizations:', [
                'message' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            
            return response()->json([
                'success' => false,
                'message' => 'Erro ao atualizar personalizações: ' . $e->getMessage()
            ], 500);
        }
    }

    public function payment(Request $request)
    {
        if ($request->isMethod('get')) {
            $order = Order::with('client', 'items')->findOrFail(session('current_order_id'));
            return view('orders.wizard.payment', compact('order'));
        }

        $validated = $request->validate([
            'entry_date' => 'required|date',
            'delivery_fee' => 'nullable|numeric|min:0',
            'payment_methods' => 'required|json',
            'size_surcharges' => 'nullable|json',
            'order_cover_image' => 'nullable|image|max:10240',
            'discount_type' => 'nullable|string|in:none,percentage,fixed',
            'discount_value' => 'nullable|numeric|min:0',
        ]);

        $order = Order::with('items')->findOrFail(session('current_order_id'));
        
        // Processar upload da imagem de capa do pedido
        $orderCoverImagePath = $order->cover_image;
        if ($request->hasFile('order_cover_image')) {
            $newOrderCoverImagePath = $this->imageProcessor->processAndStore(
                $request->file('order_cover_image'),
                'orders/covers',
                [
                    'max_width' => 1400,
                    'max_height' => 1400,
                    'quality' => 85,
                ]
            );

            if ($newOrderCoverImagePath) {
                $this->imageProcessor->delete($orderCoverImagePath);
                $orderCoverImagePath = $newOrderCoverImagePath;
            }
        }
        
        $subtotal = $order->items()->sum('total_price');
        $delivery = (float)($validated['delivery_fee'] ?? 0);
        
        // Processar acréscimos por tamanho
        // Recalcular acréscimos no backend para garantir integridade e aplicar regras de restrição
        $sizeSurcharges = [];
        $largeSizes = ['GG', 'EXG', 'G1', 'G2', 'G3'];
        $sizeQuantities = [];
        
        foreach ($order->items as $item) {
            $model = strtoupper($item->model ?? '');
            $detail = strtoupper($item->detail ?? '');
            $isRestricted = str_contains($model, 'INFANTIL') || str_contains($model, 'BABY LOOK') || 
                            str_contains($detail, 'INFANTIL') || str_contains($detail, 'BABY LOOK');
            
            $printDesc = is_string($item->print_desc) ? json_decode($item->print_desc, true) : $item->print_desc;
            $applySurcharge = filter_var($printDesc['apply_surcharge'] ?? false, FILTER_VALIDATE_BOOLEAN);
            
            // Se for restrito (Infantil/Baby look) e NÃO tiver o checkbox marcado, ignora os tamanhos deste item
            if ($isRestricted && !$applySurcharge) {
                continue;
            }
            
            $sizes = is_string($item->sizes) ? json_decode($item->sizes, true) : $item->sizes;
            if (is_array($sizes)) {
                foreach ($sizes as $size => $qty) {
                    if (in_array($size, $largeSizes)) {
                        $sizeQuantities[$size] = ($sizeQuantities[$size] ?? 0) + (int)$qty;
                    }
                }
            }
        }
        
        foreach ($sizeQuantities as $size => $qty) {
            if ($qty > 0) {
                $surchargeModel = \App\Models\SizeSurcharge::getSurchargeForSize($size, $subtotal);
                if ($surchargeModel) {
                    $sizeSurcharges[$size] = (float)$surchargeModel->surcharge * $qty;
                }
            }
        }

        $totalSurcharges = array_sum($sizeSurcharges);

        // Desconto
        $discountType = $validated['discount_type'] ?? 'none';
        $discountValue = (float)($validated['discount_value'] ?? 0);
        $subtotalWithFees = $subtotal + $totalSurcharges + $delivery;
        $discountAmount = 0.0;
        if ($discountType === 'percentage') {
            $discountValue = max(0, min(100, $discountValue));
            $discountAmount = ($subtotalWithFees * $discountValue) / 100.0;
        } elseif ($discountType === 'fixed') {
            $discountAmount = min($discountValue, $subtotalWithFees);
        }
        
        // Processar múltiplas formas de pagamento
        $paymentMethods = json_decode($validated['payment_methods'], true);
        $totalPaid = array_sum(array_column($paymentMethods, 'amount'));
        
        $total = max(0, $subtotalWithFees - $discountAmount);

        $order->update([
            'subtotal' => $subtotal,
            'delivery_fee' => $delivery,
            'discount' => $discountAmount,
            'total' => $total,
            'cover_image' => $orderCoverImagePath,
        ]);

        // Deletar pagamentos antigos para evitar acúmulo
        Payment::where('order_id', $order->id)->delete();
        
        // Deletar transações de caixa antigas deste pedido
        CashTransaction::where('order_id', $order->id)->delete();

        // Criar registro de pagamento
        $primaryMethod = count($paymentMethods) === 1 ? $paymentMethods[0]['method'] : 'pix';
        
        Payment::create([
            'order_id' => $order->id,
            'method' => $primaryMethod,
            'payment_method' => count($paymentMethods) > 1 ? 'multiplo' : $primaryMethod,
            'payment_methods' => $paymentMethods,
            'amount' => $total,
            'entry_amount' => $totalPaid,
            'remaining_amount' => max(0, $total - $totalPaid),
            'entry_date' => $validated['entry_date'],
            'payment_date' => $validated['entry_date'],
            'status' => $totalPaid >= $total ? 'pago' : 'pendente',
        ]);

        // Registrar entrada(s) no caixa como "pendente" até o pedido ser entregue
        $user = Auth::user();
        foreach ($paymentMethods as $method) {
            CashTransaction::create([
                'store_id' => $order->store_id,
                'type' => 'entrada',
                'category' => 'Venda',
                'description' => "Pagamento do Pedido #" . str_pad($order->id, 6, '0', STR_PAD_LEFT) . " - Cliente: " . $order->client->name,
                'amount' => $method['amount'],
                'payment_method' => $method['method'],
                'status' => 'pendente',
                'transaction_date' => $validated['entry_date'],
                'order_id' => $order->id,
                'user_id' => $user->id ?? null,
                'user_name' => $user->name ?? 'Sistema',
                'notes' => count($paymentMethods) > 1 ? 'Pagamento parcial (múltiplas formas)' : null,
            ]);
        }

        // Salvar acréscimos na sessão para exibir no resumo
        session(['size_surcharges' => $sizeSurcharges]);

        return redirect()->route('orders.wizard.confirm');
    }

    public function confirm(): View
    {
        $order = Order::with(['client', 'items.sublimations.size', 'items.sublimations.location', 'items.files', 'status'])
            ->findOrFail(session('current_order_id'));
        
        $payment = Payment::where('order_id', $order->id)->get();
        $sizeSurcharges = session('size_surcharges', []);
        
        // Buscar configurações da empresa da loja do pedido
        $companySettings = \App\Models\CompanySetting::getSettings($order->store_id);
        
        return view('orders.wizard.confirm', compact('order', 'payment', 'sizeSurcharges', 'companySettings'));
    }

    public function finalize(Request $request): RedirectResponse
    {
        try {
            $orderId = session('current_order_id');
            
            if (!$orderId) {
                return redirect()->route('orders.wizard.start')->with('error', 'Sessão expirada. Por favor, inicie um novo pedido.');
            }
            
            $order = Order::with(['items.sublimations'])->findOrFail($orderId);
            
            // Buscar termos e condições baseados no tipo de personalização do pedido
            $activeTerms = \App\Models\TermsCondition::getActiveForOrder($order);
            $termsVersion = '1.0';
            
            // Se encontrou termos específicos, usar a versão do primeiro termo encontrado
            if ($activeTerms->isNotEmpty()) {
                $termsVersion = $activeTerms->first()->version ?? '1.0';
            } else {
                // Fallback: buscar termos gerais
                $generalTerms = \App\Models\TermsCondition::getActive();
                if ($generalTerms) {
                    $termsVersion = $generalTerms->version ?? '1.0';
                }
            }
            
            // Buscar status "Pendente"
            $pendenteStatus = Status::where('name', 'Pendente')->first();
            
            // Garantir que a data de entrega esteja definida (preservar existente ou calcular 15 dias úteis)
            $deliveryDate = $order->delivery_date;
            if (!$deliveryDate) {
                // Calcular 15 dias úteis a partir da data de criação do pedido
                $deliveryDate = DateHelper::calculateDeliveryDate($order->created_at, 15)->format('Y-m-d');
            } else {
                // Garantir formato correto (apenas data, sem horário)
                $deliveryDate = \Carbon\Carbon::parse($deliveryDate)->format('Y-m-d');
            }
            
            // Confirmar o pedido (tirar do modo rascunho e colocar em Pendente)
            $updateData = [
                'is_draft' => false,
                'status_id' => $pendenteStatus ? $pendenteStatus->id : $order->status_id,
                'delivery_date' => $deliveryDate,
                'terms_accepted' => true,
                'terms_accepted_at' => now(),
                'terms_version' => $termsVersion
            ];
            
            // Processar checkbox de evento
            if ($request->has('is_event') && $request->input('is_event') == '1') {
                $updateData['contract_type'] = 'EVENTO';
                $updateData['is_event'] = true;
            } else {
                $updateData['is_event'] = false;
            }
            
            $order->update($updateData);
            
            // Registrar histórico de venda
            try {
                \App\Models\SalesHistory::recordSale($order);
            } catch (\Exception $e) {
                \Log::warning('Erro ao registrar histórico de venda', [
                    'error' => $e->getMessage(),
                    'order_id' => $order->id,
                ]);
            }

            // Registrar tracking de status inicial
            try {
                \App\Models\OrderStatusTracking::recordEntry($order->id, $order->status_id, Auth::id());
            } catch (\Exception $e) {
                \Log::warning('Erro ao registrar tracking de status', [
                    'error' => $e->getMessage(),
                    'order_id' => $order->id,
                ]);
            }
            
            // Criar log de confirmação
            \App\Models\OrderLog::create([
                'order_id' => $order->id,
                'user_id' => Auth::id(),
                'user_name' => Auth::user()->name ?? 'Sistema',
                'action' => 'PEDIDO_CONFIRMADO',
                'description' => 'Pedido confirmado e enviado para produção.',
            ]);
            
            // Limpar sessão
            session()->forget(['current_order_id', 'item_personalizations', 'size_surcharges']);
            
            return redirect()->route('kanban.index')->with('success', 'Pedido #' . str_pad($order->id, 6, '0', STR_PAD_LEFT) . ' confirmado com sucesso!');
            
        } catch (\Exception $e) {
            \Log::error('Erro ao finalizar pedido: ' . $e->getMessage());
            \Log::error($e->getTraceAsString());
            return redirect()->back()->with('error', 'Erro ao confirmar pedido: ' . $e->getMessage());
        }
    }

    public function deletePersonalization($id)
    {
        try {
            $personalization = \App\Models\OrderSublimation::findOrFail($id);
            $itemId = $personalization->order_item_id;
            $personalization->delete();
            
            // Recalcular total do item
            $item = \App\Models\OrderItem::findOrFail($itemId);
            $totalPersonalizations = \App\Models\OrderSublimation::where('order_item_id', $itemId)
                ->sum('final_price');
            
            $basePrice = $item->unit_price * $item->quantity;
            $newTotalPrice = $basePrice + $totalPersonalizations;
            
            $item->update([
                'total_price' => $newTotalPrice
            ]);
            
            // Recalcular subtotal do pedido
            $order = $item->order;
            $order->update([
                'subtotal' => $order->items()->sum('total_price'),
            ]);
            
            return response()->json([
                'success' => true,
                'message' => 'Personalização removida com sucesso!'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Erro ao remover personalização'
            ], 500);
        }
    }
}
