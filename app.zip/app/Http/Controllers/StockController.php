<?php

namespace App\Http\Controllers;

use App\Models\Stock;
use App\Models\ProductOption;
use App\Models\Store;
use App\Models\User;
use App\Models\Notification;
use App\Helpers\StoreHelper;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\View\View;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class StockController extends Controller
{
    /**
     * Listar estoque
     */
    public function index(Request $request): View
    {
        $storeId = $request->get('store_id');
        $fabricId = $request->get('fabric_id');
        $colorId = $request->get('color_id');
        $cutTypeId = $request->get('cut_type_id');
        $size = $request->get('size');
        $lowStock = $request->get('low_stock', false);

        $query = Stock::with(['store', 'fabric', 'color', 'cutType']);

        // Aplicar filtro de loja
        StoreHelper::applyStoreFilter($query, 'store_id');

        // Filtros
        if ($storeId) {
            $query->where('store_id', $storeId);
        }

        if ($fabricId) {
            $query->where('fabric_id', $fabricId);
        }

        if ($colorId) {
            $query->where('color_id', $colorId);
        }

        if ($cutTypeId) {
            $query->where('cut_type_id', $cutTypeId);
        }

        if ($size) {
            $query->where('size', $size);
        }

        // Estoque baixo
        if ($lowStock) {
            $query->whereRaw('(quantity - reserved_quantity) < min_stock');
        }

        $allStocks = $query->orderBy('store_id')
            ->orderBy('fabric_id')
            ->orderBy('color_id')
            ->orderBy('cut_type_id')
            ->orderBy('size')
            ->get();

        // Agrupar estoques por loja, tecido, tipo de corte e cor
        $groupedStocks = [];
        $sizes = ['PP', 'P', 'M', 'G', 'GG', 'EXG', 'G1', 'G2', 'G3'];
        
        foreach ($allStocks as $stock) {
            $key = sprintf(
                '%d_%d_%d_%d',
                $stock->store_id,
                $stock->fabric_id ?? 0,
                $stock->cut_type_id ?? 0,
                $stock->color_id ?? 0
            );
            
            if (!isset($groupedStocks[$key])) {
                $groupedStocks[$key] = [
                    'store' => [
                        'id' => $stock->store->id,
                        'name' => $stock->store->name,
                    ],
                    'fabric' => $stock->fabric ? [
                        'id' => $stock->fabric->id,
                        'name' => $stock->fabric->name,
                    ] : null,
                    'cut_type' => $stock->cutType ? [
                        'id' => $stock->cutType->id,
                        'name' => $stock->cutType->name,
                    ] : null,
                    'color' => $stock->color ? [
                        'id' => $stock->color->id,
                        'name' => $stock->color->name,
                    ] : null,
                    'sizes' => [],
                    'total_quantity' => 0,
                    'total_reserved' => 0,
                    'total_available' => 0,
                    'last_updated' => $stock->updated_at->toDateTimeString(),
                ];
            }
            
            $groupedStocks[$key]['sizes'][$stock->size] = [
                'quantity' => $stock->quantity,
                'reserved_quantity' => $stock->reserved_quantity,
                'available_quantity' => $stock->available_quantity,
                'min_stock' => $stock->min_stock,
                'max_stock' => $stock->max_stock,
                'shelf' => $stock->shelf,
                'updated_at' => $stock->updated_at,
            ];
            
            $groupedStocks[$key]['total_quantity'] += $stock->quantity;
            $groupedStocks[$key]['total_reserved'] += $stock->reserved_quantity;
            $groupedStocks[$key]['total_available'] += $stock->available_quantity;
            
            // Atualizar última atualização se for mais recente
            $lastUpdated = is_string($groupedStocks[$key]['last_updated']) 
                ? \Carbon\Carbon::parse($groupedStocks[$key]['last_updated'])
                : $groupedStocks[$key]['last_updated'];
            if ($stock->updated_at > $lastUpdated) {
                $groupedStocks[$key]['last_updated'] = $stock->updated_at->toDateTimeString();
            }
        }

        // Dados para filtros
        $stores = StoreHelper::getAvailableStores();
        $fabrics = ProductOption::where('type', 'tecido')->where('active', true)->orderBy('name')->get();
        $colors = ProductOption::where('type', 'cor')->where('active', true)->orderBy('name')->get();
        $cutTypes = ProductOption::where('type', 'tipo_corte')->where('active', true)->orderBy('name')->get();

        return view('stocks.index', compact(
            'groupedStocks',
            'stores',
            'fabrics',
            'colors',
            'cutTypes',
            'sizes',
            'storeId',
            'fabricId',
            'colorId',
            'cutTypeId',
            'size',
            'lowStock'
        ));
    }

    /**
     * Mostrar formulário de criação
     */
    public function create(Request $request): View
    {
        // Workaround para evitar limpar cache de rota em produção:
        // Se passar ?mode=edit, redireciona para a lógica de edição
        if ($request->get('mode') === 'edit') {
            return $this->edit($request);
        }

        $stores = StoreHelper::getAvailableStores();
        $fabrics = ProductOption::where('type', 'tecido')->where('active', true)->orderBy('name')->get();
        $colors = ProductOption::where('type', 'cor')->where('active', true)->orderBy('name')->get();
        $cutTypes = ProductOption::where('type', 'tipo_corte')->where('active', true)->orderBy('name')->get();
        $sizes = ['PP', 'P', 'M', 'G', 'GG', 'EXG', 'G1', 'G2', 'G3'];

        return view('stocks.create', compact('stores', 'fabrics', 'colors', 'cutTypes', 'sizes'));
    }

    /**
     * Salvar novo estoque
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'store_id' => 'required|exists:stores,id',
            'fabric_id' => 'required|exists:product_options,id',
            'color_id' => 'required|exists:product_options,id',
            'cut_type_id' => 'required|exists:product_options,id',
            'sizes' => 'required|array',
            'sizes.*' => 'nullable|integer|min:0',
            'shelf' => 'nullable|string|max:50',
            'min_stock' => 'nullable|numeric|min:0',
            'max_stock' => 'nullable|numeric|min:0',
            'notes' => 'nullable|string|max:1000',
        ]);

        // Verificar permissão de acesso à loja
        if (!StoreHelper::canAccessStore($validated['store_id'])) {
            return redirect()->back()->with('error', 'Você não tem permissão para acessar esta loja.');
        }

        $sizes = ['PP', 'P', 'M', 'G', 'GG', 'EXG', 'G1', 'G2', 'G3'];
        $createdCount = 0;
        $updatedCount = 0;

        $shelf = isset($validated['shelf']) ? trim($validated['shelf']) : null;
        
        foreach ($sizes as $size) {
            $quantity = isset($validated['sizes'][$size]) ? (int)$validated['sizes'][$size] : 0;
            
            // Criar ou atualizar apenas se a quantidade for maior que 0
            if ($quantity > 0) {
                $stockData = [
                    'store_id' => $validated['store_id'],
                    'fabric_id' => $validated['fabric_id'],
                    'color_id' => $validated['color_id'],
                    'cut_type_id' => $validated['cut_type_id'],
                    'size' => $size,
                    'shelf' => $shelf, // Mesma prateleira para todos os tamanhos
                    'quantity' => $quantity,
                    'min_stock' => $validated['min_stock'] ?? 0,
                    'max_stock' => $validated['max_stock'] ?? null,
                    'notes' => $validated['notes'] ?? null,
                ];

                $existing = Stock::findByParams(
                    $validated['store_id'],
                    $validated['fabric_id'],
                    $validated['color_id'],
                    $validated['cut_type_id'],
                    $size
                );

                $stock = null;
                if ($existing) {
                    $existing->update($stockData);
                    $stock = $existing->fresh();
                    $updatedCount++;
                } else {
                    $stock = Stock::create($stockData);
                    $createdCount++;
                }
                
                // Verificar se estoque baixou abaixo de 30 peças e criar notificação
                if ($stock) {
                    $this->checkLowStock($stock);
                }
            }
        }

        $message = '';
        if ($createdCount > 0 && $updatedCount > 0) {
            $message = "Estoque cadastrado com sucesso! {$createdCount} novo(s) registro(s) criado(s) e {$updatedCount} atualizado(s).";
        } elseif ($createdCount > 0) {
            $message = "Estoque cadastrado com sucesso! {$createdCount} novo(s) registro(s) criado(s).";
        } elseif ($updatedCount > 0) {
            $message = "Estoque atualizado com sucesso! {$updatedCount} registro(s) atualizado(s).";
        } else {
            return redirect()->back()->with('error', 'Nenhuma quantidade foi informada. Informe pelo menos uma quantidade maior que 0.');
        }

        return redirect()->route('stocks.index')->with('success', $message);
    }

    /**
     * Mostrar estoque específico
     */
    public function show($id): JsonResponse
    {
        $stock = Stock::with(['store', 'fabric', 'color', 'cutType'])->findOrFail($id);

        return response()->json([
            'success' => true,
            'stock' => $stock,
        ]);
    }

    /**
     * Verificar se estoque está baixo (abaixo de 30 peças) e criar notificação
     */
    private function checkLowStock(Stock $stock)
    {
        $stock->load(['store', 'fabric', 'color', 'cutType']);
        $availableQuantity = $stock->available_quantity;
        
        // Verificar se está abaixo de 30 peças
        if ($availableQuantity < 30) {
            // Verificar se já existe notificação recente (últimas 24 horas) para evitar spam
            $recentNotification = Notification::where('type', 'low_stock')
                ->where('data->store_name', $stock->store->name ?? 'N/A')
                ->where('data->product_info', ($stock->fabric->name ?? 'N/A') . ' - ' . ($stock->color->name ?? 'N/A'))
                ->where('data->size', $stock->size)
                ->where('created_at', '>=', now()->subDay())
                ->exists();
            
            if (!$recentNotification) {
                $productInfo = ($stock->fabric->name ?? 'N/A') . ' - ' . ($stock->color->name ?? 'N/A');
                $storeName = $stock->store->name ?? 'N/A';
                
                // Criar notificação para usuários de estoque
                $estoqueUsers = User::where('role', 'estoque')->orWhere('role', 'admin')->get();
                foreach ($estoqueUsers as $estoqueUser) {
                    Notification::createLowStock(
                        $estoqueUser->id,
                        $storeName,
                        $productInfo,
                        $stock->size,
                        $availableQuantity
                    );
                }
            }
        }
    }

    /**
     * Buscar estoque por tipo de corte (mostra todas as combinações disponíveis)
     */
    public function getByCutType(Request $request): JsonResponse
    {
        $rules = [
            'cut_type_id' => 'required|integer|exists:product_options,id',
        ];
        
        if ($request->has('store_id') && $request->store_id !== null) {
            $rules['store_id'] = 'required|integer|exists:stores,id';
        }
        
        if ($request->has('color_id') && $request->color_id !== null) {
            $rules['color_id'] = 'required|integer|exists:product_options,id';
        }
        
        $validated = $request->validate($rules);

        try {
            $cutType = ProductOption::findOrFail($validated['cut_type_id']);
            
            if ($cutType->type !== 'tipo_corte') {
                return response()->json([
                    'success' => false,
                    'message' => 'ID fornecido não é um tipo de corte',
                ], 400);
            }

            // Buscar todos os estoques que têm este tipo de corte (de todas as lojas se não especificar)
            $query = Stock::where('cut_type_id', $validated['cut_type_id'])
                ->with(['store', 'fabric', 'color', 'cutType']);
            
            if (isset($validated['store_id']) && !empty($validated['store_id'])) {
                $query->where('store_id', $validated['store_id']);
            }
            
            if (isset($validated['color_id']) && !empty($validated['color_id'])) {
                $query->where('color_id', $validated['color_id']);
            }
            
            $stocks = $query->get();

            // Agrupar por tamanho e loja
            $stockBySize = [];
            foreach ($stocks as $stock) {
                $size = $stock->size ?? 'N/A';
                $storeId = $stock->store_id;
                $storeName = $stock->store ? $stock->store->name : ('Loja #' . $storeId);
            
            if (!isset($stockBySize[$size])) {
                $stockBySize[$size] = [
                    'size' => $size,
                    'available' => 0,
                    'total' => 0,
                    'reserved' => 0,
                    'stores' => [],
                    'combinations' => []
                ];
            }
            
            $stockBySize[$size]['available'] += $stock->available_quantity;
            $stockBySize[$size]['total'] += $stock->quantity;
            $stockBySize[$size]['reserved'] += $stock->reserved_quantity;
            
            // Agrupar por loja
            if (!isset($stockBySize[$size]['stores'][$storeId])) {
                $stockBySize[$size]['stores'][$storeId] = [
                    'store_id' => $storeId,
                    'store_name' => $storeName,
                    'available' => 0,
                    'total' => 0,
                    'reserved' => 0,
                    'items' => []
                ];
            }
            
            $stockBySize[$size]['stores'][$storeId]['available'] += $stock->available_quantity;
            $stockBySize[$size]['stores'][$storeId]['total'] += $stock->quantity;
            $stockBySize[$size]['stores'][$storeId]['reserved'] += $stock->reserved_quantity;
            
            $stockBySize[$size]['stores'][$storeId]['items'][] = [
                'fabric' => $stock->fabric->name ?? 'N/A',
                'color' => $stock->color->name ?? 'N/A',
                'available' => $stock->available_quantity,
                'total' => $stock->quantity,
            ];
            
            // Manter compatibilidade com versão anterior
            $stockBySize[$size]['combinations'][] = [
                'fabric' => $stock->fabric->name ?? 'N/A',
                'color' => $stock->color->name ?? 'N/A',
                'available' => $stock->available_quantity,
                'total' => $stock->quantity,
                'store_name' => $storeName,
            ];
        }
        
            // Converter stores de array associativo para array indexado
            foreach ($stockBySize as $size => &$data) {
                $data['stores'] = array_values($data['stores']);
            }

            return response()->json([
                'success' => true,
                'cut_type' => $cutType->name,
                'stock_by_size' => array_values($stockBySize),
                'total_combinations' => $stocks->count(),
            ]);
        } catch (\Exception $e) {
            \Log::error('Erro ao buscar estoque por tipo de corte', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
                'request' => $request->all(),
            ]);
            
            return response()->json([
                'success' => false,
                'message' => 'Erro ao buscar estoque: ' . $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Buscar tecido relacionado ao tipo de corte (API)
     */
    public function getFabricByCutType(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'cut_type_id' => 'required|exists:product_options,id',
        ]);

        $cutType = ProductOption::with('parent.parent')->findOrFail($validated['cut_type_id']);
        
        if ($cutType->type !== 'tipo_corte') {
            return response()->json([
                'success' => false,
                'message' => 'ID fornecido não é um tipo de corte',
            ], 400);
        }

        $fabricId = null;
        $fabricName = null;

        // Hierarquia: tipo_corte -> tipo_tecido -> tecido
        if ($cutType->parent_id && $cutType->parent) {
            if ($cutType->parent->type === 'tipo_tecido' && $cutType->parent->parent_id) {
                $tipoTecido = $cutType->parent;
                if ($tipoTecido->parent && $tipoTecido->parent->type === 'tecido') {
                    $fabricId = $tipoTecido->parent->id;
                    $fabricName = $tipoTecido->parent->name;
                }
            } elseif ($cutType->parent->type === 'tecido') {
                // Se o parent direto for tecido
                $fabricId = $cutType->parent->id;
                $fabricName = $cutType->parent->name;
            }
        }

        // Se não encontrou, tentar buscar via relacionamento muitos-para-muitos
        if (!$fabricId && Schema::hasTable('product_option_relations')) {
            $fabricRelation = \DB::table('product_option_relations')
                ->join('product_options', 'product_option_relations.parent_id', '=', 'product_options.id')
                ->where('product_option_relations.option_id', $cutType->id)
                ->where('product_options.type', 'tecido')
                ->select('product_options.id', 'product_options.name')
                ->first();
            
            if ($fabricRelation) {
                $fabricId = $fabricRelation->id;
                $fabricName = $fabricRelation->name;
            }
        }

        return response()->json([
            'success' => true,
            'fabric_id' => $fabricId,
            'fabric_name' => $fabricName,
        ]);
    }

    /**
     * Verificar estoque em tempo real (API)
     */
    public function check(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'store_id' => 'required|exists:stores,id',
            'fabric_id' => 'nullable|exists:product_options,id',
            'color_id' => 'nullable|exists:product_options,id',
            'cut_type_id' => 'nullable|exists:product_options,id',
            'size' => 'required|string|in:PP,P,M,G,GG,EXG,G1,G2,G3',
            'quantity' => 'nullable|integer|min:1',
        ]);

        $stock = Stock::findByParams(
            $validated['store_id'],
            $validated['fabric_id'],
            $validated['color_id'],
            $validated['cut_type_id'],
            $validated['size']
        );

        $availableQuantity = $stock ? $stock->available_quantity : 0;
        $hasStock = $stock && $stock->hasStock($validated['quantity'] ?? 1);

        return response()->json([
            'success' => true,
            'stock' => $stock ? [
                'id' => $stock->id,
                'quantity' => $stock->quantity,
                'reserved_quantity' => $stock->reserved_quantity,
                'available_quantity' => $availableQuantity,
                'min_stock' => $stock->min_stock,
                'is_below_minimum' => $stock->isBelowMinimum(),
            ] : null,
            'available_quantity' => $availableQuantity,
            'has_stock' => $hasStock,
            'can_fulfill' => $hasStock,
        ]);
    }

    /**
     * Atualizar estoque
     */
    public function update(Request $request, $id): JsonResponse
    {
        $stock = Stock::findOrFail($id);

        // Verificar permissão
        if (!StoreHelper::canAccessStore($stock->store_id)) {
            return response()->json([
                'success' => false,
                'message' => 'Você não tem permissão para acessar esta loja.',
            ], 403);
        }

        $validated = $request->validate([
            'quantity' => 'sometimes|integer|min:0',
            'min_stock' => 'nullable|numeric|min:0',
            'max_stock' => 'nullable|numeric|min:0',
            'shelf' => 'nullable|string|max:50',
            'notes' => 'nullable|string|max:1000',
        ]);

        $stock->update($validated);

        return response()->json([
            'success' => true,
            'message' => 'Estoque atualizado com sucesso!',
            'stock' => $stock->load(['store', 'fabric', 'color', 'cutType']),
        ]);
    }

    /**
     * Reservar estoque
     */
    public function reserve(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'store_id' => 'required|exists:stores,id',
            'fabric_id' => 'nullable|exists:product_options,id',
            'color_id' => 'nullable|exists:product_options,id',
            'cut_type_id' => 'nullable|exists:product_options,id',
            'size' => 'required|string|in:PP,P,M,G,GG,EXG,G1,G2,G3',
            'quantity' => 'required|integer|min:1',
        ]);

        $stock = Stock::findByParams(
            $validated['store_id'],
            $validated['fabric_id'],
            $validated['color_id'],
            $validated['cut_type_id'],
            $validated['size']
        );

        if (!$stock) {
            return response()->json([
                'success' => false,
                'message' => 'Estoque não encontrado.',
            ], 404);
        }

        if (!$stock->reserve($validated['quantity'])) {
            return response()->json([
                'success' => false,
                'message' => 'Estoque insuficiente. Disponível: ' . $stock->available_quantity,
                'available_quantity' => $stock->available_quantity,
            ], 400);
        }

        return response()->json([
            'success' => true,
            'message' => 'Estoque reservado com sucesso!',
            'stock' => $stock->fresh(),
        ]);
    }

    /**
     * Liberar estoque reservado
     */
    public function release(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'store_id' => 'required|exists:stores,id',
            'fabric_id' => 'nullable|exists:product_options,id',
            'color_id' => 'nullable|exists:product_options,id',
            'cut_type_id' => 'nullable|exists:product_options,id',
            'size' => 'required|string|in:PP,P,M,G,GG,EXG,G1,G2,G3',
            'quantity' => 'required|integer|min:1',
        ]);

        $stock = Stock::findByParams(
            $validated['store_id'],
            $validated['fabric_id'],
            $validated['color_id'],
            $validated['cut_type_id'],
            $validated['size']
        );

        if (!$stock) {
            return response()->json([
                'success' => false,
                'message' => 'Estoque não encontrado.',
            ], 404);
        }

        $stock->release($validated['quantity']);

        return response()->json([
            'success' => true,
            'message' => 'Estoque liberado com sucesso!',
            'stock' => $stock->fresh(),
        ]);
    }
    /**
     * Editar grupo de estoque
     */
    public function edit(Request $request): View
    {
        $storeId = $request->get('store_id');
        $fabricId = $request->get('fabric_id');
        $colorId = $request->get('color_id');
        $cutTypeId = $request->get('cut_type_id');

        if (!$storeId || !$fabricId || !$colorId || !$cutTypeId) {
            abort(404, 'Parâmetros insuficientes para editar o estoque.');
        }

        // Buscar todos os estoques deste grupo
        $stocks = Stock::where('store_id', $storeId)
            ->where('fabric_id', $fabricId)
            ->where('color_id', $colorId)
            ->where('cut_type_id', $cutTypeId)
            ->get();

        if ($stocks->isEmpty()) {
            abort(404, 'Estoque não encontrado.');
        }

        // Carregar modelos relacionados para exibição
        $store = Store::findOrFail($storeId);
        $fabric = ProductOption::findOrFail($fabricId);
        $color = ProductOption::findOrFail($colorId);
        $cutType = ProductOption::findOrFail($cutTypeId);

        // Preparar dados para o formulário
        $sizes = ['PP', 'P', 'M', 'G', 'GG', 'EXG', 'G1', 'G2', 'G3'];
        $currentQuantities = [];
        $reservedQuantities = [];
        $commonShelf = null;
        $commonMinStock = 0;
        $commonMaxStock = null;
        $commonNotes = null;

        foreach ($stocks as $stock) {
            $currentQuantities[$stock->size] = $stock->quantity;
            $reservedQuantities[$stock->size] = $stock->reserved_quantity;
            
            // Pegar valores comuns do primeiro item encontrado (assumindo consistência)
            if ($commonShelf === null) $commonShelf = $stock->shelf;
            if ($commonMinStock === 0) $commonMinStock = $stock->min_stock;
            if ($commonMaxStock === null) $commonMaxStock = $stock->max_stock;
            if ($commonNotes === null) $commonNotes = $stock->notes;
        }

        return view('stocks.edit', compact(
            'store',
            'fabric',
            'color',
            'cutType',
            'sizes',
            'currentQuantities',
            'reservedQuantities',
            'commonShelf',
            'commonMinStock',
            'commonMaxStock',
            'commonNotes'
        ));
    }

    /**
     * Atualizar grupo de estoque
     */
    public function updateGroup(Request $request)
    {
        $validated = $request->validate([
            'store_id' => 'required|exists:stores,id',
            'fabric_id' => 'required|exists:product_options,id',
            'color_id' => 'required|exists:product_options,id',
            'cut_type_id' => 'required|exists:product_options,id',
            'sizes' => 'required|array',
            'sizes.*' => 'nullable|integer|min:0',
            'shelf' => 'nullable|string|max:50',
            'min_stock' => 'nullable|numeric|min:0',
            'max_stock' => 'nullable|numeric|min:0',
            'notes' => 'nullable|string|max:1000',
        ]);

        // Verificar permissão
        if (!StoreHelper::canAccessStore($validated['store_id'])) {
            return redirect()->back()->with('error', 'Você não tem permissão para acessar esta loja.');
        }

        $sizes = ['PP', 'P', 'M', 'G', 'GG', 'EXG', 'G1', 'G2', 'G3'];
        $updatedCount = 0;
        $createdCount = 0;

        $shelf = isset($validated['shelf']) ? trim($validated['shelf']) : null;

        foreach ($sizes as $size) {
            $quantity = isset($validated['sizes'][$size]) ? (int)$validated['sizes'][$size] : 0;
            
            // Buscar estoque existente ou criar novo
            $stock = Stock::firstOrNew([
                'store_id' => $validated['store_id'],
                'fabric_id' => $validated['fabric_id'],
                'color_id' => $validated['color_id'],
                'cut_type_id' => $validated['cut_type_id'],
                'size' => $size
            ]);

            $isNew = !$stock->exists;

            // Se for novo e quantidade for 0, ignorar
            if ($isNew && $quantity == 0) {
                continue;
            }

            // Atualizar dados
            $stock->quantity = $quantity;
            $stock->shelf = $shelf;
            $stock->min_stock = $validated['min_stock'] ?? 0;
            $stock->max_stock = $validated['max_stock'] ?? null;
            $stock->notes = $validated['notes'] ?? null;
            
            $stock->save();

            if ($isNew) {
                $createdCount++;
            } else {
                $updatedCount++;
            }
            
            // Verificar estoque baixo
            $this->checkLowStock($stock);
        }

        return redirect()->route('stocks.index')->with('success', 'Estoque atualizado com sucesso!');
    }
}
