<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\ProductOption;
use App\Models\SizeSurcharge;
use App\Models\Client;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Status;
use App\Models\Store;
use App\Models\Payment;
use App\Models\CashTransaction;
use App\Models\Stock;
use App\Models\StockRequest;
use App\Models\User;
use App\Helpers\StoreHelper;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Dompdf\Dompdf;
use Dompdf\Options;

class PDVController extends Controller
{
    /**
     * Exibir página do PDV
     */
    public function index(Request $request)
    {
        $search = $request->get('search');

        // Buscar produtos apenas se a tabela existir
        $products = collect();
        if (Schema::hasTable('products')) {
            try {
                $query = Product::with(['category', 'subcategory', 'tecido', 'personalizacao', 'modelo', 'images'])
                    ->where('active', true);
                
                if ($search) {
                    $query->where(function($q) use ($search) {
                        $q->where('title', 'like', "%{$search}%")
                          ->orWhereHas('category', function($q) use ($search) {
                              $q->where('name', 'like', "%{$search}%");
                          });
                    });
                }
                
                $products = $query->orderBy('title')->get();
            } catch (\Exception $e) {
                // Se houver erro, usar collection vazia
                $products = collect();
            }
        }

        // Buscar ID da personalização SUB. LOCAL primeiro
        $subLocalPersonalizationId = null;
        if (Schema::hasTable('product_options')) {
            try {
                $subLocal = ProductOption::where('type', 'personalizacao')
                    ->where('name', 'SUB. LOCAL')
                    ->first();
                $subLocalPersonalizationId = $subLocal ? $subLocal->id : null;
            } catch (\Exception $e) {
                // Ignorar erro
            }
        }
        
        // Buscar product_options do tipo tipo_corte
        $productOptions = collect();
        $productOptionsWithSublocal = collect();
        if (Schema::hasTable('product_options')) {
            try {
                $query = ProductOption::where('type', 'tipo_corte')
                    ->where('active', true);
                
                if ($search) {
                    $query->where('name', 'like', "%{$search}%");
                }
                
                $productOptions = $query->orderBy('order')
                    ->orderBy('name')
                    ->get();
                
                // Verificar quais permitem SUB.LOCAL
                if ($subLocalPersonalizationId && Schema::hasTable('product_option_relations')) {
                    try {
                        $productOptionsWithSublocal = $productOptions->map(function($o) use ($subLocalPersonalizationId) {
                            $allowsSublocal = false;
                            $fabricId = null;
                            
                            try {
                                // Buscar o tecido relacionado ao tipo_corte
                                $o->load('parent.parent');
                                
                                if ($o->parent_id && $o->parent) {
                                    if ($o->parent->type === 'tipo_tecido' && $o->parent->parent_id) {
                                        $tipoTecido = $o->parent;
                                        if ($tipoTecido->parent && $tipoTecido->parent->type === 'tecido') {
                                            $fabricId = $tipoTecido->parent->id;
                                        }
                                    } elseif ($o->parent->type === 'tecido') {
                                        $fabricId = $o->parent->id;
                                    }
                                }
                                
                                // Se não encontrou, tentar buscar via relacionamento muitos-para-muitos
                                if (!$fabricId && Schema::hasTable('product_option_relations')) {
                                    $fabricRelation = DB::table('product_option_relations')
                                        ->join('product_options', 'product_option_relations.parent_id', '=', 'product_options.id')
                                        ->where('product_option_relations.option_id', $o->id)
                                        ->where('product_options.type', 'tecido')
                                        ->select('product_options.id', 'product_options.name')
                                        ->first();
                                    
                                    if ($fabricRelation) {
                                        $fabricId = $fabricRelation->id;
                                    }
                                }
                                
                                // Verificar se o tecido permite SUB.LOCAL
                                if ($fabricId) {
                                    $relation = DB::table('product_option_relations')
                                        ->where('option_id', $fabricId)
                                        ->where('parent_id', $subLocalPersonalizationId)
                                        ->first();
                                    
                                    $allowsSublocal = $relation !== null;
                                }
                            } catch (\Exception $e) {
                                // Se houver erro ao verificar, apenas não permitir sub.local
                                $allowsSublocal = false;
                            }
                            
                            return [
                                'id' => $o->id,
                                'allows_sublocal' => $allowsSublocal,
                                'fabric_id' => $fabricId
                            ];
                        })->keyBy('id');
                    } catch (\Exception $e) {
                        // Se houver erro, usar collection vazia
                        $productOptionsWithSublocal = collect();
                    }
                }
            } catch (\Exception $e) {
                // Se houver erro, usar collection vazia
                $productOptions = collect();
            }
        }

        // Combinar produtos e opções
        $allItems = $products->concat($productOptions);
        
        // Paginar manualmente
        $perPage = 8; // 12 itens por página (bom para grid de 1, 2 ou 3 colunas)
        $currentPage = $request->get('page', 1);
        $offset = ($currentPage - 1) * $perPage;
        $paginatedItems = new \Illuminate\Pagination\LengthAwarePaginator(
            $allItems->slice($offset, $perPage)->values(),
            $allItems->count(),
            $perPage,
            $currentPage,
            ['path' => $request->url(), 'query' => $request->query()]
        );

        $clients = Client::orderBy('name')->get();
        $cart = Session::get('pdv_cart', []);
        
        // Buscar locations de sublimação para usar em personalizações
        $locations = collect();
        if (Schema::hasTable('sublimation_locations')) {
            try {
                $locations = \App\Models\SublimationLocation::where('active', true)
                    ->orderBy('name')
                    ->get();
            } catch (\Exception $e) {
                $locations = collect();
            }
        }

        // Buscar tecidos e cores para controle de estoque
        $fabrics = collect();
        $colors = collect();
        if (Schema::hasTable('product_options')) {
            try {
                $fabrics = ProductOption::where('type', 'tecido')
                    ->where('active', true)
                    ->orderBy('name')
                    ->get();
                $colors = ProductOption::where('type', 'cor')
                    ->where('active', true)
                    ->orderBy('name')
                    ->get();
            } catch (\Exception $e) {
                // Ignorar erro
            }
        }

        // Obter loja atual do usuário
        $user = Auth::user();
        $currentStoreId = null;
        if ($user->isAdminLoja()) {
            $storeIds = $user->getStoreIds();
            $currentStoreId = !empty($storeIds) ? $storeIds[0] : null;
        } elseif ($user->isVendedor()) {
            $userStores = $user->stores()->get();
            if ($userStores->isNotEmpty()) {
                $currentStoreId = $userStores->first()->id;
            }
        }
        
        if (!$currentStoreId) {
            $mainStore = Store::where('is_main', true)->first();
            $currentStoreId = $mainStore ? $mainStore->id : null;
        }

        return view('pdv.index', compact(
            'paginatedItems',
            'products', 
            'productOptions', 
            'clients', 
            'cart', 
            'locations', 
            'subLocalPersonalizationId', 
            'productOptionsWithSublocal',
            'fabrics',
            'colors',
            'currentStoreId',
            'search'
        ));
    }

    /**
     * Adicionar item ao carrinho
     */
    public function addToCart(Request $request)
    {
        $validated = $request->validate([
            'product_id' => 'nullable|exists:products,id',
            'product_option_id' => 'nullable|exists:product_options,id',
            'quantity' => 'required|numeric|min:0.01',
            'unit_price' => 'nullable|numeric|min:0',
            'application_type' => 'nullable|in:sublimacao_local,dtf',
            'size_quantities' => 'nullable|array',
            'size_quantities.GG' => 'nullable|integer|min:0',
            'size_quantities.EXG' => 'nullable|integer|min:0',
            'size_quantities.G1' => 'nullable|integer|min:0',
            'size_quantities.G2' => 'nullable|integer|min:0',
            'size_quantities.G3' => 'nullable|integer|min:0',
            'sublocal_personalizations' => 'nullable|array',
            'sublocal_personalizations.*.location_id' => 'nullable|exists:sublimation_locations,id',
            'sublocal_personalizations.*.location_name' => 'nullable|string',
            'sublocal_personalizations.*.size_name' => 'nullable|string',
            'sublocal_personalizations.*.quantity' => 'nullable|integer|min:1',
            'sublocal_personalizations.*.unit_price' => 'nullable|numeric|min:0',
            'sublocal_personalizations.*.final_price' => 'nullable|numeric|min:0',
            // Campos para controle de estoque
            'size' => 'nullable|string|in:PP,P,M,G,GG,EXG,G1,G2,G3',
            'color_id' => 'nullable|exists:product_options,id',
            'cut_type_id' => 'nullable|exists:product_options,id',
            'fabric_id' => 'nullable|exists:product_options,id',
        ]);

        // Validar que apenas um dos dois seja fornecido
        $productId = $validated['product_id'] ?? null;
        $productOptionId = $validated['product_option_id'] ?? null;
        
        if (!$productId && !$productOptionId) {
            return response()->json([
                'success' => false,
                'message' => 'É necessário informar product_id ou product_option_id',
            ], 400);
        }

        if ($productId && $productOptionId) {
            return response()->json([
                'success' => false,
                'message' => 'Informe apenas product_id ou product_option_id, não ambos',
            ], 400);
        }

        $cart = Session::get('pdv_cart', []);
        $cartItem = [];

        // Verificar se é um produto normal ou product_option
        if ($productId) {
            // Verificar se a tabela products existe
            if (!Schema::hasTable('products')) {
                return response()->json([
                    'success' => false,
                    'message' => 'Tabela de produtos não existe',
                ], 400);
            }
            
            $product = Product::with(['category', 'subcategory', 'tecido', 'personalizacao', 'modelo'])
                ->findOrFail($productId);
            
            // Calcular preço unitário (usar o fornecido ou o preço do produto)
            $unitPrice = $validated['unit_price'] ?? $product->price ?? 0;
            $baseTotal = $unitPrice * $validated['quantity'];
            
            // Calcular acréscimos de tamanhos especiais
            // IMPORTANTE: Usar preço unitário, não o total, para determinar a faixa de acréscimo
            $sizeQuantities = $validated['size_quantities'] ?? [];
            $sizeSurcharges = [];
            $totalSurcharges = 0;
            
            if (!empty($sizeQuantities) && Schema::hasTable('size_surcharges')) {
                foreach (['GG', 'EXG', 'G1', 'G2', 'G3'] as $size) {
                    $qty = $sizeQuantities[$size] ?? 0;
                    if ($qty > 0 && $unitPrice > 0) {
                        // Usar preço unitário para determinar a faixa de acréscimo
                        $surchargeData = SizeSurcharge::getSurchargeForSize($size, $unitPrice);
                        if ($surchargeData) {
                            $surchargeTotal = $surchargeData->surcharge * $qty;
                            $sizeSurcharges[$size] = [
                                'quantity' => $qty,
                                'surcharge_per_unit' => $surchargeData->surcharge,
                                'total' => $surchargeTotal,
                            ];
                            $totalSurcharges += $surchargeTotal;
                        }
                    }
                }
            }

            $cartItem = [
                'id' => uniqid(),
                'type' => 'product',
                'product_id' => $product->id,
                'product_title' => $product->title,
                'category' => $product->category?->name,
                'subcategory' => $product->subcategory?->name,
                'sale_type' => $product->sale_type ?? 'unidade',
                'quantity' => $validated['quantity'],
                'unit_price' => $unitPrice,
                'total_price' => $baseTotal + $totalSurcharges,
                'base_price' => $baseTotal,
                'size_surcharges' => $sizeSurcharges,
                'total_surcharges' => $totalSurcharges,
                'application_type' => $validated['application_type'] ?? null,
            ];
        } elseif ($productOptionId) {
            // Verificar se a tabela product_options existe
            if (!Schema::hasTable('product_options')) {
                return response()->json([
                    'success' => false,
                    'message' => 'Tabela de opções de produtos não existe',
                ], 400);
            }
            
            $productOption = ProductOption::with('parent')->findOrFail($productOptionId);
            
            // Verificar se é do tipo tipo_corte
            if ($productOption->type !== 'tipo_corte') {
                return response()->json([
                    'success' => false,
                    'message' => 'Tipo de opção inválido',
                ], 400);
            }
            
            // Usar fabric_id fornecido ou buscar automaticamente
            $fabricName = 'Tipo de Corte'; // Valor padrão
            $fabricId = $validated['fabric_id'] ?? null;
            
            // Se não foi fornecido, buscar automaticamente
            if (!$fabricId) {
                // Carregar parent (tipo_tecido) e parent do parent (tecido)
                $productOption->load('parent.parent');
                
                // Se o parent for tipo_tecido e tiver um parent que é tecido
                if ($productOption->parent_id && $productOption->parent) {
                    if ($productOption->parent->type === 'tipo_tecido' && $productOption->parent->parent_id) {
                        $tipoTecido = $productOption->parent;
                        if ($tipoTecido->parent && $tipoTecido->parent->type === 'tecido') {
                            $fabricName = $tipoTecido->parent->name;
                            $fabricId = $tipoTecido->parent->id;
                        }
                    } elseif ($productOption->parent->type === 'tecido') {
                        // Se o parent direto for tecido
                        $fabricName = $productOption->parent->name;
                        $fabricId = $productOption->parent->id;
                    }
                }
                
                // Se não encontrou, tentar buscar via relacionamento muitos-para-muitos
                if (!$fabricId && Schema::hasTable('product_option_relations')) {
                    $fabricRelation = \DB::table('product_option_relations')
                        ->join('product_options', 'product_option_relations.parent_id', '=', 'product_options.id')
                        ->where('product_option_relations.option_id', $productOption->id)
                        ->where('product_options.type', 'tecido')
                        ->select('product_options.id', 'product_options.name')
                        ->first();
                    
                    if ($fabricRelation) {
                        $fabricName = $fabricRelation->name;
                        $fabricId = $fabricRelation->id;
                    }
                }
            } else {
                // Se foi fornecido, buscar o nome do tecido
                $fabric = ProductOption::find($fabricId);
                if ($fabric) {
                    $fabricName = $fabric->name;
                }
            }
            
            // Calcular preço unitário (para product_option, sempre usar o preço fixo do tipo de corte)
            // O preço não pode ser alterado pelo usuário, sempre usa o preço cadastrado no tipo de corte
            $unitPrice = $productOption->price ?? 0;
            
            if ($unitPrice <= 0) {
                return response()->json([
                    'success' => false,
                    'message' => 'Preço não configurado para este tipo de corte',
                ], 400);
            }
            $baseTotal = $unitPrice * $validated['quantity'];
            
            // Calcular acréscimos de tamanhos especiais
            // IMPORTANTE: Usar preço unitário, não o total, para determinar a faixa de acréscimo
            $sizeQuantities = $validated['size_quantities'] ?? [];
            $sizeSurcharges = [];
            $totalSurcharges = 0;
            
            if (!empty($sizeQuantities) && Schema::hasTable('size_surcharges')) {
                foreach (['GG', 'EXG', 'G1', 'G2', 'G3'] as $size) {
                    $qty = $sizeQuantities[$size] ?? 0;
                    if ($qty > 0 && $unitPrice > 0) {
                        // Usar preço unitário para determinar a faixa de acréscimo
                        $surchargeData = SizeSurcharge::getSurchargeForSize($size, $unitPrice);
                        if ($surchargeData) {
                            $surchargeTotal = $surchargeData->surcharge * $qty;
                            $sizeSurcharges[$size] = [
                                'quantity' => $qty,
                                'surcharge_per_unit' => $surchargeData->surcharge,
                                'total' => $surchargeTotal,
                            ];
                            $totalSurcharges += $surchargeTotal;
                        }
                    }
                }
            }

            // Processar personalizações sub.local se houver
            $sublocalPersonalizations = [];
            $sublocalTotal = 0;
            if (isset($validated['sublocal_personalizations']) && is_array($validated['sublocal_personalizations'])) {
                foreach ($validated['sublocal_personalizations'] as $personalization) {
                    if (!empty($personalization['location_id']) || !empty($personalization['location_name'])) {
                        $sublocalPersonalizations[] = [
                            'location_id' => $personalization['location_id'] ?? null,
                            'location_name' => $personalization['location_name'] ?? null,
                            'size_name' => $personalization['size_name'] ?? null,
                            'quantity' => $personalization['quantity'] ?? 1,
                            'unit_price' => $personalization['unit_price'] ?? 0,
                            'final_price' => $personalization['final_price'] ?? ($personalization['unit_price'] ?? 0) * ($personalization['quantity'] ?? 1),
                        ];
                        $sublocalTotal += $personalization['final_price'] ?? ($personalization['unit_price'] ?? 0) * ($personalization['quantity'] ?? 1);
                    }
                }
            }
            
            // Verificar estoque e criar solicitação se necessário
            $stockRequestCreated = false;
            if (isset($validated['size']) && isset($validated['color_id']) && isset($validated['cut_type_id']) && $fabricId) {
                $currentStoreId = $this->getCurrentStoreId();
                if ($currentStoreId) {
                    $stockRequestCreated = $this->checkStockAndCreateRequest(
                        $currentStoreId,
                        $fabricId,
                        $validated['color_id'],
                        $validated['cut_type_id'],
                        $validated['size'],
                        $validated['quantity']
                    );
                }
            }
            
            $cartItem = [
                'id' => uniqid(),
                'type' => 'product_option',
                'product_option_id' => $productOption->id,
                'product_title' => $productOption->name,
                'category' => $fabricName, // Usar o nome do tecido ao invés de "Tipo de Corte"
                'fabric_id' => $fabricId, // Salvar o ID do tecido para usar depois
                'subcategory' => null,
                'sale_type' => 'unidade',
                'quantity' => $validated['quantity'],
                'unit_price' => $unitPrice,
                'total_price' => $baseTotal + $totalSurcharges + $sublocalTotal,
                'base_price' => $baseTotal,
                'size_surcharges' => $sizeSurcharges,
                'total_surcharges' => $totalSurcharges,
                'application_type' => null,
                'sublocal_personalizations' => $sublocalPersonalizations,
                // Campos de estoque - IMPORTANTE: garantir que todos os campos estejam presentes
                'size' => $validated['size'] ?? null,
                'color_id' => $validated['color_id'] ?? null,
                'cut_type_id' => $validated['cut_type_id'] ?? $productOption->id,
                'fabric_id' => $fabricId, // Garantir que fabric_id está presente
            ];
            
            \Log::info('Item adicionado ao carrinho (product_option)', [
                'cart_item' => [
                    'type' => $cartItem['type'],
                    'size' => $cartItem['size'],
                    'color_id' => $cartItem['color_id'],
                    'cut_type_id' => $cartItem['cut_type_id'],
                    'fabric_id' => $cartItem['fabric_id'],
                    'quantity' => $cartItem['quantity'],
                ],
            ]);
        }

        $cart[] = $cartItem;
        Session::put('pdv_cart', $cart);
        
        \Log::info('Carrinho atualizado na sessão', [
            'cart_count' => count($cart),
            'last_item' => [
                'type' => $cartItem['type'] ?? null,
                'size' => $cartItem['size'] ?? null,
                'color_id' => $cartItem['color_id'] ?? null,
                'cut_type_id' => $cartItem['cut_type_id'] ?? null,
                'fabric_id' => $cartItem['fabric_id'] ?? null,
            ],
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Item adicionado ao carrinho',
            'cart' => $cart,
            'cart_total' => $this->calculateCartTotal($cart),
            'stock_request_created' => $stockRequestCreated ?? false,
        ]);
    }
    
    /**
     * Verificar estoque e criar solicitação se necessário
     */
    private function checkStockAndCreateRequest($storeId, $fabricId, $colorId, $cutTypeId, $size, $quantity, $orderId = null)
    {
        if (!Schema::hasTable('stocks') || !Schema::hasTable('stock_requests')) {
            \Log::warning('Tabelas de estoque não existem', [
                'stocks_table' => Schema::hasTable('stocks'),
                'stock_requests_table' => Schema::hasTable('stock_requests'),
            ]);
            return false;
        }
        
        try {
            \Log::info('Verificando estoque para criar solicitação', [
                'store_id' => $storeId,
                'fabric_id' => $fabricId,
                'color_id' => $colorId,
                'cut_type_id' => $cutTypeId,
                'size' => $size,
                'quantity' => $quantity,
                'order_id' => $orderId,
            ]);
            
            // Validar que o tamanho é válido (PP, P, M, G, GG, EXG, G1, G2, G3)
            $validSizes = ['PP', 'P', 'M', 'G', 'GG', 'EXG', 'G1', 'G2', 'G3'];
            if (!in_array($size, $validSizes)) {
                \Log::warning('Tamanho inválido', ['size' => $size, 'valid_sizes' => $validSizes]);
                return false;
            }
            
            // Validar que todos os campos necessários estão presentes
            if (!$storeId || !$fabricId || !$colorId || !$cutTypeId || !$size || !$quantity) {
                \Log::error('Campos obrigatórios faltando para criar solicitação de estoque', [
                    'store_id' => $storeId,
                    'fabric_id' => $fabricId,
                    'color_id' => $colorId,
                    'cut_type_id' => $cutTypeId,
                    'size' => $size,
                    'quantity' => $quantity,
                ]);
                return false;
            }
            
            // Verificar estoque para incluir na nota da solicitação
            $stock = Stock::findByParams($storeId, $fabricId, $colorId, $cutTypeId, $size);
            $hasStock = $stock && $stock->available_quantity >= $quantity;
            $availableQuantity = $stock ? $stock->available_quantity : 0;
            
            \Log::info('Criando solicitação de estoque para venda', [
                'stock_exists' => $stock !== null,
                'available_quantity' => $availableQuantity,
                'requested_quantity' => $quantity,
                'has_sufficient_stock' => $hasStock,
            ]);
            
            // SEMPRE criar solicitação de estoque quando houver uma venda
            // Isso permite que o estoquista controle e gerencie o estoque, mesmo quando há estoque disponível
            try {
                $requestNotes = $hasStock 
                    ? "Solicitação automática gerada pelo PDV - Estoque disponível: {$availableQuantity}"
                    : "Solicitação automática gerada pelo PDV - Estoque insuficiente (disponível: {$availableQuantity}, solicitado: {$quantity})";
                
                $stockRequest = StockRequest::create([
                    'order_id' => $orderId, // Pedido que gerou a solicitação
                    'requesting_store_id' => $storeId, // Loja que está solicitando
                    'target_store_id' => null, // Pode ser preenchido depois quando encontrar loja com estoque
                    'fabric_id' => $fabricId,
                    'color_id' => $colorId,
                    'cut_type_id' => $cutTypeId,
                    'size' => $size, // String: PP, P, M, G, GG, EXG, G1, G2, G3
                    'requested_quantity' => $quantity,
                    'status' => 'pendente', // Status correto conforme enum da migration
                    'requested_by' => Auth::id(), // Campo correto conforme migration
                    'request_notes' => $requestNotes,
                ]);
                
                \Log::info('Solicitação de estoque criada com sucesso', [
                    'stock_request_id' => $stockRequest->id,
                    'order_id' => $orderId,
                    'store_id' => $storeId,
                    'fabric_id' => $fabricId,
                    'color_id' => $colorId,
                    'cut_type_id' => $cutTypeId,
                    'size' => $size,
                    'quantity' => $quantity,
                    'has_stock' => $hasStock,
                ]);
                
                return true;
            } catch (\Exception $e) {
                \Log::error('Erro ao criar solicitação de estoque', [
                    'error' => $e->getMessage(),
                    'trace' => $e->getTraceAsString(),
                    'store_id' => $storeId,
                    'fabric_id' => $fabricId,
                    'color_id' => $colorId,
                    'cut_type_id' => $cutTypeId,
                    'size' => $size,
                    'quantity' => $quantity,
                ]);
                return false;
            }
        } catch (\Exception $e) {
            \Log::error('Erro ao verificar estoque e criar solicitação', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
                'store_id' => $storeId,
                'fabric_id' => $fabricId,
                'color_id' => $colorId,
                'cut_type_id' => $cutTypeId,
                'size' => $size,
                'quantity' => $quantity,
            ]);
        }
        
        return false;
    }
    
    /**
     * Obter ID da loja atual
     */
    private function getCurrentStoreId()
    {
        $user = Auth::user();
        if ($user->isAdminLoja()) {
            $storeIds = $user->getStoreIds();
            return !empty($storeIds) ? $storeIds[0] : null;
        } elseif ($user->isVendedor()) {
            $userStores = $user->stores()->get();
            if ($userStores->isNotEmpty()) {
                return $userStores->first()->id;
            }
        }
        
        $mainStore = Store::where('is_main', true)->first();
        return $mainStore ? $mainStore->id : null;
    }

    /**
     * Atualizar item do carrinho
     */
    public function updateCart(Request $request)
    {
        $validated = $request->validate([
            'item_id' => 'required|string',
            'quantity' => 'nullable|numeric|min:0.01',
            'unit_price' => 'nullable|numeric|min:0',
        ]);

        $cart = Session::get('pdv_cart', []);
        $itemFound = false;

        foreach ($cart as $index => $item) {
            if ($item['id'] === $validated['item_id']) {
                if (isset($validated['quantity'])) {
                    $cart[$index]['quantity'] = $validated['quantity'];
                }
                if (isset($validated['unit_price'])) {
                    $cart[$index]['unit_price'] = $validated['unit_price'];
                }
                
                // Recalcular total_price incluindo acréscimos e personalizações sub.local
                $baseTotal = $cart[$index]['quantity'] * $cart[$index]['unit_price'];
                
                // Recalcular acréscimos de tamanhos se houver
                $totalSurcharges = 0;
                if (isset($cart[$index]['size_surcharges']) && !empty($cart[$index]['size_surcharges'])) {
                    // Recalcular acréscimos baseado no novo preço unitário
                    $unitPrice = $cart[$index]['unit_price'];
                    $sizeQuantities = [];
                    foreach ($cart[$index]['size_surcharges'] as $size => $data) {
                        $sizeQuantities[$size] = $data['quantity'];
                    }
                    
                    if (!empty($sizeQuantities) && Schema::hasTable('size_surcharges')) {
                        $newSizeSurcharges = [];
                        foreach (['GG', 'EXG', 'G1', 'G2', 'G3'] as $size) {
                            $qty = $sizeQuantities[$size] ?? 0;
                            if ($qty > 0 && $unitPrice > 0) {
                                $surchargeData = SizeSurcharge::getSurchargeForSize($size, $unitPrice);
                                if ($surchargeData) {
                                    $surchargeTotal = $surchargeData->surcharge * $qty;
                                    $newSizeSurcharges[$size] = [
                                        'quantity' => $qty,
                                        'surcharge_per_unit' => $surchargeData->surcharge,
                                        'total' => $surchargeTotal,
                                    ];
                                    $totalSurcharges += $surchargeTotal;
                                }
                            }
                        }
                        $cart[$index]['size_surcharges'] = $newSizeSurcharges;
                        $cart[$index]['total_surcharges'] = $totalSurcharges;
                    }
                }
                
                // Incluir total de personalizações sub.local se houver
                $sublocalTotal = 0;
                if (isset($cart[$index]['sublocal_personalizations']) && is_array($cart[$index]['sublocal_personalizations'])) {
                    foreach ($cart[$index]['sublocal_personalizations'] as $personalization) {
                        $sublocalTotal += $personalization['final_price'] ?? 0;
                    }
                }
                
                $cart[$index]['total_price'] = $baseTotal + $totalSurcharges + $sublocalTotal;
                $cart[$index]['base_price'] = $baseTotal;
                $itemFound = true;
                break;
            }
        }

        if (!$itemFound) {
            return response()->json([
                'success' => false,
                'message' => 'Item não encontrado no carrinho',
            ], 404);
        }

        Session::put('pdv_cart', $cart);

        return response()->json([
            'success' => true,
            'message' => 'Item atualizado',
            'cart' => $cart,
            'cart_total' => $this->calculateCartTotal($cart),
        ]);
    }

    /**
     * Remover item do carrinho
     */
    public function removeFromCart(Request $request)
    {
        $validated = $request->validate([
            'item_id' => 'required|string',
        ]);

        $cart = Session::get('pdv_cart', []);
        $cart = array_filter($cart, function($item) use ($validated) {
            return $item['id'] !== $validated['item_id'];
        });

        // Reindexar array
        $cart = array_values($cart);
        Session::put('pdv_cart', $cart);

        return response()->json([
            'success' => true,
            'message' => 'Item removido do carrinho',
            'cart' => $cart,
            'cart_total' => $this->calculateCartTotal($cart),
        ]);
    }

    /**
     * Limpar carrinho
     */
    public function clearCart()
    {
        Session::forget('pdv_cart');

        return response()->json([
            'success' => true,
            'message' => 'Carrinho limpo',
            'cart' => [],
            'cart_total' => 0,
        ]);
    }

    /**
     * Obter carrinho
     */
    public function getCart()
    {
        $cart = Session::get('pdv_cart', []);

        return response()->json([
            'cart' => $cart,
            'cart_total' => $this->calculateCartTotal($cart),
            'cart_count' => count($cart),
        ]);
    }

    /**
     * Finalizar venda (checkout)
     */
    public function checkout(Request $request)
    {
        \Log::info('=== PDV CHECKOUT ===');
        \Log::info('Request data:', $request->all());
        
        // Normalizar client_id antes da validação
        $clientId = $request->input('client_id');
        \Log::info('Client ID recebido:', ['client_id' => $clientId, 'type' => gettype($clientId)]);
        
        // Converter qualquer valor vazio para null
        if ($clientId === '' || $clientId === null || $clientId === 'null' || $clientId === 0 || $clientId === '0') {
            $request->merge(['client_id' => null]);
            $clientId = null;
            \Log::info('Client ID normalizado para null');
        }
        
        // Validação
        $rules = [
            'discount' => 'nullable|numeric|min:0',
            'delivery_fee' => 'nullable|numeric|min:0',
            'notes' => 'nullable|string|max:1000',
            'payment_methods' => 'required|array|min:1',
            'payment_methods.*.method' => 'required|string',
            'payment_methods.*.amount' => 'required|numeric|min:0.01',
        ];
        
        // Adicionar validação de client_id apenas se fornecido
        if ($clientId !== null && $clientId !== '') {
            $rules['client_id'] = 'required|exists:clients,id';
            \Log::info('Validando client_id como required|exists');
        } else {
            $rules['client_id'] = 'nullable';
            \Log::info('Validando client_id como nullable');
        }
        
        try {
            $validated = $request->validate($rules);
            \Log::info('Validação passou:', $validated);
        } catch (\Illuminate\Validation\ValidationException $e) {
            \Log::error('Erro de validação:', $e->errors());
            throw $e;
        }
        
        // Garantir que client_id seja null se não fornecido
        $validated['client_id'] = $validated['client_id'] ?? null;
        \Log::info('Client ID final:', ['client_id' => $validated['client_id']]);

        $cart = Session::get('pdv_cart', []);

        if (empty($cart)) {
            return response()->json([
                'success' => false,
                'message' => 'Carrinho vazio',
            ], 400);
        }

        // Calcular totais
        $subtotal = $this->calculateCartTotal($cart);
        $discount = $validated['discount'] ?? 0;
        $deliveryFee = $validated['delivery_fee'] ?? 0;
        $total = $subtotal - $discount + $deliveryFee;

        // Venda PDV: Status "Entregue" (finalizada)
        $status = Status::where('name', 'Entregue')->first();
        if (!$status) {
            // Se não encontrar "Entregue", usar o último status (maior position)
            $status = Status::orderBy('position', 'desc')->first();
        }

        // Obter store_id
        $user = Auth::user();
        $storeId = null;
        
        if ($user->isAdminLoja()) {
            $storeIds = $user->getStoreIds();
            $storeId = !empty($storeIds) ? $storeIds[0] : null;
        } elseif ($user->isVendedor()) {
            $userStores = $user->stores()->get();
            if ($userStores->isNotEmpty()) {
                $storeId = $userStores->first()->id;
            }
        }
        
        // Se ainda não encontrou, usar loja principal
        if (!$storeId) {
            $mainStore = Store::where('is_main', true)->first();
            $storeId = $mainStore ? $mainStore->id : null;
        }

        // Criar pedido (marcado como venda PDV)
        $order = Order::create([
            'client_id' => $validated['client_id'] ?? null,
            'user_id' => Auth::id(),
            'store_id' => $storeId,
            'status_id' => $status?->id ?? 1,
            'order_date' => Carbon::now('America/Sao_Paulo')->toDateString(),
            'delivery_date' => Carbon::now('America/Sao_Paulo')->addDays(15)->toDateString(),
            'is_draft' => false,
            'is_pdv' => true, // Sempre True para Venda PDV
            'client_confirmed' => true, // Vendas do PDV não precisam de confirmação do cliente
            'client_confirmed_at' => Carbon::now('America/Sao_Paulo'), // Marcar como confirmado automaticamente
            'subtotal' => $subtotal,
            'discount' => $discount,
            'delivery_fee' => $deliveryFee,
            'total' => $total,
            'total_items' => array_sum(array_column($cart, 'quantity')),
            'notes' => $validated['notes'] ?? null,
        ]);

        // Criar itens do pedido
        $itemNumber = 1;
        $stockRequestsCreated = [];
        
        \Log::info('Iniciando processamento do checkout - Carrinho completo', [
            'cart_count' => count($cart),
            'cart_items' => array_map(function($item) {
                return [
                    'type' => $item['type'] ?? null,
                    'size' => $item['size'] ?? null,
                    'color_id' => $item['color_id'] ?? null,
                    'cut_type_id' => $item['cut_type_id'] ?? null,
                    'fabric_id' => $item['fabric_id'] ?? null,
                    'quantity' => $item['quantity'] ?? null,
                ];
            }, $cart),
        ]);
        
        foreach ($cart as $cartItem) {
            $orderItemData = [
                'order_id' => $order->id,
                'item_number' => $itemNumber++,
                'fabric' => isset($cartItem['fabric_id']) && $cartItem['fabric_id'] ? $cartItem['fabric_id'] : ($cartItem['category'] ?? ''),
                'color' => $cartItem['subcategory'] ?? '',
                'print_type' => $cartItem['product_title'] ?? '',
                'quantity' => $cartItem['quantity'],
                'unit_price' => $cartItem['unit_price'],
                'total_price' => $cartItem['total_price'],
            ];
            
            // Se for product_option do tipo tipo_corte, salvar o ID no campo model
            if (isset($cartItem['type']) && $cartItem['type'] === 'product_option' && isset($cartItem['product_option_id'])) {
                $orderItemData['model'] = $cartItem['product_option_id'];
            }
            
            // Salvar tamanhos especiais (GG, EXG, G1, G2, G3) no campo sizes
            if (isset($cartItem['size_surcharges']) && !empty($cartItem['size_surcharges'])) {
                $sizes = [];
                foreach ($cartItem['size_surcharges'] as $size => $data) {
                    if (isset($data['quantity']) && $data['quantity'] > 0) {
                        $sizes[$size] = $data['quantity'];
                    }
                }
                if (!empty($sizes)) {
                    $orderItemData['sizes'] = $sizes;
                }
            }
            
            $orderItem = OrderItem::create($orderItemData);
            
            // Verificar estoque e descontar ou criar solicitação se for product_option
            if (isset($cartItem['type']) && $cartItem['type'] === 'product_option' 
                && isset($cartItem['size']) && isset($cartItem['color_id']) 
                && isset($cartItem['cut_type_id']) && isset($cartItem['fabric_id'])) {
                
                \Log::info('Processando item do carrinho para verificação de estoque', [
                    'cart_item' => [
                        'type' => $cartItem['type'] ?? null,
                        'size' => $cartItem['size'] ?? null,
                        'color_id' => $cartItem['color_id'] ?? null,
                        'cut_type_id' => $cartItem['cut_type_id'] ?? null,
                        'fabric_id' => $cartItem['fabric_id'] ?? null,
                        'quantity' => $cartItem['quantity'] ?? null,
                    ],
                ]);
                
                // Tentar descontar do estoque
                $stockDeducted = $this->deductStockFromSale(
                    $storeId,
                    $cartItem['fabric_id'],
                    $cartItem['color_id'],
                    $cartItem['cut_type_id'],
                    $cartItem['size'],
                    (int)$cartItem['quantity']
                );
                
                \Log::info('Resultado da tentativa de desconto de estoque', [
                    'stock_deducted' => $stockDeducted,
                    'store_id' => $storeId,
                    'fabric_id' => $cartItem['fabric_id'],
                    'color_id' => $cartItem['color_id'],
                    'cut_type_id' => $cartItem['cut_type_id'],
                    'size' => $cartItem['size'],
                    'quantity' => $cartItem['quantity'],
                ]);
                
                // SEMPRE criar solicitação de estoque quando houver uma venda, independente de ter estoque ou não
                // Isso permite que o estoquista controle e gerencie o estoque
                \Log::info('Criando solicitação de estoque para venda', [
                    'order_id' => $order->id,
                    'cart_item_data' => [
                        'fabric_id' => $cartItem['fabric_id'] ?? null,
                        'color_id' => $cartItem['color_id'] ?? null,
                        'cut_type_id' => $cartItem['cut_type_id'] ?? null,
                        'size' => $cartItem['size'] ?? null,
                        'quantity' => $cartItem['quantity'] ?? null,
                        'stock_deducted' => $stockDeducted,
                    ],
                ]);
                
                $requestCreated = $this->checkStockAndCreateRequest(
                    $storeId,
                    $cartItem['fabric_id'],
                    $cartItem['color_id'],
                    $cartItem['cut_type_id'],
                    $cartItem['size'],
                    (int)$cartItem['quantity'],
                    $order->id // Passar o order_id
                );
                
                \Log::info('Resultado da criação de solicitação', [
                    'request_created' => $requestCreated,
                    'order_id' => $order->id,
                    'store_id' => $storeId,
                    'fabric_id' => $cartItem['fabric_id'],
                    'color_id' => $cartItem['color_id'],
                    'cut_type_id' => $cartItem['cut_type_id'],
                    'size' => $cartItem['size'],
                    'quantity' => $cartItem['quantity'],
                ]);
                
                if ($requestCreated) {
                    $stockRequestsCreated[] = [
                        'size' => $cartItem['size'],
                        'quantity' => $cartItem['quantity'],
                    ];
                    \Log::info('Solicitação adicionada ao array de solicitações criadas', [
                        'total_requests' => count($stockRequestsCreated),
                    ]);
                } else {
                    \Log::warning('Falha ao criar solicitação de estoque', [
                        'order_id' => $order->id,
                        'store_id' => $storeId,
                        'fabric_id' => $cartItem['fabric_id'],
                        'color_id' => $cartItem['color_id'],
                        'cut_type_id' => $cartItem['cut_type_id'],
                        'size' => $cartItem['size'],
                        'quantity' => $cartItem['quantity'],
                    ]);
                }
            } else {
                \Log::warning('Item do carrinho não possui dados necessários para verificação de estoque', [
                    'cart_item' => [
                        'type' => $cartItem['type'] ?? null,
                        'has_size' => isset($cartItem['size']),
                        'has_color_id' => isset($cartItem['color_id']),
                        'has_cut_type_id' => isset($cartItem['cut_type_id']),
                        'has_fabric_id' => isset($cartItem['fabric_id']),
                    ],
                ]);
            }
            
            // Criar personalizações sub.local se houver
            $sublimationsTotal = 0;
            if (isset($cartItem['sublocal_personalizations']) && is_array($cartItem['sublocal_personalizations']) && !empty($cartItem['sublocal_personalizations'])) {
                foreach ($cartItem['sublocal_personalizations'] as $personalization) {
                    if (!empty($personalization['location_id']) || !empty($personalization['location_name'])) {
                        $finalPrice = $personalization['final_price'] ?? ($personalization['unit_price'] ?? 0) * ($personalization['quantity'] ?? 1);
                        $sublimationsTotal += $finalPrice;
                        
                        \App\Models\OrderSublimation::create([
                            'order_item_id' => $orderItem->id,
                            'application_type' => 'sublimacao_local',
                            'art_name' => null,
                            'size_id' => null,
                            'size_name' => $personalization['size_name'] ?? null,
                            'location_id' => $personalization['location_id'] ?? null,
                            'location_name' => $personalization['location_name'] ?? null,
                            'quantity' => $personalization['quantity'] ?? 1,
                            'color_count' => 0,
                            'has_neon' => false,
                            'neon_surcharge' => 0,
                            'unit_price' => $personalization['unit_price'] ?? 0,
                            'discount_percent' => 0,
                            'final_price' => $finalPrice,
                            'application_image' => null,
                            'color_details' => null,
                            'seller_notes' => null,
                        ]);
                    }
                }
                
                // Garantir que o total_price do item inclua as personalizações
                // O total_price já vem do carrinho com as personalizações, mas vamos garantir
                $baseTotal = $orderItem->unit_price * $orderItem->quantity;
                $expectedTotal = $baseTotal + $sublimationsTotal;
                
                // Se o total_price não estiver correto, atualizar
                if (abs($orderItem->total_price - $expectedTotal) > 0.01) {
                    $orderItem->update(['total_price' => $expectedTotal]);
                }
            }
        }

        // Processar formas de pagamento
        $paymentMethods = $validated['payment_methods'];
        
        // Garantir que cada método tenha um ID
        foreach ($paymentMethods as $index => $method) {
            if (!isset($method['id'])) {
                $paymentMethods[$index]['id'] = time() . rand(1000, 9999) . $index;
            }
        }
        
        $totalPaid = array_sum(array_column($paymentMethods, 'amount'));
        
        // Validar que o total pago não exceda o total do pedido (com tolerância para erros de ponto flutuante)
        if (round($totalPaid, 2) > round($total, 2)) {
            return response()->json([
                'success' => false,
                'message' => 'O valor total pago (R$ ' . number_format($totalPaid, 2, ',', '.') . ') não pode exceder o total do pedido (R$ ' . number_format($total, 2, ',', '.') . ').',
            ], 400);
        }
        
        $primaryMethod = count($paymentMethods) === 1 ? $paymentMethods[0]['method'] : 'pix';
        
        // Criar registro de pagamento
        $payment = Payment::create([
            'order_id' => $order->id,
            'method' => $primaryMethod,
            'payment_method' => count($paymentMethods) > 1 ? 'multiplo' : $primaryMethod,
            'payment_methods' => $paymentMethods,
            'amount' => $total,
            'entry_amount' => $totalPaid,
            'remaining_amount' => max(0, $total - $totalPaid),
            'entry_date' => Carbon::now('America/Sao_Paulo'),
            'payment_date' => Carbon::now('America/Sao_Paulo'),
            'status' => $totalPaid >= $total ? 'pago' : 'pendente',
        ]);

        // Registrar entrada(s) no caixa como "concluído" (venda finalizada)
        $user = Auth::user();
        $client = $order->client;
        foreach ($paymentMethods as $method) {
            CashTransaction::create([
                'user_id' => $user->id,
                'user_name' => $user->name,
                'order_id' => $order->id,
                'store_id' => $storeId,
                'type' => 'entrada',
                'category' => 'Venda',
                'description' => 'Venda PDV - Pedido #' . str_pad($order->id, 6, '0', STR_PAD_LEFT) . ' - Cliente: ' . ($client->name ?? 'N/A'),
                'amount' => $method['amount'],
                'payment_method' => $method['method'],
                'payment_methods' => [$method],
                'transaction_date' => Carbon::now('America/Sao_Paulo'),
                'status' => 'confirmado', // Venda finalizada, já confirmada
                'notes' => 'Venda PDV - Pedido #' . str_pad($order->id, 6, '0', STR_PAD_LEFT),
            ]);
        }

        // Registrar histórico de venda
        try {
            \App\Models\SalesHistory::recordSale($order);
        } catch (\Exception $e) {
            \Log::warning('Erro ao registrar histórico de venda', [
                'error' => $e->getMessage(),
                'order_id' => $order->id,
            ]);
        }

        // Registrar tracking de status inicial
        try {
            \App\Models\OrderStatusTracking::recordEntry($order->id, $order->status_id, Auth::id());
        } catch (\Exception $e) {
            \Log::warning('Erro ao registrar tracking de status', [
                'error' => $e->getMessage(),
                'order_id' => $order->id,
            ]);
        }

        // Limpar carrinho
        Session::forget('pdv_cart');

        $message = 'Venda realizada com sucesso';
        $requestsCount = count($stockRequestsCreated);
        if ($requestsCount > 0) {
            $message .= ". {$requestsCount} solicitação(ões) de estoque criada(s) automaticamente.";
        }
        
        \Log::info('Checkout do PDV concluído', [
            'order_id' => $order->id,
            'stock_requests_created_count' => $requestsCount,
            'stock_requests_created' => $stockRequestsCreated,
        ]);
        
        return response()->json([
            'success' => true,
            'message' => $message,
            'order_id' => $order->id,
            'order_number' => str_pad($order->id, 6, '0', STR_PAD_LEFT),
            'receipt_url' => route('pdv.sale-receipt', $order->id), // URL para gerar nota de venda do PDV
            'stock_requests_created' => $requestsCount,
            'stock_requests_details' => $stockRequestsCreated,
        ]);
    }

    /**
     * Gerar nota de venda do PDV (PDF)
     */
    public function downloadSaleReceipt($id)
    {
        $order = Order::with([
            'client',
            'status',
            'user',
            'store',
            'items.sublimations.location',
            'items.sublimations.size',
            'payments'
        ])->findOrFail($id);

        // Verificar se é realmente uma venda do PDV
        if (!$order->is_pdv) {
            return redirect()->route('orders.client-receipt', $order->id);
        }

        $payment = Payment::where('order_id', $id)->first();
        
        // Buscar configurações da loja
        $storeId = $order->store_id;
        if (!$storeId) {
            $mainStore = Store::where('is_main', true)->first();
            $storeId = $mainStore ? $mainStore->id : null;
        }
        
        $companySettings = \App\Models\CompanySetting::getSettings($storeId);

        try {
            // Gerar HTML da view
            $html = view('pdv.pdf.sale-receipt', compact('order', 'payment', 'companySettings'))->render();
            
            // Configurar DomPDF
            $options = new Options();
            $options->set('defaultFont', 'Arial');
            $options->set('isRemoteEnabled', true);
            $options->set('isHtml5ParserEnabled', true);
            $options->set('isImageEnabled', true);
            $options->set('chroot', public_path());
            
            $dompdf = new Dompdf($options);
            $dompdf->loadHtml($html);
            $dompdf->setPaper('A4', 'portrait');
            $dompdf->render();
            
            $filename = 'Nota_Venda_' . str_pad($order->id, 6, '0', STR_PAD_LEFT) . '_' . now()->format('Y-m-d') . '.pdf';
            
            return response($dompdf->output(), 200, [
                'Content-Type' => 'application/pdf',
                'Content-Disposition' => 'attachment; filename="' . $filename . '"',
            ]);
            
        } catch (\Exception $e) {
            \Log::error('Erro ao gerar PDF da venda: ' . $e->getMessage());
            return response()->json([
                'error' => 'Erro ao gerar PDF: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Listar vendas do PDV
     */
    public function sales(Request $request)
    {
        $search = $request->get('search');
        $status = $request->get('status');
        $startDate = $request->get('start_date');
        $endDate = $request->get('end_date');
        $paymentMethod = $request->get('payment_method');
        $showCancelled = $request->get('show_cancelled', false);
        $vendorId = $request->get('vendor_id'); // Novo filtro por vendedor

        $query = Order::with(['client', 'items', 'user', 'status', 'payments'])
            ->where('is_pdv', true) // Apenas vendas do PDV
            ->where('is_draft', false);

        // Filtro para mostrar/ocultar canceladas
        if (!$showCancelled) {
            $query->where('is_cancelled', false);
        }

        // Aplicar filtro de loja
        StoreHelper::applyStoreFilter($query);

        // Filtro por vendedor
        if ($vendorId) {
            $query->where('user_id', $vendorId);
        } elseif (Auth::user()->isVendedor()) {
            // Se for vendedor, mostrar apenas as vendas que ele criou
            $query->where('user_id', Auth::id());
        }

        // Busca
        if ($search) {
            $query->where(function($q) use ($search) {
                $q->where('id', 'like', "%{$search}%")
                  ->orWhereHas('client', function($q2) use ($search) {
                      $q2->where('name', 'like', "%{$search}%")
                         ->orWhere('phone_primary', 'like', "%{$search}%");
                  });
            });
        }

        // Filtro por status
        if ($status) {
            $query->where('status_id', $status);
        }

        // Filtro por data
        if ($startDate && $endDate) {
            $query->whereBetween('created_at', [$startDate . ' 00:00:00', $endDate . ' 23:59:59']);
        }

        // Filtro por forma de pagamento
        if ($paymentMethod) {
            $query->whereHas('payments', function($q) use ($paymentMethod) {
                $q->where(function($q2) use ($paymentMethod) {
                    $q2->where('payment_method', $paymentMethod)
                       ->orWhereJsonContains('payment_methods', [['method' => $paymentMethod]]);
                });
            });
        }

        $sales = $query->orderBy('created_at', 'desc')->paginate(20);
        $statuses = Status::orderBy('position')->get();

        // Buscar vendedores para filtro (apenas admins podem filtrar)
        $vendors = collect();
        if (Auth::user()->isAdmin()) {
            $vendors = User::where('role', 'vendedor')
                ->orWhereHas('stores', function($q) {
                    $q->where('store_user.role', 'vendedor');
                })
                ->orderBy('name')
                ->get();
        }

        // Estatísticas
        $totalSales = (clone $query)->count();
        $totalRevenue = (clone $query)->sum('total');
        $salesToday = (clone $query)->whereDate('created_at', Carbon::now('America/Sao_Paulo')->toDateString())->count();
        $revenueToday = (clone $query)->whereDate('created_at', Carbon::now('America/Sao_Paulo')->toDateString())->sum('total');

        // Estatísticas do vendedor selecionado (se houver)
        $vendorStats = null;
        if ($vendorId) {
            $vendorQuery = (clone $query)->where('user_id', $vendorId);
            $vendorStats = [
                'total_sales' => $vendorQuery->count(),
                'total_revenue' => $vendorQuery->sum('total'),
                'avg_ticket' => $vendorQuery->count() > 0 ? $vendorQuery->sum('total') / $vendorQuery->count() : 0,
            ];
        }

        return view('pdv.sales', compact(
            'sales', 
            'statuses', 
            'vendors',
            'vendorId',
            'vendorStats',
            'search', 
            'status', 
            'startDate', 
            'endDate', 
            'paymentMethod',
            'showCancelled',
            'totalSales',
            'totalRevenue',
            'salesToday',
            'revenueToday'
        ));
    }

    /**
     * Editar venda do PDV (apenas admin)
     */
    public function editSale($id)
    {
        if (!Auth::user()->isAdmin()) {
            abort(403, 'Apenas administradores podem editar vendas.');
        }

        $sale = Order::with(['client', 'items', 'payments', 'status'])
            ->where('is_pdv', true)
            ->findOrFail($id);

        $clients = Client::orderBy('name')->get();
        $statuses = Status::orderBy('position')->get();

        return view('pdv.edit-sale', compact('sale', 'clients', 'statuses'));
    }

    /**
     * Atualizar venda do PDV (apenas admin)
     */
    public function updateSale(Request $request, $id)
    {
        if (!Auth::user()->isAdmin()) {
            abort(403, 'Apenas administradores podem editar vendas.');
        }

        $sale = Order::where('is_pdv', true)->findOrFail($id);

        $validated = $request->validate([
            'client_id' => 'required|exists:clients,id',
            'status_id' => 'required|exists:statuses,id',
            'notes' => 'nullable|string',
        ]);

        // Manter sempre o status "Entregue" para vendas do PDV
        $status = Status::where('name', 'Entregue')->first();
        if ($status) {
            $validated['status_id'] = $status->id;
        }

        $sale->update($validated);

        return redirect()->route('pdv.sales')->with('success', 'Venda atualizada com sucesso!');
    }

    /**
     * Cancelar venda do PDV (apenas admin)
     */
    public function cancelSale(Request $request, $id)
    {
        if (!Auth::user()->isAdmin()) {
            abort(403, 'Apenas administradores podem cancelar vendas.');
        }

        $validated = $request->validate([
            'cancellation_reason' => 'required|string|max:1000'
        ]);

        $sale = Order::where('is_pdv', true)->findOrFail($id);

        if ($sale->is_cancelled) {
            return redirect()->route('pdv.sales')->with('error', 'Esta venda já está cancelada.');
        }

        // Cancelar a venda (não excluir)
        $sale->update([
            'is_cancelled' => true,
            'cancelled_at' => Carbon::now('America/Sao_Paulo'),
            'cancellation_reason' => $validated['cancellation_reason'],
        ]);

        // Reverter transações de caixa criando transações de saída
        $user = Auth::user();
        $client = $sale->client;
        $cashTransactions = $sale->cashTransactions()->where('status', 'confirmado')->get();
        
        foreach ($cashTransactions as $transaction) {
            // Criar transação de saída para reverter
            CashTransaction::create([
                'user_id' => $user->id,
                'user_name' => $user->name,
                'order_id' => $sale->id,
                'store_id' => $transaction->store_id,
                'type' => 'saida',
                'category' => 'Cancelamento',
                'description' => 'Cancelamento de Venda PDV - Pedido #' . str_pad($sale->id, 6, '0', STR_PAD_LEFT) . ' - Cliente: ' . ($client->name ?? 'N/A'),
                'amount' => $transaction->amount,
                'payment_method' => $transaction->payment_method,
                'payment_methods' => $transaction->payment_methods,
                'transaction_date' => Carbon::now('America/Sao_Paulo'),
                'status' => 'confirmado',
                'notes' => 'Reversão de venda cancelada - Pedido #' . str_pad($sale->id, 6, '0', STR_PAD_LEFT) . ' - Motivo: ' . $validated['cancellation_reason'],
            ]);
        }

        return redirect()->route('pdv.sales')->with('success', 'Venda cancelada com sucesso! As transações de caixa foram revertidas.');
    }
    
    /**
     * Descontar estoque após venda
     * Retorna true se conseguiu descontar, false se não havia estoque suficiente
     */
    private function deductStockFromSale($storeId, $fabricId, $colorId, $cutTypeId, $size, $quantity)
    {
        if (!Schema::hasTable('stocks') || !$storeId) {
            return false;
        }
        
        try {
            $stock = Stock::findByParams($storeId, $fabricId, $colorId, $cutTypeId, $size);
            
            if ($stock && $stock->available_quantity >= $quantity) {
                $stock->use($quantity);
                \Log::info('Estoque descontado com sucesso', [
                    'store_id' => $storeId,
                    'fabric_id' => $fabricId,
                    'color_id' => $colorId,
                    'cut_type_id' => $cutTypeId,
                    'size' => $size,
                    'quantity' => $quantity,
                    'available_after' => $stock->available_quantity,
                ]);
                return true;
            } else {
                \Log::warning('Tentativa de descontar estoque insuficiente', [
                    'store_id' => $storeId,
                    'fabric_id' => $fabricId,
                    'color_id' => $colorId,
                    'cut_type_id' => $cutTypeId,
                    'size' => $size,
                    'quantity' => $quantity,
                    'available' => $stock ? $stock->available_quantity : 0,
                ]);
            }
        } catch (\Exception $e) {
            \Log::error('Erro ao descontar estoque', [
                'error' => $e->getMessage(),
                'store_id' => $storeId,
                'fabric_id' => $fabricId,
                'color_id' => $colorId,
                'cut_type_id' => $cutTypeId,
                'size' => $size,
                'quantity' => $quantity,
            ]);
        }
        
        return false;
    }

    /**
     * Calcular total do carrinho
     */
    private function calculateCartTotal(array $cart): float
    {
        return array_sum(array_column($cart, 'total_price'));
    }
}

