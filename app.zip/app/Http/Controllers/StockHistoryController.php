<?php

namespace App\Http\Controllers;

use App\Models\StockHistory;
use App\Models\Store;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\View\View;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;

class StockHistoryController extends Controller
{
    /**
     * Listar histórico de estoque
     */
    public function index(Request $request): View
    {
        $search = $request->get('search');
        $storeId = $request->get('store_id');
        $userId = $request->get('user_id');
        $actionType = $request->get('action_type');
        $startDate = $request->get('start_date');
        $endDate = $request->get('end_date');
        $fabricId = $request->get('fabric_id');
        $colorId = $request->get('color_id');
        $cutTypeId = $request->get('cut_type_id');
        $size = $request->get('size');

        $query = StockHistory::with([
            'stock',
            'store',
            'user',
            'order',
            'stockRequest',
            'fabric',
            'color',
            'cutType'
        ]);

        // Filtros
        if ($storeId) {
            $query->where('store_id', $storeId);
        }

        if ($userId) {
            $query->where('user_id', $userId);
        }

        if ($actionType) {
            $query->where('action_type', $actionType);
        }

        if ($fabricId) {
            $query->where('fabric_id', $fabricId);
        }

        if ($colorId) {
            $query->where('color_id', $colorId);
        }

        if ($cutTypeId) {
            $query->where('cut_type_id', $cutTypeId);
        }

        if ($size) {
            $query->where('size', $size);
        }

        // Filtro por data
        if ($startDate) {
            $query->where('action_date', '>=', $startDate);
        }
        if ($endDate) {
            $query->where('action_date', '<=', $endDate . ' 23:59:59');
        }

        // Busca
        if ($search) {
            $query->where(function($q) use ($search) {
                $q->where('size', 'like', "%{$search}%")
                  ->orWhereHas('fabric', function($q2) use ($search) {
                      $q2->where('name', 'like', "%{$search}%");
                  })
                  ->orWhereHas('color', function($q2) use ($search) {
                      $q2->where('name', 'like', "%{$search}%");
                  })
                  ->orWhereHas('cutType', function($q2) use ($search) {
                      $q2->where('name', 'like', "%{$search}%");
                  });
            });
        }

        $history = $query->orderBy('action_date', 'desc')->paginate(20);

        // Estatísticas
        $stats = [
            'total_movements' => (clone $query)->count(),
            'total_entradas' => (clone $query)->where('action_type', 'entrada')->sum('quantity_change'),
            'total_saidas' => abs((clone $query)->where('action_type', 'saida')->sum('quantity_change')),
            'total_transferencias' => (clone $query)->where('action_type', 'transferencia')->count(),
        ];

        // Dados para filtros
        $stores = \App\Helpers\StoreHelper::getAvailableStores();
        $users = User::whereIn('role', ['admin_geral', 'admin_loja', 'producao'])
            ->orderBy('name')
            ->get();

        $actionTypes = [
            'entrada' => 'Entrada',
            'saida' => 'Saída',
            'reserva' => 'Reserva',
            'liberacao' => 'Liberação',
            'transferencia' => 'Transferência',
            'ajuste' => 'Ajuste',
            'devolucao' => 'Devolução',
            'perda' => 'Perda',
        ];

        $sizes = ['PP', 'P', 'M', 'G', 'GG', 'EXG', 'G1', 'G2', 'G3'];

        return view('stock-history.index', compact(
            'history',
            'stores',
            'users',
            'actionTypes',
            'sizes',
            'stats',
            'search',
            'storeId',
            'userId',
            'actionType',
            'startDate',
            'endDate',
            'fabricId',
            'colorId',
            'cutTypeId',
            'size'
        ));
    }
}
