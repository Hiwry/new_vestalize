<?php

namespace App\Helpers;

use Illuminate\Support\Facades\Auth;
use App\Models\Store;

class StoreHelper
{
    /**
     * Aplicar filtro de loja na query baseado no role do usuário
     */
    public static function applyStoreFilter($query, $storeColumn = 'store_id')
    {
        $user = Auth::user();
        
        if (!$user) {
            return $query;
        }

        // Admin geral e estoque vêem tudo (sem filtro)
        if ($user->isAdminGeral() || $user->isEstoque()) {
            return $query;
        }

        // Admin loja vê apenas suas lojas + sub-lojas
        if ($user->isAdminLoja()) {
            $storeIds = $user->getStoreIds();
            
            if (!empty($storeIds)) {
                return $query->whereIn($storeColumn, $storeIds);
            }
        }

        // Vendedor não tem filtro por loja (mantém comportamento atual - filtrado por user_id)
        return $query;
    }

    /**
     * Obter IDs das lojas que o usuário pode acessar
     */
    public static function getUserStoreIds(): array
    {
        $user = Auth::user();
        
        if (!$user) {
            return [];
        }

        return $user->getStoreIds();
    }

    /**
     * Verificar se usuário pode acessar uma loja
     */
    public static function canAccessStore($storeId): bool
    {
        $user = Auth::user();
        
        if (!$user) {
            return false;
        }

        return $user->canAccessStore($storeId);
    }

    /**
     * Obter todas as lojas disponíveis para o usuário
     */
    public static function getAvailableStores()
    {
        $user = Auth::user();
        
        if (!$user) {
            return collect();
        }

        if ($user->isAdminGeral() || $user->isEstoque()) {
            return Store::active()->orderBy('name')->get();
        }

        if ($user->isAdminLoja()) {
            $storeIds = $user->getStoreIds();
            return Store::whereIn('id', $storeIds)->active()->orderBy('name')->get();
        }

        return collect();
    }
}

