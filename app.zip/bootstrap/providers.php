<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\StorageLinkServiceProvider::class,
    Intervention\Image\ImageServiceProvider::class,
    Barryvdh\DomPDF\ServiceProvider::class,
];
